// Umbra Background v2.6

const LICENSE_ENDPOINT = 'https://cvrdcupvqvkpwllwlkfw.functions.supabase.co/validar-licenca';
const SLUG = 'umbrahub-all';
const VERSION = '2.6.0';
const SESSION_MS = 24 * 60 * 60 * 1000;
const HEARTBEAT_MS = 6 * 60 * 60 * 1000;

async function getDeviceId() {
  return new Promise(r => {
    chrome.storage.local.get('umbra_device_id', d => {
      if (d.umbra_device_id) { r(d.umbra_device_id); return; }
      const id = 'dev_' + Math.random().toString(36).slice(2) + Date.now().toString(36);
      chrome.storage.local.set({ umbra_device_id: id }, () => r(id));
    });
  });
}

async function checkLocal() {
  return new Promise(r => {
    chrome.storage.local.get(['umbra_token','umbra_chave','umbra_expiry'], d => {
      r(d.umbra_token && d.umbra_expiry && Date.now() < d.umbra_expiry
        ? { valido: true } : { valido: false });
    });
  });
}

async function activateLicense(chave) {
  const device_id = await getDeviceId();
  try {
    const res = await fetch(LICENSE_ENDPOINT, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action:'activate', chave, device_id, slug:SLUG, version:VERSION })
    });
    const data = await res.json();
    if (data.valido || data.token) {
      chrome.storage.local.set({ umbra_token: data.token, umbra_chave: chave, umbra_expiry: Date.now()+SESSION_MS });
      scheduleHeartbeat();
      return { valido: true };
    }
    return { valido: false, motivo: data.motivo || data.message || 'Chave inválida.' };
  } catch {
    return { valido: false, motivo: 'Erro de conexão.' };
  }
}

async function verifyLicense() {
  return new Promise(r => {
    chrome.storage.local.get(['umbra_token','umbra_chave'], async d => {
      if (!d.umbra_token) { r({ valido: false }); return; }
      const device_id = await getDeviceId();
      try {
        const res = await fetch(LICENSE_ENDPOINT, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action:'verify', chave:d.umbra_chave, device_id, token:d.umbra_token, slug:SLUG, version:VERSION })
        });
        const data = await res.json();
        if (data.valido || data.token) {
          chrome.storage.local.set({ umbra_expiry: Date.now()+SESSION_MS, umbra_token: data.token||d.umbra_token });
          r({ valido: true });
        } else {
          chrome.storage.local.remove(['umbra_token','umbra_chave','umbra_expiry']);
          r({ valido: false, motivo: data.motivo||'Licença revogada.' });
        }
      } catch {
        const local = await checkLocal();
        r(local);
      }
    });
  });
}

async function getStatus() {
  const local = await checkLocal();
  return local.valido ? local : verifyLicense();
}

let heartbeatTimer = null;
function scheduleHeartbeat() {
  if (heartbeatTimer) clearInterval(heartbeatTimer);
  heartbeatTimer = setInterval(verifyLicense, HEARTBEAT_MS);
}
chrome.storage.local.get('umbra_token', d => { if (d.umbra_token) scheduleHeartbeat(); });

function isBadUrl(url) {
  if (!url) return true;
  return url.startsWith('chrome://') || url.startsWith('chrome-extension://') ||
         url.startsWith('edge://') || url.startsWith('about:') ||
         url.startsWith('data:') || url.startsWith('file://') ||
         url.includes('chrome.google.com/webstore');
}

function injectAndToggle(tabId) {
  chrome.scripting.executeScript({ target:{ tabId }, files:['content.js'] }, () => {
    if (chrome.runtime.lastError) return;
    setTimeout(() => chrome.tabs.sendMessage(tabId, { type:'UMBRA_TOGGLE' }, () => {
      if (chrome.runtime.lastError) {}
    }), 200);
  });
}

chrome.action.onClicked.addListener((tab) => {
  if (!tab || !tab.id || isBadUrl(tab.url)) return;

  if (tab.status === 'loading') {
    const fn = (tabId, info) => {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(fn);
        chrome.tabs.sendMessage(tab.id, { type:'UMBRA_TOGGLE' }, () => {
          if (chrome.runtime.lastError) injectAndToggle(tab.id);
        });
      }
    };
    chrome.tabs.onUpdated.addListener(fn);
    setTimeout(() => chrome.tabs.onUpdated.removeListener(fn), 10000);
    return;
  }

  chrome.tabs.sendMessage(tab.id, { type:'UMBRA_TOGGLE' }, () => {
    if (chrome.runtime.lastError) injectAndToggle(tab.id);
  });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'GET_STATUS') { getStatus().then(sendResponse); return true; }
  if (msg.action === 'ACTIVATE')   { activateLicense(msg.chave).then(sendResponse); return true; }
  if (msg.action === 'LOGOUT') {
    chrome.storage.local.remove(['umbra_token','umbra_chave','umbra_expiry'], () => sendResponse({ ok:true }));
    return true;
  }

  if (msg.type === 'UMBRA_DOWNLOAD') {
    chrome.downloads.download({ url:msg.url, filename:msg.filename||undefined }, () => sendResponse({ ok:true }));
    return true;
  }
  if (msg.type === 'UMBRA_DOWNLOAD_BATCH') {
    const { images, folder } = msg;
    images.forEach((img,i) => {
      const e = (img.url.split('?')[0].split('.').pop()||'jpg').toLowerCase();
      const ext = ['jpg','jpeg','png','gif','webp','svg','bmp','avif'].includes(e) ? e : 'jpg';
      const name = img.name || `umbra_${String(i+1).padStart(3,'0')}.${ext}`;
      chrome.downloads.download({ url:img.url, filename:folder ? `${folder}/${name}` : name });
    });
    sendResponse({ ok:true, count:images.length });
    return true;
  }
  if (msg.type === 'UMBRA_GET_SETTINGS') {
    chrome.storage.local.get('umbra_settings', d => sendResponse({ settings:d.umbra_settings||{} }));
    return true;
  }
  if (msg.type === 'UMBRA_SAVE_SETTINGS') {
    chrome.storage.local.set({ umbra_settings:msg.settings }, () => sendResponse({ ok:true }));
    return true;
  }
});
