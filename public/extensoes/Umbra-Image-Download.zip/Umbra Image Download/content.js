// Umbra Image Download v2.7
(function () {
  'use strict';
  if (window.__UMBRA27) { window.__UMBRA27.toggle(); return; }

  // ── State ────────────────────────────────────────────────────────────
  let images = [], filtered = [], selected = new Set();
  let viewMode = 'grid', visible = false, minimized = false;
  let S = { folder:'umbra-images', prefix:'umbra', filterType:'all', minW:0, minH:0, query:'' };
  let toastT, prevT, obsv, shadow, hostEl;

  // ── Init Shadow DOM ──────────────────────────────────────────────────
  // The HOST itself is position:fixed and fills the panel area.
  // The shadow root renders inside it with no coordinate issues.
  function initShadow() {
    if (shadow) return;
    hostEl = document.createElement('div');
    // Host is fixed, sized to the panel, starts at top-right
    hostEl.style.cssText = [
      'all:initial',
      'position:fixed',
      'top:20px',
      'right:20px',
      'width:460px',
      'height:680px',
      'min-width:360px',
      'min-height:240px',
      'z-index:2147483647',
      'pointer-events:none',
      'border-radius:12px',
    ].join(';');
    document.documentElement.appendChild(hostEl);
    shadow = hostEl.attachShadow({ mode:'open' });
    const s = document.createElement('style');
    s.textContent = CSS;
    shadow.appendChild(s);
  }

  function R(id) { return shadow && shadow.getElementById(id); }
  function QA(sel) { return shadow ? [...shadow.querySelectorAll(sel)] : []; }

  // ── Settings ─────────────────────────────────────────────────────────
  function saveSett() {
    try { chrome.runtime.sendMessage({ type:'UMBRA_SAVE_SETTINGS', settings:{...S,viewMode} }); } catch{}
  }
  function loadSett(cb) {
    try {
      chrome.runtime.sendMessage({ type:'UMBRA_GET_SETTINGS' }, r => {
        if (!chrome.runtime.lastError && r?.settings) {
          const s = r.settings;
          S = { folder:s.folder||'umbra-images', prefix:s.prefix||'umbra',
                filterType:s.filterType||'all', minW:s.minW||0, minH:s.minH||0, query:s.query||'' };
          if (s.viewMode) viewMode = s.viewMode;
        }
        cb();
      });
    } catch { cb(); }
  }

  // ── Build panel ──────────────────────────────────────────────────────
  function buildPanel() {
    initShadow();
    if (R('panel')) return;

    const wrap = document.createElement('div');
    wrap.id = 'panel';
    wrap.innerHTML = `
<div id="hdr">
  <div id="hdr-l">
    <div id="logo">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
        <polyline points="7 10 12 15 17 10"/>
        <line x1="12" y1="15" x2="12" y2="3"/>
      </svg>
    </div>
    <span id="t-title">Umbra</span>
    <span id="t-lic" class="lic-dot"></span>
  </div>
  <div id="hdr-r">
    <button id="btn-scan" class="hbtn">↺</button>
    <button id="btn-min"  class="hbtn">−</button>
    <button id="btn-cls"  class="hbtn red">✕</button>
  </div>
</div>

<div id="lic-view">
  <div id="lic-box">
    <div id="lic-icon">🔐</div>
    <h2>Licença necessária</h2>
    <p>Insira sua chave para acessar o Umbra Image Download.</p>
    <input id="lic-key" type="text" placeholder="UMBRA-XXXX-XXXX-XXXX" spellcheck="false" autocomplete="off">
    <button id="lic-ok">Ativar licença</button>
    <p id="lic-err"></p>
    <a id="lic-link" href="https://umbrahubb.vercel.app" target="_blank">Comprar licença →</a>
  </div>
</div>

<div id="app-view">
  <div id="filters">
    <div class="row">
      <span class="lbl">Tipo</span>
      <select id="f-type">
        <option value="all">Todos</option>
        <option value="jpg">JPG</option>
        <option value="png">PNG</option>
        <option value="gif">GIF</option>
        <option value="webp">WebP</option>
        <option value="svg">SVG</option>
        <option value="avif">AVIF</option>
      </select>
      <span class="lbl ml">Mín W×H</span>
      <input id="f-w" class="narrow" type="number" placeholder="W" min="0">
      <span class="x">×</span>
      <input id="f-h" class="narrow" type="number" placeholder="H" min="0">
    </div>
    <div class="row">
      <span class="lbl">URL</span>
      <input id="f-q" type="text" placeholder="Palavra-chave na URL…">
    </div>
    <div class="row">
      <span class="lbl">Pasta</span>
      <input id="f-folder" type="text" placeholder="umbra-images">
      <span class="lbl ml">Prefix</span>
      <input id="f-prefix" class="short" type="text" placeholder="umbra">
    </div>
  </div>

  <div id="toolbar">
    <span id="t-count">0 imagens</span>
    <div id="t-btns">
      <button id="v3" class="vb on">⊞</button>
      <button id="v2" class="vb">▦</button>
      <button id="vl" class="vb">≡</button>
      <div class="vd"></div>
      <button id="sel-all" class="tb">Sel. todos</button>
      <button id="desel"   class="tb">Desmarcar</button>
      <div class="vd"></div>
      <button id="btn-out" class="tb red-tb" title="Sair">⎋</button>
    </div>
  </div>

  <div id="scroll">
    <div id="t-load"><div class="spin"></div><span>Escaneando…</span></div>
    <div id="t-empty">
      <svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="#444" stroke-width="1.3">
        <rect x="3" y="3" width="18" height="18" rx="2"/>
        <circle cx="8.5" cy="8.5" r="1.5"/>
        <polyline points="21 15 16 10 5 21"/>
      </svg>
      <p>Nenhuma imagem encontrada</p>
    </div>
    <div id="grid"></div>
  </div>

  <div id="footer">
    <button id="dl-sel" class="fb s" disabled>↓ Sel. (<span id="sc">0</span>)</button>
    <button id="dl-all" class="fb p" disabled>↓ Baixar todas</button>
    <button id="dl-zip" class="fb z" disabled>ZIP</button>
  </div>

  <div id="zip-ov">
    <div class="spin"></div>
    <span id="zip-txt">Aguarde…</span>
    <div id="zip-bar"><div id="zip-fill"></div></div>
  </div>
</div>

<div id="rzr"></div>`;

    shadow.appendChild(wrap);

    // Preview tooltip + toast (outside panel, inside shadow)
    const pv = document.createElement('div');
    pv.id = 'pv';
    pv.innerHTML = '<img id="pi" src="" alt="">';
    shadow.appendChild(pv);

    const toast = document.createElement('div');
    toast.id = 'toast';
    shadow.appendChild(toast);

    wireEvents();
  }

  // ── Wire events ───────────────────────────────────────────────────────
  function wireEvents() {
    // Header
    R('btn-cls').onclick = hide;
    R('btn-min').onclick = toggleMin;
    R('btn-scan').onclick = doScan;

    // License
    R('lic-ok').onclick = doActivate;
    R('lic-key').addEventListener('keydown', e => { if (e.key==='Enter') doActivate(); });

    // Filters
    R('f-type').onchange   = e => { S.filterType=e.target.value; saveSett(); refilter(); };
    R('f-w').oninput       = e => { S.minW=+e.target.value||0; saveSett(); refilter(); };
    R('f-h').oninput       = e => { S.minH=+e.target.value||0; saveSett(); refilter(); };
    R('f-q').oninput       = e => { S.query=e.target.value; saveSett(); refilter(); };
    R('f-folder').onchange = e => { S.folder=e.target.value||'umbra-images'; saveSett(); };
    R('f-prefix').onchange = e => { S.prefix=e.target.value||'umbra'; saveSett(); };

    // View buttons
    R('v3').onclick = () => setView('grid');
    R('v2').onclick = () => setView('cols2');
    R('vl').onclick = () => setView('list');

    // Select
    R('sel-all').onclick = () => {
      filtered.forEach(i => selected.add(i.url));
      QA('.card').forEach(c => c.classList.add('sel'));
      updFoot();
    };
    R('desel').onclick = () => {
      selected.clear();
      QA('.card').forEach(c => c.classList.remove('sel'));
      updFoot();
    };

    // Logout
    R('btn-out').onclick = () => {
      chrome.runtime.sendMessage({ action:'LOGOUT' }, () => showLic());
    };

    // Downloads
    R('dl-all').onclick = () => dlBatch(filtered);
    R('dl-sel').onclick = () => dlBatch(filtered.filter(i=>selected.has(i.url)));
    R('dl-zip').onclick = () => doZip(selected.size>0 ? filtered.filter(i=>selected.has(i.url)) : filtered);

    // Drag — move the HOST element
    let ox,oy,ex,ey;
    R('hdr').addEventListener('mousedown', e => {
      if (e.target.closest('button')) return;
      e.preventDefault();
      const cs = getComputedStyle(hostEl);
      ox=e.clientX; oy=e.clientY;
      ex=parseInt(cs.right)||20; ey=parseInt(cs.top)||20;
      const mm = ev => {
        const dx = ox - ev.clientX; // right decreases as we go left
        const dy = ev.clientY - oy;
        hostEl.style.right = Math.max(0, ex+dx)+'px';
        hostEl.style.top   = Math.max(0, ey+dy)+'px';
        hostEl.style.left  = 'auto';
      };
      const mu = () => { removeEventListener('mousemove',mm); removeEventListener('mouseup',mu); };
      addEventListener('mousemove',mm); addEventListener('mouseup',mu);
    });

    // Resize — resize the HOST element
    R('rzr').addEventListener('mousedown', e => {
      e.preventDefault();
      const sx=e.clientX, sy=e.clientY;
      const sw=hostEl.offsetWidth, sh=hostEl.offsetHeight;
      const mm = e => {
        hostEl.style.width  = Math.max(360, sw+e.clientX-sx)+'px';
        hostEl.style.height = Math.max(240, sh+e.clientY-sy)+'px';
      };
      const mu = () => { removeEventListener('mousemove',mm); removeEventListener('mouseup',mu); };
      addEventListener('mousemove',mm); addEventListener('mouseup',mu);
    });
  }

  function toggleMin() {
    minimized = !minimized;
    if (minimized) {
      hostEl.style.height = '46px';
      R('lic-view').style.display = 'none';
      R('app-view').style.display = 'none';
    } else {
      hostEl.style.height = '680px';
      checkAndShow(); // restore correct view
    }
  }

  // ── License screens ───────────────────────────────────────────────────
  function showLic() {
    R('lic-view').style.display = 'flex';
    R('app-view').style.display = 'none';
    R('t-lic').className = 'lic-dot locked';
    R('btn-scan').style.visibility = 'hidden';
    if (obsv) { obsv.disconnect(); obsv=null; }
  }

  function showApp() {
    R('lic-view').style.display = 'none';
    R('app-view').style.display = 'flex';
    R('t-lic').className = 'lic-dot active';
    R('btn-scan').style.visibility = 'visible';
    // restore saved values
    R('f-type').value   = S.filterType;
    R('f-w').value      = S.minW||'';
    R('f-h').value      = S.minH||'';
    R('f-q').value      = S.query||'';
    R('f-folder').value = S.folder;
    R('f-prefix').value = S.prefix;
    setView(viewMode, false);
    doScan();
  }

  function doActivate() {
    const chave = (R('lic-key').value||'').trim().toUpperCase();
    if (!chave) { R('lic-err').textContent='Digite sua chave.'; return; }
    const btn = R('lic-ok');
    btn.disabled=true; btn.textContent='Validando…';
    R('lic-err').textContent='';
    chrome.runtime.sendMessage({ action:'ACTIVATE', chave }, res => {
      btn.disabled=false; btn.textContent='Ativar licença';
      if (res?.valido) showApp();
      else R('lic-err').textContent = res?.motivo||'Chave inválida ou limite atingido.';
    });
  }

  function checkAndShow() {
    chrome.runtime.sendMessage({ action:'GET_STATUS' }, res => {
      if (res?.valido) showApp(); else showLic();
    });
  }

  // ── View mode ─────────────────────────────────────────────────────────
  function setView(mode, render=true) {
    viewMode=mode; saveSett();
    ['v3','v2','vl'].forEach(id => R(id)&&R(id).classList.remove('on'));
    R({grid:'v3',cols2:'v2',list:'vl'}[mode])?.classList.add('on');
    const g=R('grid'); if(g) g.className=mode==='cols2'?'c2':mode==='list'?'lst':'';
    if(render) renderGrid();
  }

  // ── Scan ──────────────────────────────────────────────────────────────
  function doScan() {
    if (!R('t-load')) return;
    R('t-load').style.display='flex';
    R('t-empty').style.display='none';
    R('grid').innerHTML='';
    R('grid').style.display='none';
    selected.clear(); updFoot();
    setTimeout(() => {
      images = scanPage();
      refilter();
      R('t-load').style.display='none';
      showToast('✓ '+images.length+' imagens encontradas');
      startObs();
    }, 150);
  }

  function scanPage() {
    const seen=new Set(), list=[];
    function res(u) {
      if (!u||typeof u!=='string') return null;
      u=u.trim();
      if (!u||u.startsWith('data:')||u.startsWith('blob:')) return null;
      try { return new URL(u,location.href).href; } catch { return null; }
    }
    function add(raw,w,h) {
      const url=res(raw);
      if (!url||url.startsWith('chrome-extension://')||url.startsWith('moz-extension://')) return;
      if (seen.has(url)) return;
      seen.add(url); list.push({url,w:w||0,h:h||0});
    }
    function skip(el) { return hostEl&&(el===hostEl||hostEl.contains(el)); }

    document.querySelectorAll('img').forEach(el => {
      if (skip(el)) return;
      add(el.currentSrc||el.src, el.naturalWidth||el.width, el.naturalHeight||el.height);
      ['data-src','data-lazy','data-original','data-url'].forEach(a => {
        const v=el.getAttribute(a); if(v) add(v.split(',')[0].trim().split(/\s+/)[0],0,0);
      });
    });
    document.querySelectorAll('img[srcset],source[srcset]').forEach(el => {
      if (skip(el)) return;
      (el.getAttribute('srcset')||'').split(',').forEach(p=>{const u=p.trim().split(/\s+/)[0];if(u)add(u,0,0);});
    });
    document.querySelectorAll('source[src]').forEach(el=>{ if(!skip(el)) add(el.getAttribute('src'),0,0); });
    document.querySelectorAll('a[href]').forEach(el => {
      if (skip(el)) return;
      const h=el.getAttribute('href')||'';
      if (/\.(jpe?g|png|gif|webp|svg|avif|bmp)(\?|#|$)/i.test(h)) add(h,0,0);
    });
    document.querySelectorAll('[style*="background"]').forEach(el => {
      if (skip(el)) return;
      for(const m of (el.getAttribute('style')||'').matchAll(/url\(["']?([^"')]+)["']?\)/g)) add(m[1],0,0);
    });
    'div,section,article,aside,header,footer,main,figure,li,a,td,th'.split(',').forEach(tag=>{
      document.querySelectorAll(tag).forEach(el=>{
        if (skip(el)) return;
        try {
          const bg=getComputedStyle(el).backgroundImage;
          if (!bg||bg==='none') return;
          for(const m of bg.matchAll(/url\(["']?([^"')]+)["']?\)/g))
            if(!m[1].startsWith('data:')){ const r=el.getBoundingClientRect(); add(m[1],Math.round(r.width),Math.round(r.height)); }
        } catch{}
      });
    });
    document.querySelectorAll('meta[property="og:image"],meta[name="twitter:image"]').forEach(el=>add(el.getAttribute('content'),0,0));
    return list;
  }

  function startObs() {
    if (obsv) obsv.disconnect();
    let t;
    obsv=new MutationObserver(()=>{ clearTimeout(t); t=setTimeout(()=>{ const f=scanPage(); if(f.length!==images.length){images=f;refilter();} },1200); });
    obsv.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['src','srcset','data-src','style']});
  }

  // ── Filter + render ───────────────────────────────────────────────────
  function getExt(url) {
    try { return new URL(url).pathname.split('.').pop().toLowerCase().replace(/[^a-z0-9]/g,'').slice(0,5); }
    catch { return ''; }
  }

  function refilter() {
    const q=(S.query||'').toLowerCase();
    filtered=images.filter(img=>{
      const e=getExt(img.url);
      if (S.filterType!=='all') {
        if (S.filterType==='jpg'&&!['jpg','jpeg'].includes(e)) return false;
        if (S.filterType!=='jpg'&&e!==S.filterType) return false;
      }
      if (S.minW>0&&img.w>0&&img.w<S.minW) return false;
      if (S.minH>0&&img.h>0&&img.h<S.minH) return false;
      if (q&&!img.url.toLowerCase().includes(q)) return false;
      return true;
    });
    renderGrid();
  }

  function renderGrid() {
    const grid=R('grid'), empty=R('t-empty'), cnt=R('t-count');
    if (!grid) return;
    cnt.textContent = filtered.length+' imagem'+(filtered.length!==1?'ns':'');
    if (!filtered.length) {
      grid.innerHTML=''; grid.style.display='none'; empty.style.display='flex'; updFoot(); return;
    }
    empty.style.display='none'; grid.style.display='grid';
    grid.className = viewMode==='cols2'?'c2':viewMode==='list'?'lst':'';
    grid.innerHTML='';
    filtered.forEach((img,i)=>{
      const e=getExt(img.url).toUpperCase()||'IMG';
      const dim=img.w&&img.h?img.w+'×'+img.h:'';
      const short=img.url.replace(/^https?:\/\//,'').slice(0,52);

      const card=document.createElement('div');
      card.className='card'+(selected.has(img.url)?' sel':'');

      const thumb=document.createElement('img');
      thumb.className='th'; thumb.loading='lazy'; thumb.src=img.url; thumb.alt='';
      thumb.onerror=()=>{ thumb.style.opacity='0.07'; };

      const chk=document.createElement('div'); chk.className='ck';
      chk.innerHTML='<svg width="9" height="9" viewBox="0 0 12 12" fill="none" stroke="#fff" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="2 6 5 9 10 3"/></svg>';

      const ov=document.createElement('div'); ov.className='ov';
      const dlb=document.createElement('button'); dlb.className='dlb'; dlb.textContent='↓ Baixar';
      const mt=document.createElement('span'); mt.className='mt'; mt.textContent=dim?dim+' · '+e:e;
      ov.append(dlb,mt);

      const uu=document.createElement('span'); uu.className='uu'; uu.textContent=short;
      const ud=document.createElement('span'); ud.className='ud'; ud.textContent=dim||e;

      card.append(chk,thumb,ov,uu,ud);

      card.addEventListener('mouseenter',ev=>showPrev(img.url,ev));
      card.addEventListener('mousemove',movePrev);
      card.addEventListener('mouseleave',hidePrev);
      card.addEventListener('click',ev=>{
        if (ev.target.closest('.dlb')) return;
        if (selected.has(img.url)){selected.delete(img.url);card.classList.remove('sel');}
        else{selected.add(img.url);card.classList.add('sel');}
        updFoot();
      });
      dlb.addEventListener('click',ev=>{ev.stopPropagation();dlOne(img.url,i);});
      grid.appendChild(card);
    });
    updFoot();
  }

  function updFoot() {
    if (!R('sc')) return;
    R('sc').textContent=selected.size;
    R('dl-sel').disabled=selected.size===0;
    R('dl-all').disabled=filtered.length===0;
    R('dl-zip').disabled=filtered.length===0;
  }

  // ── Preview ───────────────────────────────────────────────────────────
  function showPrev(url,e){ clearTimeout(prevT); prevT=setTimeout(()=>{ const pv=R('pv'),pi=R('pi'); if(!pv||!pi)return; pi.src=url; pv.style.display='block'; movePrev(e); },450); }
  function movePrev(e){ const pv=R('pv'); if(!pv||pv.style.display==='none')return; let x=e.clientX+14,y=e.clientY+14; if(x+240>innerWidth-10)x=e.clientX-254; if(y+240>innerHeight-10)y=e.clientY-254; pv.style.left=x+'px'; pv.style.top=y+'px'; }
  function hidePrev(){ clearTimeout(prevT); const pv=R('pv'); if(pv)pv.style.display='none'; }

  // ── Download ──────────────────────────────────────────────────────────
  function fname(url,i){ const e=getExt(url); const se=['jpg','jpeg','png','gif','webp','svg','bmp','avif'].includes(e)?e:'jpg'; let b=null; try{const p=new URL(url).pathname.split('/').pop().split('?')[0];if(p&&p.includes('.')&&p.length>4)b=p.split('.').slice(0,-1).join('.');}catch{} if(!b)b=S.prefix+'_'+String(i+1).padStart(3,'0'); return b+'.'+se; }
  function dlOne(url,i){ chrome.runtime.sendMessage({type:'UMBRA_DOWNLOAD',url,filename:(R('f-folder')?.value||S.folder)+'/'+fname(url,i)}); showToast('⬇ Baixando…'); }
  function dlBatch(imgs){ if(!imgs.length)return; const folder=R('f-folder')?.value||S.folder; chrome.runtime.sendMessage({type:'UMBRA_DOWNLOAD_BATCH',images:imgs.map((img,i)=>({url:img.url,name:fname(img.url,i)})),folder},r=>showToast('⬇ '+(r?.count||imgs.length)+' downloads iniciados')); }

  // ── ZIP ───────────────────────────────────────────────────────────────
  const CT=(()=>{const t=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1);t[n]=c;}return t;})();
  function crc32(d){let c=0xFFFFFFFF;for(let i=0;i<d.length;i++)c=(c>>>8)^CT[(c^d[i])&0xFF];return(c^0xFFFFFFFF)>>>0;}
  async function doZip(imgs){
    if(!imgs.length)return;
    const ov=R('zip-ov'),lbl=R('zip-txt'),bar=R('zip-fill');
    ov.style.display='flex';
    const files=[];
    for(let i=0;i<imgs.length;i++){
      if(lbl)lbl.textContent='Baixando '+(i+1)+'/'+imgs.length+'…';
      if(bar)bar.style.width=((i/imgs.length)*80)+'%';
      try{const r=await fetch(imgs[i].url,{mode:'cors',credentials:'omit'});if(r.ok)files.push({name:fname(imgs[i].url,i),data:new Uint8Array(await r.arrayBuffer())});}catch{}
    }
    if(lbl)lbl.textContent='Criando ZIP…'; if(bar)bar.style.width='92%';
    const enc=new TextEncoder(),parts=[],cd=[];let off=0;
    files.forEach(f=>{const nb=enc.encode(f.name),d=f.data,crc=crc32(d);const lh=new Uint8Array(30+nb.length),lv=new DataView(lh.buffer);lv.setUint32(0,0x04034b50,true);lv.setUint16(4,20,true);[6,8,10,12].forEach(o=>lv.setUint16(o,0,true));lv.setUint32(14,crc,true);lv.setUint32(18,d.length,true);lv.setUint32(22,d.length,true);lv.setUint16(26,nb.length,true);lv.setUint16(28,0,true);lh.set(nb,30);parts.push(lh,d);const ce=new Uint8Array(46+nb.length),cv=new DataView(ce.buffer);cv.setUint32(0,0x02014b50,true);[4,6].forEach(o=>cv.setUint16(o,20,true));[8,10,12,14].forEach(o=>cv.setUint16(o,0,true));cv.setUint32(16,crc,true);cv.setUint32(20,d.length,true);cv.setUint32(24,d.length,true);cv.setUint16(28,nb.length,true);[30,32,34,36].forEach(o=>cv.setUint16(o,0,true));cv.setUint32(38,0,true);cv.setUint32(42,off,true);ce.set(nb,46);cd.push(ce);off+=lh.length+d.length;});
    const cdSz=cd.reduce((s,e)=>s+e.length,0),eocd=new Uint8Array(22),ev=new DataView(eocd.buffer);ev.setUint32(0,0x06054b50,true);[4,6].forEach(o=>ev.setUint16(o,0,true));ev.setUint16(8,files.length,true);ev.setUint16(10,files.length,true);ev.setUint32(12,cdSz,true);ev.setUint32(16,off,true);ev.setUint16(20,0,true);
    const blob=new Blob([...parts,...cd,eocd],{type:'application/zip'});const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='umbra-'+Date.now()+'.zip';document.body.appendChild(a);a.click();setTimeout(()=>{a.remove();URL.revokeObjectURL(url);},1000);
    if(bar)bar.style.width='100%'; setTimeout(()=>{ov.style.display='none';},800);
    showToast('✓ ZIP com '+files.length+' imagens!');
  }

  // ── Toast ─────────────────────────────────────────────────────────────
  function showToast(msg){ const t=R('toast');if(!t)return;t.textContent=msg;t.classList.add('on');clearTimeout(toastT);toastT=setTimeout(()=>t.classList.remove('on'),2800); }

  // ── Show / Hide ───────────────────────────────────────────────────────
  function show() {
    loadSett(() => {
      buildPanel();
      hostEl.style.display = 'block';
      hostEl.style.pointerEvents = 'all';
      visible = true;
      minimized = false;
      hostEl.style.height = '680px';
      checkAndShow();
    });
  }
  function hide() {
    if (hostEl) { hostEl.style.display = 'none'; hostEl.style.pointerEvents = 'none'; }
    visible = false;
    if (obsv) { obsv.disconnect(); obsv=null; }
  }
  function toggle() { if (visible) hide(); else show(); }

  window.__UMBRA27 = { toggle };
  chrome.runtime.onMessage.addListener(msg => { if (msg.type==='UMBRA_TOGGLE') toggle(); });
  show();

// ── CSS ── (lives in Shadow DOM, zero leakage to page)
const CSS = `
:host { all: initial; }
* { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }

/* The panel fills the host element 100% */
#panel {
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: column;
  border-radius: 12px;
  overflow: hidden;
  font-size: 13px;
  line-height: 1.4;
  color: #e2e8f0;
  background: #0e0e18;
  border: 1.5px solid rgba(139,92,246,.5);
  box-shadow: 0 24px 64px rgba(0,0,0,.85);
}

/* ── Header ── */
#hdr {
  height: 46px; min-height: 46px; flex-shrink: 0;
  display: flex; align-items: center; justify-content: space-between;
  padding: 0 10px;
  background: #12121f;
  border-bottom: 1px solid rgba(139,92,246,.22);
  cursor: grab; user-select: none;
}
#hdr:active { cursor: grabbing; }
#hdr-l { display: flex; align-items: center; gap: 8px; min-width: 0; flex: 1; }
#logo {
  width: 26px; height: 26px; flex-shrink: 0;
  background: linear-gradient(135deg,#8b5cf6,#6d28d9);
  border-radius: 7px; display: flex; align-items: center; justify-content: center;
}
#t-title { font-size: 13px; font-weight: 700; color: #f1f5f9; }
.lic-dot {
  width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0;
}
.lic-dot.active { background: #22c55e; box-shadow: 0 0 6px #22c55e; }
.lic-dot.locked { background: #ef4444; }
#hdr-r { display: flex; align-items: center; gap: 3px; flex-shrink: 0; }
.hbtn {
  width: 26px; height: 26px; border: none; border-radius: 6px;
  background: rgba(255,255,255,.07); color: #94a3b8;
  font-size: 14px; line-height: 1; cursor: pointer;
  display: flex; align-items: center; justify-content: center; padding: 0;
  transition: background .15s, color .15s;
}
.hbtn:hover { background: rgba(139,92,246,.3); color: #c4b5fd; }
.hbtn.red:hover { background: rgba(239,68,68,.25); color: #f87171; }

/* ── License view ── */
#lic-view {
  flex: 1; display: none; flex-direction: column;
  align-items: center; justify-content: center; padding: 28px 24px;
  background: #0e0e18;
}
#lic-box {
  width: 100%; max-width: 320px;
  display: flex; flex-direction: column; align-items: center; gap: 14px;
}
#lic-icon { font-size: 40px; line-height: 1; }
#lic-box h2 { font-size: 17px; font-weight: 700; color: #f1f5f9; text-align: center; }
#lic-box > p { font-size: 12px; color: #64748b; text-align: center; line-height: 1.6; }
#lic-key {
  width: 100%;
  background: rgba(255,255,255,.07);
  border: 1.5px solid rgba(255,255,255,.12);
  border-radius: 8px; color: #e2e8f0;
  padding: 11px 14px; font-size: 13px;
  font-family: 'Courier New', monospace;
  letter-spacing: 1.5px; outline: none;
  transition: border-color .2s; text-align: center;
}
#lic-key:focus { border-color: #8b5cf6; }
#lic-key::placeholder { color: #374151; font-family: inherit; letter-spacing: 0; }
#lic-ok {
  width: 100%; padding: 12px;
  background: linear-gradient(135deg,#8b5cf6,#7c3aed);
  border: none; border-radius: 8px;
  color: white; font-size: 13px; font-weight: 700;
  cursor: pointer; font-family: inherit;
  transition: opacity .2s, transform .15s;
}
#lic-ok:hover:not(:disabled) { opacity: .88; transform: translateY(-1px); }
#lic-ok:disabled { opacity: .45; cursor: not-allowed; }
#lic-err { font-size: 11px; color: #f87171; text-align: center; min-height: 14px; line-height: 1.4; }
#lic-link { font-size: 11px; color: #8b5cf6; text-decoration: none; }
#lic-link:hover { color: #a78bfa; text-decoration: underline; }

/* ── App view ── */
#app-view {
  flex: 1; display: none; flex-direction: column;
  overflow: hidden; position: relative; min-height: 0;
}

/* ── Filters ── */
#filters {
  flex-shrink: 0; padding: 8px 10px;
  background: #0a0a14;
  border-bottom: 1px solid rgba(255,255,255,.06);
  display: flex; flex-direction: column; gap: 6px;
}
.row { display: flex; align-items: center; gap: 5px; }
.lbl { font-size: 9px; font-weight: 700; color: #4b5563; text-transform: uppercase; letter-spacing: .5px; min-width: 28px; flex-shrink: 0; }
.ml  { margin-left: 4px; }
input, select {
  background: rgba(255,255,255,.07); border: 1px solid rgba(255,255,255,.1);
  border-radius: 5px; color: #e2e8f0; padding: 4px 7px;
  font-size: 11px; font-family: inherit; outline: none; height: 26px;
}
input { flex: 1; }
input.narrow { flex: none; width: 52px; }
input.short  { flex: none; width: 68px; }
input:focus, select:focus { border-color: rgba(139,92,246,.6); }
input::placeholder { color: #374151; }
select { cursor: pointer; }
select option { background: #1a1a2e; color: #e2e8f0; }
.x { color: #4b5563; font-size: 11px; flex-shrink: 0; }

/* ── Toolbar ── */
#toolbar {
  flex-shrink: 0; display: flex; align-items: center;
  justify-content: space-between; padding: 5px 10px;
  border-bottom: 1px solid rgba(255,255,255,.05);
}
#t-count { font-size: 11px; font-weight: 700; color: #8b5cf6; }
#t-btns  { display: flex; align-items: center; gap: 2px; }
.vb {
  width: 26px; height: 22px; border: none; border-radius: 4px;
  background: none; color: #4b5563; font-size: 13px; cursor: pointer;
  display: flex; align-items: center; justify-content: center; padding: 0;
}
.vb:hover { background: rgba(139,92,246,.15); color: #c4b5fd; }
.vb.on    { background: rgba(139,92,246,.18); color: #8b5cf6; }
.vd { width: 1px; height: 14px; background: rgba(255,255,255,.1); margin: 0 3px; }
.tb { border: none; border-radius: 4px; background: none; color: #4b5563; font-size: 10px; padding: 3px 6px; cursor: pointer; white-space: nowrap; }
.tb:hover { background: rgba(139,92,246,.15); color: #c4b5fd; }
.red-tb { font-size: 13px; padding: 2px 5px; }
.red-tb:hover { color: #f87171 !important; background: rgba(239,68,68,.1) !important; }

/* ── Scroll ── */
#scroll { flex: 1; overflow-y: auto; overflow-x: hidden; padding: 8px; min-height: 0; }
#scroll::-webkit-scrollbar { width: 4px; }
#scroll::-webkit-scrollbar-thumb { background: rgba(139,92,246,.35); border-radius: 2px; }

/* Loading / Empty */
#t-load { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 10px; padding: 50px 20px; color: #4b5563; font-size: 12px; }
.spin { width: 26px; height: 26px; border: 2px solid rgba(139,92,246,.2); border-top-color: #8b5cf6; border-radius: 50%; animation: sp .65s linear infinite; }
@keyframes sp { to { transform: rotate(360deg); } }
#t-empty { display: none; flex-direction: column; align-items: center; justify-content: center; gap: 10px; padding: 40px 20px; color: #4b5563; font-size: 12px; text-align: center; line-height: 1.6; }

/* Grid */
#grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 6px; }
#grid.c2  { grid-template-columns: repeat(2,1fr); }
#grid.lst { grid-template-columns: 1fr; }

/* Card */
.card {
  position: relative; border-radius: 7px; overflow: hidden;
  background: rgba(255,255,255,.05); border: 1.5px solid rgba(255,255,255,.08);
  cursor: pointer; aspect-ratio: 1/1; transition: border-color .15s, transform .12s;
}
.card:hover { border-color: rgba(139,92,246,.55); transform: translateY(-1px); }
.card.sel   { border-color: #8b5cf6; box-shadow: 0 0 0 2px rgba(139,92,246,.2); }
.th { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; display: block; pointer-events: none; }
.ov { position: absolute; inset: 0; background: rgba(0,0,0,.65); display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 4px; opacity: 0; transition: opacity .15s; z-index: 2; }
.card:hover .ov { opacity: 1; }
.dlb { background: rgba(139,92,246,.9); border: none; color: #fff; border-radius: 5px; padding: 4px 10px; font-size: 11px; font-weight: 700; cursor: pointer; font-family: inherit; }
.dlb:hover { background: #7c3aed; }
.mt { font-size: 9px; color: rgba(255,255,255,.7); }
.ck { position: absolute; top: 5px; left: 5px; width: 16px; height: 16px; border-radius: 4px; background: rgba(0,0,0,.5); border: 1.5px solid rgba(255,255,255,.4); display: flex; align-items: center; justify-content: center; pointer-events: none; z-index: 3; }
.ck svg { display: none; }
.card.sel .ck { background: #8b5cf6; border-color: #8b5cf6; }
.card.sel .ck svg { display: block; }
.uu, .ud { display: none; }

/* List mode */
#grid.lst .card { aspect-ratio: unset; height: 54px; display: flex; align-items: center; gap: 8px; padding: 5px 8px; }
#grid.lst .th { position: static; width: 42px; height: 42px; flex-shrink: 0; border-radius: 5px; object-fit: cover; }
#grid.lst .ov { display: none; }
#grid.lst .uu { display: block; font-size: 9.5px; color: #6b7280; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; flex: 1; min-width: 0; }
#grid.lst .ud { display: block; font-size: 9px; color: #4b5563; flex-shrink: 0; }
#grid.lst .ck { position: static; flex-shrink: 0; margin-left: auto; }

/* Footer */
#footer { flex-shrink: 0; display: flex; gap: 6px; padding: 8px 10px; background: #09090f; border-top: 1px solid rgba(255,255,255,.06); }
.fb { flex: 1; padding: 7px 6px; border: none; border-radius: 7px; font-size: 11px; font-weight: 700; cursor: pointer; font-family: inherit; transition: opacity .15s, transform .12s; }
.fb:disabled { opacity: .35; cursor: not-allowed; }
.fb.p { background: linear-gradient(135deg,#8b5cf6,#7c3aed); color: #fff; }
.fb.p:not(:disabled):hover { transform: translateY(-1px); }
.fb.s { background: rgba(255,255,255,.08); color: #94a3b8; border: 1px solid rgba(255,255,255,.1); }
.fb.z { background: rgba(16,185,129,.13); color: #34d399; border: 1px solid rgba(16,185,129,.22); flex: none; padding: 7px 11px; }
.fb.z:not(:disabled):hover { background: rgba(16,185,129,.22); }

/* Resize handle */
#rzr { position: absolute; bottom: 0; right: 0; width: 18px; height: 18px; cursor: nwse-resize; z-index: 10; }
#rzr::after { content: ''; position: absolute; bottom: 4px; right: 4px; width: 8px; height: 8px; border-right: 2px solid rgba(139,92,246,.5); border-bottom: 2px solid rgba(139,92,246,.5); }

/* ZIP overlay */
#zip-ov { position: absolute; inset: 0; background: rgba(8,8,16,.92); display: none; flex-direction: column; align-items: center; justify-content: center; gap: 10px; z-index: 20; }
#zip-ov span { font-size: 12px; color: #e2e8f0; }
#zip-bar { width: 180px; height: 5px; background: rgba(139,92,246,.2); border-radius: 3px; overflow: hidden; }
#zip-fill { height: 100%; width: 0; background: #8b5cf6; transition: width .2s; }

/* Preview tooltip */
#pv { position: fixed; pointer-events: none; z-index: 2147483647; display: none; border-radius: 8px; overflow: hidden; border: 1px solid rgba(139,92,246,.5); box-shadow: 0 16px 40px rgba(0,0,0,.7); max-width: 240px; max-height: 240px; background: #0e0e18; }
#pv img { display: block; max-width: 240px; max-height: 240px; object-fit: contain; }

/* Toast */
#toast { position: fixed; bottom: 18px; right: 18px; background: #1a1a2e; border: 1px solid rgba(139,92,246,.4); color: #e2e8f0; font-size: 12px; font-family: inherit; padding: 8px 14px; border-radius: 8px; box-shadow: 0 8px 24px rgba(0,0,0,.5); pointer-events: none; opacity: 0; transform: translateY(6px); transition: opacity .2s, transform .2s; z-index: 2147483647; white-space: nowrap; }
#toast.on { opacity: 1; transform: translateY(0); }
`;

})();
