// UMBRA FLOW v2.4.0 — App Window JS
'use strict';

const $ = id => document.getElementById(id);
const FLOW_URL = 'https://labs.google/fx/tools/flow';

const MAX_BATCH = 4; // máximo de prompts enviados por vez antes do delay

let isRunning   = false;
let shouldStop  = false;
let frameImages = []; // { file, dataUrl, name }
let personagens = []; // { id, nome, dataUrl, slot, timestamp }
let stats = { enviados: 0, gerados: 0, falhou: 0, baixados: 0, total: 0 };

const delay = ms => new Promise(r => setTimeout(r, ms));

// ── Config padrão ─────────────────────────────
let cfg = {
  mvideo:      'Veo 3.1 - Fast',
  mimagem:     'Nano Banana',
  orientacao:  '16:9',
  qtd:         'x1',
  delay:       5000,
  prewait:     60000,
  vPasta:      'UmbraVideos',
  fPasta:      'UmbraFrameVideos',
  iPasta:      'UmbraImagens',
  vSimultaneos: 1,
  vAutodownload: true,
  vBackground:   true,
  fAutodownload: true,
  fBackground:   true,
  iAutodownload: true,
};

// ── Tabs ──────────────────────────────────────
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.pane').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    $('pane-' + tab.dataset.tab)?.classList.add('active');
  });
});

// ── Status ────────────────────────────────────
function setStatus(msg, tipo) {
  $('status-dot').className = 'dot ' + (tipo || 'idle');
  $('status-text').textContent = (msg || '').substring(0, 90);
}

// ── Verificar Flow ────────────────────────────
function verificarFlow() {
  return new Promise(resolve => {
    chrome.tabs.query({ url: 'https://labs.google/fx/tools/flow*' }, tabs => {
      resolve(!!(tabs && tabs.length > 0));
    });
  });
}

async function updateStatus() {
  const ok = await verificarFlow();
  setStatus(ok ? '✅ Veo 3 Flow detectado!' : '⚠ Flow não detectado', ok ? 'ok' : 'warn');
}

// ── Garantir Flow ─────────────────────────────
function garantirFlow() {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ type: 'ENSURE_FLOW' }, response => {
      if (chrome.runtime.lastError) { resolve({ ok: false }); return; }
      resolve(response || { ok: false });
    });
  });
}

// ── Enviar para Flow ──────────────────────────
function enviarParaFlow(payload) {
  return new Promise(resolve => {
    try {
      chrome.runtime.sendMessage({ type: 'TO_FLOW', payload }, response => {
        if (chrome.runtime.lastError) {
          resolve({ ok: false, err: chrome.runtime.lastError.message });
          return;
        }
        resolve(response || { ok: false });
      });
    } catch(e) { resolve({ ok: false, err: e.message }); }
  });
}

// ── Parse de prompts ──────────────────────────
function parsePrompts(raw) {
  if (!raw || !raw.trim()) return [];
  if (raw.includes(';')) return raw.split(';').map(s => s.trim()).filter(Boolean);
  return raw.split(/\n\s*\n/).map(s => s.trim()).filter(Boolean);
}

// ── Fila visual ───────────────────────────────
function renderFila(queueId, prompts, idx) {
  const q = $(queueId);
  if (!q) return;
  q.style.display = 'flex';
  q.innerHTML = '';
  prompts.forEach((p, i) => {
    const item = document.createElement('div');
    item.className = 'qi' + (i < idx ? ' done' : i === idx ? ' active' : '');
    item.innerHTML = `<div class="qdot"></div><div class="qtxt">${p.slice(0,56)}${p.length>56?'…':''}</div>`;
    q.appendChild(item);
  });
  q.querySelector('.qi.active')?.scrollIntoView({ block: 'nearest' });
}

function updateStats() {
  $('stat-enviados').textContent = stats.enviados;
  $('stat-gerados').textContent  = stats.gerados;
  $('stat-falhou').textContent   = stats.falhou;
  $('stat-baixados').textContent = stats.baixados;
}

function updateProg(prefixo, current, total) {
  const block = $(prefixo + 'prog-block');
  const fill  = $(prefixo + 'prog-fill');
  const label = $(prefixo + 'prog-label');
  const count = $(prefixo + 'prog-count');
  if (!block) return;
  block.style.display = 'flex';
  const pct = total > 0 ? Math.round((current / total) * 100) : 0;
  if (fill)  fill.style.width    = pct + '%';
  if (label) label.textContent   = current >= total ? '✅ Concluído!' : `Disparando ${current+1} de ${total}...`;
  if (count) count.textContent   = `${current}/${total}`;
}

// ═══════════════════════════════════════════════
// PROCESSAR FILA — máximo 4 prompts por lote
// Envia 4, aguarda delay configurado, envia mais 4
// ═══════════════════════════════════════════════
async function processarFila(tipo, raw, progPrefix, queueId, btnId, btnStopId) {
  if (isRunning) { setStatus('⚠ Já está processando!', 'warn'); return; }

  const prompts = parsePrompts(raw);
  if (!prompts.length) { setStatus('⚠ Nenhum prompt encontrado!', 'warn'); return; }

  isRunning   = true;
  shouldStop  = false;
  stats = { enviados: 0, gerados: 0, falhou: 0, baixados: 0, total: prompts.length };

  if ($('stats-row')) $('stats-row').style.display = 'flex';
  if ($(btnId))       $(btnId).disabled = true;
  if ($(btnStopId))   $(btnStopId).style.display = 'block';
  updateStats();

  // Garante Flow aberto
  setStatus('🔄 Verificando Flow...', 'run');
  const flowResult = await garantirFlow();
  if (flowResult.nova) {
    setStatus('🔄 Aguardando Flow carregar...', 'run');
    await delay(4000);
  }

  const config = {
    tipo,
    modelo:      tipo === 'imagem' ? cfg.mimagem : cfg.mvideo,
    qtd:         cfg.qtd,
    orientacao:  cfg.orientacao,
    autoConfig:  true,
    maxWaitMs:   180000,
    pasta:       tipo === 'video' ? cfg.vPasta : tipo === 'frame' ? cfg.fPasta : cfg.iPasta,
    autoDownload: tipo === 'video' ? cfg.vAutodownload : cfg.fAutodownload,
    personagens: personagens.filter(p => p.nome).map(p => ({ nome: p.nome, slot: p.slot, dataUrl: p.dataUrl })),
  };

  // ── Envio em lotes de MAX_BATCH (4) ──────────
  for (let i = 0; i < prompts.length; i++) {
    if (shouldStop) { setStatus('⏹ Cancelado', 'warn'); break; }

    renderFila(queueId, prompts, i);
    updateProg(progPrefix, i, prompts.length);

    const loteNum   = Math.floor(i / MAX_BATCH) + 1;
    const posNoLote = (i % MAX_BATCH) + 1;
    setStatus(`⚡ Lote ${loteNum} — prompt ${posNoLote}/${Math.min(MAX_BATCH, prompts.length - Math.floor(i/MAX_BATCH)*MAX_BATCH)} (total ${i+1}/${prompts.length})`, 'run');

    // Inclui imagem de frame se disponível
    const payloadConfig = { ...config };
    if (tipo === 'frame' && frameImages[i]) {
      payloadConfig.frameImageDataUrl = frameImages[i].dataUrl;
      payloadConfig.frameImageName    = frameImages[i].name;
    }

    await enviarParaFlow({
      type:   'DISPARAR',
      tipo,
      prompt: prompts[i],
      index:  i + 1,
      config: payloadConfig,
    });

    stats.enviados++;
    stats.gerados++;
    updateStats();

    const ehUltimoPrompt     = i === prompts.length - 1;
    const ehUltimoDoLote     = (i + 1) % MAX_BATCH === 0;
    const temProximoPrompt   = i < prompts.length - 1;

    if (!ehUltimoPrompt && temProximoPrompt && !shouldStop) {
      if (ehUltimoDoLote) {
        // ── Fim de lote: delay entre lotes (maior) ──
        const delayLote = cfg.delay * 2; // delay dobrado entre lotes
        setStatus(`⏳ Lote ${loteNum} completo (${MAX_BATCH} prompts). Aguardando ${delayLote/1000}s...`, 'run');
        for (let t = 0; t < delayLote && !shouldStop; t += 500) {
          const rest = Math.ceil((delayLote - t) / 1000);
          setStatus(`⏳ Próximo lote em ${rest}s... (${i+1}/${prompts.length} enviados)`, 'run');
          await delay(500);
        }
      } else {
        // ── Dentro do lote: delay normal ──
        for (let t = 0; t < cfg.delay && !shouldStop; t += 500) {
          const rest = Math.ceil((cfg.delay - t) / 1000);
          setStatus(`⏳ Próximo em ${rest}s... (${i+1}/${prompts.length})`, 'run');
          await delay(500);
        }
      }
    }
  }

  // ── Download automático após tudo ────────────
  if (!shouldStop && config.autoDownload) {
    setStatus(`⏳ Aguardando ${cfg.prewait/1000}s para os vídeos gerarem...`, 'run');
    await delay(cfg.prewait);
    setStatus('📥 Iniciando downloads...', 'run');
    await enviarParaFlow({
      type:   'DISPARAR',
      tipo:   'download',
      index:  1,
      config: { pasta: config.pasta, count: prompts.length, maxWaitMs: 300000 },
    });
  }

  if (!shouldStop) {
    renderFila(queueId, prompts, prompts.length);
    updateProg(progPrefix, prompts.length, prompts.length);
    setStatus(`✅ ${prompts.length} prompts processados!`, 'ok');
  }

  isRunning = false;
  if ($(btnId))     $(btnId).disabled = false;
  if ($(btnStopId)) $(btnStopId).style.display = 'none';
}

// ═══════════════════════════════════════════════
// FRAME IMAGES — Upload e Matching
// ═══════════════════════════════════════════════
function renderFrameGrid() {
  const grid = $('frame-img-grid');
  const matchBox  = $('frame-matching');
  const matchList = $('frame-matching-list');
  if (!grid) return;

  grid.innerHTML = '';
  frameImages.forEach((img, i) => {
    const thumb = document.createElement('div');
    thumb.className = 'img-thumb';
    thumb.innerHTML = `
      <img src="${img.dataUrl}" alt="Frame ${i+1}">
      <span class="img-num">${i+1}</span>
      <button class="img-del" data-idx="${i}">✕</button>
    `;
    thumb.querySelector('.img-del').addEventListener('click', () => {
      frameImages.splice(i, 1);
      renderFrameGrid();
    });
    grid.appendChild(thumb);
  });

  // Matching automático
  if (frameImages.length > 0 && matchBox && matchList) {
    matchBox.style.display = 'block';
    matchList.innerHTML = frameImages.map((img, i) =>
      `<div class="matching-item">PROMPT ${i+1} → <span>Imagem ${i+1} (frame inicial)</span></div>`
    ).join('');
  } else if (matchBox) {
    matchBox.style.display = 'none';
  }
}

$('btn-upload-frames')?.addEventListener('click', () => {
  $('input-frames').click();
});

$('input-frames')?.addEventListener('change', (e) => {
  const files = Array.from(e.target.files || []);
  files.forEach(file => {
    const reader = new FileReader();
    reader.onload = (ev) => {
      frameImages.push({ file, dataUrl: ev.target.result, name: file.name });
      renderFrameGrid();
    };
    reader.readAsDataURL(file);
  });
  e.target.value = ''; // reset para permitir re-selecionar
});

// ── Botões ────────────────────────────────────
$('btn-processar')?.addEventListener('click', () => {
  processarFila('video', $('txt-video').value, '', 'queue', 'btn-processar', 'btn-parar');
});
$('btn-frame')?.addEventListener('click', () => {
  processarFila('frame', $('txt-frame').value, 'f-', 'f-queue', 'btn-frame', 'btn-frame-parar');
});
$('btn-imagem')?.addEventListener('click', () => {
  processarFila('imagem', $('txt-imagem').value, 'i-', 'i-queue', 'btn-imagem', null);
});
$('btn-parar')?.addEventListener('click',       () => { shouldStop = true; setStatus('⏹ Parando...', 'warn'); });
$('btn-frame-parar')?.addEventListener('click', () => { shouldStop = true; setStatus('⏹ Parando...', 'warn'); });
$('btn-limpar')?.addEventListener('click', () => {
  $('txt-video').value = $('txt-frame').value = $('txt-imagem').value = '';
  frameImages = [];
  renderFrameGrid();
  chrome.storage.local.remove('umbraPrompts');
  setStatus('🗑 Limpo', 'idle');
});

// ── Feedback em tempo real do content script ──
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'LOG') {
    const cor = msg.logType === 'error' ? 'err' : msg.logType === 'success' ? 'ok' : msg.logType === 'warn' ? 'warn' : 'run';
    setStatus((msg.msg || '').substring(0, 90), cor);
    // Atualiza baixados se download confirmado
    if ((msg.msg || '').includes('✓') && (msg.msg || '').includes('.mp4')) {
      stats.baixados++;
      updateStats();
    }
  }
  if (msg.type === 'PROGRESS') {
    ['', 'f-', 'i-'].forEach(p => {
      const fill  = $(p + 'prog-fill');
      const label = $(p + 'prog-label');
      const block = $(p + 'prog-block');
      if (block && block.style.display !== 'none') {
        if (fill)  fill.style.width  = (msg.pct || 0) + '%';
        if (label) label.textContent = msg.label || '';
      }
    });
  }
  if (msg.type === 'STEP') {
    setStatus(msg.step || '', 'run');
  }
  if (msg.type === 'VIDEO_DOWNLOADED') {
    stats.baixados++;
    updateStats();
  }
});

// ── Config auto-save ──────────────────────────
function salvarConfig() {
  cfg.mvideo      = $('cfg-mvideo')?.value     || cfg.mvideo;
  cfg.mimagem     = $('cfg-mimagem')?.value    || cfg.mimagem;
  cfg.orientacao  = $('cfg-orientacao')?.value || cfg.orientacao;
  cfg.qtd         = $('cfg-qtd')?.value        || cfg.qtd;
  cfg.delay       = parseInt($('cfg-delay')?.value)   || cfg.delay;
  cfg.prewait     = parseInt($('cfg-prewait')?.value) || cfg.prewait;
  cfg.vPasta      = $('v-pasta')?.value        || cfg.vPasta;
  cfg.fPasta      = $('f-pasta')?.value        || cfg.fPasta;
  cfg.iPasta      = $('i-pasta')?.value        || cfg.iPasta;
  cfg.vSimultaneos  = parseInt($('v-simultaneos')?.value) || 1;
  cfg.vAutodownload = $('v-autodownload')?.checked ?? true;
  cfg.vBackground   = $('v-background')?.checked   ?? true;
  cfg.fAutodownload = $('f-autodownload')?.checked ?? true;
  cfg.fBackground   = $('f-background')?.checked   ?? true;
  cfg.iAutodownload = $('i-autodownload')?.checked ?? true;
  chrome.storage.local.set({ umbraCfg: cfg });
}

function salvarPrompts() {
  chrome.storage.local.set({
    umbraPrompts: {
      video:  $('txt-video')?.value  || '',
      frame:  $('txt-frame')?.value  || '',
      imagem: $('txt-imagem')?.value || '',
    }
  });
}

function carregarEstado() {
  chrome.storage.local.get(['umbraCfg', 'umbraPrompts', 'umbraPersonagens'], data => {
    if (data.umbraCfg) {
      cfg = { ...cfg, ...data.umbraCfg };
      if ($('cfg-mvideo'))     $('cfg-mvideo').value     = cfg.mvideo;
      if ($('cfg-mimagem'))    $('cfg-mimagem').value    = cfg.mimagem;
      if ($('cfg-orientacao')) $('cfg-orientacao').value = cfg.orientacao;
      if ($('cfg-qtd'))        $('cfg-qtd').value        = cfg.qtd;
      if ($('cfg-delay'))      $('cfg-delay').value      = cfg.delay;
      if ($('cfg-prewait'))    $('cfg-prewait').value    = cfg.prewait;
      if ($('v-pasta'))        $('v-pasta').value        = cfg.vPasta;
      if ($('f-pasta'))        $('f-pasta').value        = cfg.fPasta;
      if ($('i-pasta'))        $('i-pasta').value        = cfg.iPasta;
      if ($('v-simultaneos'))  $('v-simultaneos').value  = cfg.vSimultaneos;
      if ($('v-autodownload')) $('v-autodownload').checked = cfg.vAutodownload;
      if ($('v-background'))   $('v-background').checked   = cfg.vBackground;
      if ($('f-autodownload')) $('f-autodownload').checked = cfg.fAutodownload;
      if ($('f-background'))   $('f-background').checked   = cfg.fBackground;
      if ($('i-autodownload')) $('i-autodownload').checked = cfg.iAutodownload;
    }
    if (data.umbraPrompts) {
      if ($('txt-video'))  $('txt-video').value  = data.umbraPrompts.video  || '';
      if ($('txt-frame'))  $('txt-frame').value  = data.umbraPrompts.frame  || '';
      if ($('txt-imagem')) $('txt-imagem').value = data.umbraPrompts.imagem || '';
    }
    if (data.umbraPersonagens && Array.isArray(data.umbraPersonagens)) {
      personagens = data.umbraPersonagens;
      renderPersonagens();
    }
  });
}

// Listeners de mudança
['cfg-mvideo','cfg-mimagem','cfg-orientacao','cfg-qtd','cfg-delay','cfg-prewait',
 'v-pasta','f-pasta','i-pasta','v-simultaneos',
 'v-autodownload','v-background','f-autodownload','f-background','i-autodownload'
].forEach(id => $(id)?.addEventListener('change', salvarConfig));

['txt-video','txt-frame','txt-imagem'].forEach(id => $(id)?.addEventListener('input', salvarPrompts));

// ═══════════════════════════════════════════════
// PERSONAGENS — Rastrear, Nomear, Salvar
// ═══════════════════════════════════════════════

function renderPersonagens() {
  const list  = $('pers-list');
  const empty = $('pers-empty');
  const count = $('pers-count');
  if (!list) return;

  if (count) count.textContent = personagens.length;

  if (personagens.length === 0) {
    if (empty) empty.style.display = 'block';
    // remove cards antigos
    list.querySelectorAll('.pers-card').forEach(c => c.remove());
    return;
  }
  if (empty) empty.style.display = 'none';
  list.querySelectorAll('.pers-card').forEach(c => c.remove());

  personagens.forEach((p, i) => {
    const card = document.createElement('div');
    card.className = 'pers-card';
    const thumb = p.dataUrl
      ? `<img class="pers-thumb" src="${p.dataUrl}" alt="Personagem ${i+1}">`
      : `<div class="pers-thumb-placeholder">👤</div>`;

    card.innerHTML = `
      ${thumb}
      <div class="pers-info">
        <input class="pers-name-input" type="text" placeholder="Nome do personagem..." value="${p.nome || ''}" data-idx="${i}">
        <div class="pers-meta">Capturado: ${new Date(p.timestamp).toLocaleTimeString('pt-BR')}</div>
      </div>
      <span class="pers-slot">SLOT ${i + 1}</span>
      <button class="pers-del-btn" data-idx="${i}" title="Excluir">✕</button>
    `;

    // Salva nome ao digitar
    card.querySelector('.pers-name-input').addEventListener('input', e => {
      personagens[parseInt(e.target.dataset.idx)].nome = e.target.value;
      salvarPersonagens();
      if ($('pers-count')) $('pers-count').textContent = personagens.length;
    });

    // Excluir individual
    card.querySelector('.pers-del-btn').addEventListener('click', e => {
      const idx = parseInt(e.currentTarget.dataset.idx);
      personagens.splice(idx, 1);
      salvarPersonagens();
      renderPersonagens();
    });

    list.appendChild(card);
  });
}

// Rastrear — captura thumbnails abertas no Flow
$('btn-rastrear')?.addEventListener('click', async () => {
  setStatus('📡 Rastreando imagens no Flow...', 'run');
  $('btn-rastrear').disabled = true;

  // Pede ao content script para capturar as imagens visíveis no dropdown
  const res = await enviarParaFlow({ type: 'RASTREAR_PERSONAGENS' });

  if (res && res.ok && res.imagens && res.imagens.length > 0) {
    res.imagens.forEach((imgData, i) => {
      // Evita duplicatas pelo src
      const jaExiste = personagens.some(p => p.src === imgData.src);
      if (!jaExiste && personagens.length < 3) {
        // Usa o label capturado do DOM como sugestão de nome
        const nomeSugerido = imgData.label || '';
        personagens.push({
          id:        Date.now() + i,
          nome:      nomeSugerido,
          dataUrl:   imgData.dataUrl || null,
          src:       imgData.src || '',
          slot:      personagens.length + 1,
          timestamp: Date.now(),
        });
      }
    });
    salvarPersonagens();
    renderPersonagens();
    setStatus(`✅ ${res.imagens.length} personagem(ns) rastreado(s)!`, 'ok');
  } else {
    setStatus('⚠ Nenhuma imagem encontrada. Abra o dropdown no Flow primeiro.', 'warn');
  }

  $('btn-rastrear').disabled = false;
});

// Identificar automaticamente
$('btn-identificar')?.addEventListener('click', async () => {
  if (!personagens.length) {
    setStatus('⚠ Rastreie personagens primeiro!', 'warn');
    return;
  }
  setStatus('🔍 Identificando personagens...', 'run');

  // Tenta identificar pelo nome do arquivo ou metadata da imagem
  personagens.forEach((p, i) => {
    if (!p.nome && p.src) {
      // Extrai nome do src (ex: "Maria_closeup.jpg" → "Maria")
      const match = p.src.match(/([^/\\?#]+)\.(jpg|jpeg|png|webp)/i);
      if (match) {
        const rawName = match[1].replace(/[_\-]/g, ' ').replace(/\d+/g, '').trim();
        if (rawName.length > 1) p.nome = rawName;
      }
    }
    if (!p.nome) p.nome = `Personagem ${i + 1}`;
  });

  salvarPersonagens();
  renderPersonagens();
  setStatus('✅ Personagens identificados!', 'ok');
});

// Limpar nomes
$('btn-limpar-nomes')?.addEventListener('click', () => {
  personagens.forEach(p => { p.nome = ''; });
  salvarPersonagens();
  renderPersonagens();
  setStatus('✏️ Nomes limpos', 'idle');
});

// Deletar tudo
$('btn-deletar-tudo')?.addEventListener('click', () => {
  if (!personagens.length) return;
  personagens = [];
  salvarPersonagens();
  renderPersonagens();
  setStatus('🗑 Todos os personagens removidos', 'idle');
});

function salvarPersonagens() {
  chrome.storage.local.set({ umbraPersonagens: personagens.map(p => ({
    id: p.id, nome: p.nome, src: p.src, slot: p.slot, timestamp: p.timestamp
    // não salva dataUrl (muito grande para storage)
  }))});
}

// ═══════════════════════════════════════════════
// LICENÇA — verifica antes de liberar o app
// ═══════════════════════════════════════════════
(function iniciarLicenca() {
  const overlay = $('licenca-overlay');
  const btnAtivar = $('lic-btn');
  const inputChave = $('lic-input');
  const msgErro = $('lic-msg');

  function mostrarOverlay() {
    overlay.style.display = 'flex';
  }

  function esconderOverlay() {
    overlay.style.display = 'none';
  }

  // Verifica status ao abrir a janela
  chrome.runtime.sendMessage({ action: 'GET_STATUS' }, resp => {
    if (resp && resp.valido) {
      esconderOverlay();
    } else {
      mostrarOverlay();
    }
  });

  // Botão ativar
  btnAtivar?.addEventListener('click', () => {
    const chave = (inputChave?.value || '').trim().toUpperCase();
    if (!chave) { if (msgErro) msgErro.textContent = 'Insira uma chave válida.'; return; }

    if (btnAtivar) { btnAtivar.disabled = true; btnAtivar.textContent = 'Validando...'; }
    if (msgErro) msgErro.textContent = '';

    chrome.runtime.sendMessage({ action: 'ACTIVATE', chave }, resp => {
      if (btnAtivar) { btnAtivar.disabled = false; btnAtivar.textContent = 'Ativar Licença'; }
      if (resp && resp.valido) {
        esconderOverlay();
      } else {
        if (msgErro) msgErro.textContent = resp?.motivo || 'Chave inválida ou limite atingido.';
      }
    });
  });

  // Enter no campo também ativa
  inputChave?.addEventListener('keydown', e => {
    if (e.key === 'Enter') btnAtivar?.click();
  });

  // Foco visual no input
  inputChave?.addEventListener('focus', () => {
    if (inputChave) inputChave.style.borderColor = '#ff7a00';
  });
  inputChave?.addEventListener('blur', () => {
    if (inputChave) inputChave.style.borderColor = '#333';
  });
})();

// ── Init ──────────────────────────────────────
carregarEstado();
updateStatus();
garantirFlow();
