# UMBRA FLOW v2.2.0
**Disparo automático de prompts no Google Flow — by Umbra Hub**

---

## INSTALAÇÃO

1. Extraia a pasta `umbra-flow`
2. Abra o Chrome → `chrome://extensions/`
3. Ative **Modo desenvolvedor** (canto superior direito)
4. Clique em **Carregar sem compactação**
5. Selecione a pasta `umbra-flow`

---

## CRIAR ATALHO NA ÁREA DE TRABALHO (Windows)

Depois de instalar, crie um atalho para abrir direto como um app:

### Método 1 — Chrome (recomendado)
1. No Chrome, abra `chrome://apps/`
2. Clique com botão direito em **Umbra Flow**
3. Selecione **Criar atalho...**
4. Marque **Área de trabalho** → OK
5. O atalho aparece na sua área de trabalho!

### Método 2 — Atalho manual
1. Clique com botão direito na área de trabalho → Novo → Atalho
2. No campo de local, cole:
   ```
   "C:\Program Files\Google\Chrome\Application\chrome.exe" --app=chrome-extension://ID_DA_EXTENSAO/app.html
   ```
   *(substitua `ID_DA_EXTENSAO` pelo ID que aparece em chrome://extensions/)*
3. Nome: **Umbra Flow**
4. Clique com botão direito no atalho → Propriedades → Alterar ícone

---

## COMO USAR

1. Clique no ícone 🌑 na barra do Chrome **OU** use o atalho da área de trabalho
2. A janela abre automaticamente (360×640px, sem barra de endereços)
3. O **Google Flow abre em segundo plano** automaticamente
4. Cole seus prompts na aba **Vídeo**, **Frame** ou **Imagem**
5. Clique em **▶ Processar Prompts**

### Formato dos prompts (Vídeo/Imagem)
```
PROMPT 1 [1]: Descrição com elemento 1...

PROMPT 2 [1, 2]: Descrição com elementos 1 e 2...
```
- Separe com `;` ou linha em branco dupla
- `[1]` = 1ª imagem de referência
- `[2]` = 2ª imagem de referência
- Sem `[ ]` = modo texto simples

---

## SEGUNDO PLANO

A extensão mantém o Google Flow aberto em **segundo plano** (aba inativa).
Você não precisa ver o Flow — a extensão injeta os prompts e clica em gerar automaticamente.

---

**umbrahubb.vercel.app**
