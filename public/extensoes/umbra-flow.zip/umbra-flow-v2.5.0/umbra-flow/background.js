// UMBRA FLOW v2.5.0 — Background Service Worker
// Inclui: janela app, download com força de nome, relay de mensagens, SDK de licença
'use strict';

// ═══════════════════════════════════════════════
// UMBRA SDK v2.0 — Sistema de Licenças
// ═══════════════════════════════════════════════
const SDK_ENDPOINT = 'https://cvrdcupvqvkpwllwlkfw.functions.supabase.co/validar-licenca';
const SDK_SLUG     = 'umbrahub-all';
const SDK_VERSION  = '2.0.0';
const SDK_SESSION  = 24 * 60 * 60 * 1000; // 24h em ms
const SDK_HEARTBEAT_INTERVAL = 6 * 60 * 60 * 1000; // 6h em ms

// Gera ou recupera device_id único para esta instalação
async function getDeviceId() {
  return new Promise(resolve => {
    chrome.storage.local.get(['umbra_device_id'], data => {
      if (data.umbra_device_id) { resolve(data.umbra_device_id); return; }
      const id = 'dev-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
      chrome.storage.local.set({ umbra_device_id: id }, () => resolve(id));
    });
  });
}

// Valida localmente se a sessão ainda está dentro das 24h
function sessaoLocalValida(data) {
  if (!data.umbra_token || !data.umbra_expiry) return false;
  return Date.now() < data.umbra_expiry;
}

// Chama o servidor para ativar ou verificar
async function chamarServidor(payload) {
  try {
    const res = await fetch(SDK_ENDPOINT, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(payload),
    });
    if (!res.ok) return { valido: false, motivo: 'Servidor indisponível (' + res.status + ')' };
    return await res.json();
  } catch(e) {
    return { valido: false, motivo: 'Sem conexão com o servidor de licenças.' };
  }
}

// Ativa uma nova chave
async function ativarLicenca(chave) {
  const device_id = await getDeviceId();
  const resp = await chamarServidor({ action: 'activate', chave, device_id, slug: SDK_SLUG, version: SDK_VERSION });

  if (resp && resp.valido) {
    const expiry = Date.now() + SDK_SESSION;
    await new Promise(r => chrome.storage.local.set({
      umbra_chave:  chave,
      umbra_token:  resp.token || 'ok',
      umbra_expiry: expiry,
    }, r));
    agendarHeartbeat();
    return { valido: true };
  }
  return { valido: false, motivo: resp?.motivo || resp?.error || 'Chave inválida ou limite de dispositivos atingido.' };
}

// Verifica status atual (heartbeat ou verificação inicial)
async function verificarStatus() {
  return new Promise(resolve => {
    chrome.storage.local.get(['umbra_chave', 'umbra_token', 'umbra_expiry'], async data => {
      // Sessão local ainda válida → não precisa bater no servidor
      if (sessaoLocalValida(data)) { resolve({ valido: true }); return; }

      // Sem chave salva → não ativado
      if (!data.umbra_chave) { resolve({ valido: false, motivo: 'Não ativado.' }); return; }

      // Sessão expirada → verifica no servidor
      const device_id = await getDeviceId();
      const resp = await chamarServidor({
        action:   'verify',
        chave:    data.umbra_chave,
        device_id,
        token:    data.umbra_token || '',
        slug:     SDK_SLUG,
        version:  SDK_VERSION,
      });

      if (resp && resp.valido) {
        await new Promise(r => chrome.storage.local.set({
          umbra_token:  resp.token || data.umbra_token,
          umbra_expiry: Date.now() + SDK_SESSION,
        }, r));
        resolve({ valido: true });
      } else {
        // Licença revogada remotamente — limpa tudo
        await new Promise(r => chrome.storage.local.remove(['umbra_token', 'umbra_expiry'], r));
        resolve({ valido: false, motivo: resp?.motivo || 'Licença inválida ou revogada.' });
      }
    });
  });
}

// Heartbeat periódico a cada 6h
let heartbeatTimer = null;
function agendarHeartbeat() {
  if (heartbeatTimer) clearTimeout(heartbeatTimer);
  heartbeatTimer = setTimeout(async () => {
    await verificarStatus();
    agendarHeartbeat();
  }, SDK_HEARTBEAT_INTERVAL);
}

// Inicia heartbeat ao carregar o service worker
verificarStatus().then(r => { if (r.valido) agendarHeartbeat(); });


const FLOW_URL = 'https://labs.google/fx/tools/flow';
const APP_URL  = chrome.runtime.getURL('app.html');

let appWindowId = null;

// ── Fila de nomes para downloads ──────────────
// content.js empurra o nome ANTES do download
// onDeterminingFilename pega o próximo da fila
const pendingRenames = {};

// ── Abre/foca janela do app ───────────────────
function abrirJanela() {
  return new Promise(resolve => {
    if (appWindowId !== null) {
      chrome.windows.get(appWindowId, win => {
        if (chrome.runtime.lastError || !win) {
          appWindowId = null;
          criarJanela(resolve);
        } else {
          chrome.windows.update(appWindowId, { focused: true }, () => resolve());
        }
      });
    } else {
      criarJanela(resolve);
    }
  });
}

function criarJanela(resolve) {
  chrome.windows.create({
    url: APP_URL, type: 'popup',
    width: 360, height: 660, top: 80, left: 40, focused: true,
  }, win => {
    appWindowId = win.id;
    chrome.windows.onRemoved.addListener(function onRem(id) {
      if (id === appWindowId) {
        appWindowId = null;
        chrome.windows.onRemoved.removeListener(onRem);
      }
    });
    resolve();
  });
}

chrome.action.onClicked.addListener(() => abrirJanela());

// ── Injetar content script programaticamente ──
function injetarContentScript(tabId) {
  return new Promise(resolve => {
    chrome.scripting.executeScript({
      target: { tabId }, files: ['content.js']
    }, () => {
      if (chrome.runtime.lastError) {
        console.warn('[Umbra BG] injeção:', chrome.runtime.lastError.message);
      }
      setTimeout(resolve, 800);
    });
    chrome.scripting.insertCSS({ target: { tabId }, files: ['content.css'] }, () => {});
  });
}

// ── Enviar com retry automático ───────────────
function enviarComRetry(tabId, payload, tentativas) {
  tentativas = tentativas || 3;
  return new Promise(resolve => {
    function tentar(restantes) {
      chrome.tabs.sendMessage(tabId, payload, response => {
        const err = chrome.runtime.lastError;
        if (!err) { resolve(response || { ok: true }); return; }
        const msg = err.message || '';
        const naoConectou = msg.includes('Could not establish') ||
                            msg.includes('Receiving end') ||
                            msg.includes('message channel closed');
        if (naoConectou && restantes > 0) {
          console.log('[Umbra BG] Reinjetando content script... (' + restantes + ')');
          injetarContentScript(tabId).then(() => tentar(restantes - 1));
        } else {
          resolve({ ok: false, err: msg });
        }
      });
    }
    tentar(tentativas - 1);
  });
}

// ── Garantir aba do Flow ──────────────────────
function garantirFlow() {
  return new Promise(resolve => {
    chrome.tabs.query({ url: 'https://labs.google/fx/tools/flow*' }, tabs => {
      if (tabs && tabs.length > 0) {
        resolve({ ok: true, tabId: tabs[0].id, nova: false });
      } else {
        chrome.tabs.create({ url: FLOW_URL, active: false }, tab => {
          resolve({ ok: true, tabId: tab.id, nova: true });
        });
      }
    });
  });
}

// ── Aguarda tab carregar ──────────────────────
function aguardarTab(tabId, timeout) {
  return new Promise(resolve => {
    chrome.tabs.get(tabId, tab => {
      if (!chrome.runtime.lastError && tab && tab.status === 'complete') return resolve();
      const t = setTimeout(() => { chrome.tabs.onUpdated.removeListener(fn); resolve(); }, timeout || 10000);
      function fn(id, info) {
        if (id === tabId && info.status === 'complete') {
          clearTimeout(t); chrome.tabs.onUpdated.removeListener(fn); resolve();
        }
      }
      chrome.tabs.onUpdated.addListener(fn);
    });
  });
}

// ── DOWNLOAD com nome forçado ─────────────────
function fazerDownload(url, filename, tabId) {
  return new Promise(resolve => {
    const desiredName = filename || 'video.mp4';
    const key = tabId || 'global';

    // Coloca nome na fila ANTES do download
    if (!pendingRenames[key]) pendingRenames[key] = [];
    pendingRenames[key].push(desiredName);

    chrome.downloads.download({
      url,
      filename: desiredName,
      conflictAction: 'uniquify',
    }, downloadId => {
      if (chrome.runtime.lastError) {
        if (pendingRenames[key]) pendingRenames[key].pop();
        resolve({ success: false, error: chrome.runtime.lastError.message });
      } else {
        resolve({ success: true, downloadId });
      }
    });
  });
}

// ── Intercepta nome de downloads ─────────────
// Única forma 100% confiável de forçar o nome
// (o servidor pode mandar Content-Disposition diferente)
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  for (const key of Object.keys(pendingRenames)) {
    const queue = pendingRenames[key];
    if (queue && queue.length > 0) {
      const newName = queue.shift();
      if (queue.length === 0) delete pendingRenames[key];
      console.log('[Umbra DL] ' + (item.filename || '?') + ' → ' + newName);
      suggest({ filename: newName, conflictAction: 'uniquify' });
      return;
    }
  }
  suggest();
});

// ── Relay de LOG/PROGRESS/STEP para a janela ──
function relayParaApp(msg) {
  chrome.tabs.query({ url: chrome.runtime.getURL('app.html') }, tabs => {
    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, msg, () => { void chrome.runtime.lastError; });
    });
  });
  // Também tenta pela janela popup
  if (appWindowId) {
    chrome.windows.get(appWindowId, win => {
      if (!chrome.runtime.lastError && win) {
        chrome.tabs.query({ windowId: appWindowId }, tabs => {
          tabs.forEach(tab => {
            chrome.tabs.sendMessage(tab.id, msg, () => { void chrome.runtime.lastError; });
          });
        });
      }
    });
  }
}

// ═══════════════════════════════════════════════
// LISTENER PRINCIPAL
// ═══════════════════════════════════════════════
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {

  // ── Licença SDK ───────────────────────────────
  if (msg.action === 'GET_STATUS') {
    verificarStatus().then(r => sendResponse(r));
    return true;
  }

  if (msg.action === 'ACTIVATE') {
    ativarLicenca(msg.chave).then(r => sendResponse(r));
    return true;
  }

  if (msg.action === 'LOGOUT') {
    chrome.storage.local.remove(['umbra_token', 'umbra_chave', 'umbra_expiry'], () => {
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg.type === 'OPEN_APP') {
    abrirJanela().then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === 'ENSURE_FLOW') {
    garantirFlow().then(r => sendResponse(r));
    return true;
  }

  if (msg.type === 'TO_FLOW') {
    garantirFlow().then(async flowResult => {
      const tabId = flowResult.tabId;
      if (flowResult.nova) {
        await aguardarTab(tabId, 10000);
        await new Promise(r => setTimeout(r, 1500));
        await injetarContentScript(tabId);
      }
      const response = await enviarComRetry(tabId, msg.payload, 3);
      sendResponse(response);
    });
    return true;
  }

  // Download direto do content script
  if (msg.type === 'DOWNLOAD_FILE') {
    if (!msg.url) { sendResponse({ success: false, error: 'URL inválida' }); return; }
    const tabId = sender.tab?.id || 'global';
    fazerDownload(msg.url, msg.filename, tabId).then(r => sendResponse(r));
    return true;
  }

  // Relay de logs/progresso do content script para a janela do app
  if (msg.type === 'LOG' || msg.type === 'PROGRESS' || msg.type === 'STEP' ||
      msg.type === 'VIDEO_FOUND' || msg.type === 'VIDEO_DOWNLOADED') {
    relayParaApp(msg);
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'SAVE') {
    chrome.storage.local.set(msg.data, () => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === 'LOAD') {
    chrome.storage.local.get(msg.keys, data => sendResponse(data || {}));
    return true;
  }

  sendResponse({ ok: false, err: 'tipo desconhecido' });
  return false;
});
