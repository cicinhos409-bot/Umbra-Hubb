// UMBRA FLOW v2.4.2 — Content Script
// Ingredientes v3: snapshot DOM + container detection + clique agressivo
(function () {
  'use strict';
  if (window.__umbraLoaded) return;
  window.__umbraLoaded = true;
  let umbraStopped = false;
  function checkStopped() { return umbraStopped; }
  function log(msg) { console.log('[UMBRA] ' + msg); }
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  function isElVisible(el) {
    if (!el) return false;
    const s = window.getComputedStyle(el);
    if (s.display === 'none' || s.visibility === 'hidden') return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  function getSlateField() {
    // 1. Editor Slate nativo (padrão histórico do Flow)
    const slate = document.querySelector('div[data-slate-editor="true"]');
    if (slate && isElVisible(slate)) return slate;

    // 2. Qualquer contenteditable visível, excluindo recaptcha e iframes
    for (const e of document.querySelectorAll('[contenteditable="true"]')) {
      if (!isElVisible(e)) continue;
      const combined = (e.id + e.className + (e.getAttribute('aria-label')||'')).toLowerCase();
      if (combined.includes('recaptcha') || combined.includes('search')) continue;
      // Prefere elementos na metade inferior da tela (campo de prompt)
      const r = e.getBoundingClientRect();
      if (r.top > window.innerHeight * 0.4) return e;
    }

    // 3. Fallback: qualquer contenteditable visível (qualquer posição)
    for (const e of document.querySelectorAll('[contenteditable="true"]')) {
      if (!isElVisible(e)) continue;
      const combined = (e.id + e.className).toLowerCase();
      if (combined.includes('recaptcha')) continue;
      return e;
    }

    // 4. textarea visível na parte inferior (fallback para versões alternativas do Flow)
    for (const e of document.querySelectorAll('textarea')) {
      if (!isElVisible(e)) continue;
      const r = e.getBoundingClientRect();
      if (r.top > window.innerHeight * 0.3) return e;
    }

    return null;
  }

  function getFieldText(campo) {
    const phs = [...campo.querySelectorAll('[data-slate-placeholder="true"]')].map(e => e.textContent || '');
    let t = campo.innerText || '';
    for (const ph of phs) t = t.replace(ph, '');
    return t.trim();
  }

  function isFieldEmpty(campo) {
    const t = getFieldText(campo);
    log('isEmpty: "' + t.substring(0,50) + '" = ' + (t.length===0));
    return t.length === 0;
  }

  async function clearField(campo) {
    if (isFieldEmpty(campo)) return true;
    log('Limpando campo...');

    campo.click(); await sleep(300);
    campo.focus(); await sleep(300);

    // Método 1: Ctrl+A → Delete (rápido e confiável para Slate/React)
    campo.dispatchEvent(new KeyboardEvent('keydown', { key:'a', code:'KeyA', keyCode:65, ctrlKey:true, bubbles:true, cancelable:true }));
    await sleep(150);
    campo.dispatchEvent(new KeyboardEvent('keydown', { key:'Delete', keyCode:46, bubbles:true, cancelable:true }));
    document.execCommand('selectAll', false, null);
    document.execCommand('delete', false, null);
    await sleep(300);

    if (isFieldEmpty(campo)) { log('Campo limpo (Ctrl+A)'); return true; }

    // Método 2: beforeinput deleteContent (Slate ouve esse evento)
    campo.dispatchEvent(new InputEvent('beforeinput', {
      bubbles: true, cancelable: true, inputType: 'deleteContentBackward'
    }));
    await sleep(200);

    if (isFieldEmpty(campo)) { log('Campo limpo (beforeinput)'); return true; }

    // Método 3: caractere a caractere com Home+Shift+End → delete (fallback lento)
    campo.dispatchEvent(new KeyboardEvent('keydown', { key:'End', keyCode:35, ctrlKey:true, bubbles:true }));
    await sleep(150);
    const len = getFieldText(campo).length + 5;
    for (let i = 0; i < len; i++) {
      document.execCommand('delete', false, null);
      await sleep(10);
      if (i % 30 === 0) {
        campo.dispatchEvent(new KeyboardEvent('keydown', { key:'End', keyCode:35, ctrlKey:true, bubbles:true }));
        if (isFieldEmpty(campo)) break;
      }
    }
    await sleep(300);

    const ok = isFieldEmpty(campo);
    log('Campo limpo: ' + ok);
    return ok;
  }

  async function typeIntoSlate(campo, texto) {
    log('Inserindo ' + texto.length + ' chars...');
    await clearField(campo);
    await sleep(300);

    campo.click(); await sleep(300);
    campo.focus(); await sleep(300);

    // Posiciona cursor no início
    try {
      const node = campo.querySelector('span[data-slate-node="text"]') ||
                   campo.querySelector('p') ||
                   campo.firstChild ||
                   campo;
      const sel   = window.getSelection();
      const range = document.createRange();
      if (node.nodeType === Node.TEXT_NODE) {
        range.setStart(node, 0);
      } else {
        range.setStart(node, 0);
      }
      range.collapse(true);
      sel.removeAllRanges();
      sel.addRange(range);
      await sleep(150);
    } catch(e) { log('cursor err: ' + e.message); }

    // ── Detecta se é textarea simples ou Slate ──
    const isTextarea = campo.tagName === 'TEXTAREA';
    const isSlate    = !!campo.dataset.slateEditor ||
                       !!campo.closest('[data-slate-editor]') ||
                       !!campo.querySelector('[data-slate-node]');

    if (isTextarea) {
      // textarea simples: atribui direto e dispara evento React
      const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
        window.HTMLTextAreaElement.prototype, 'value'
      )?.set;
      if (nativeInputValueSetter) {
        nativeInputValueSetter.call(campo, texto);
      } else {
        campo.value = texto;
      }
      campo.dispatchEvent(new Event('input',  { bubbles: true }));
      campo.dispatchEvent(new Event('change', { bubbles: true }));
      await sleep(400);
      log('Textarea: ok=' + (campo.value.length > 0));
      return campo.value.length > 0;
    }

    // ── Slate / contenteditable ──

    // Testa se Slate intercepta beforeinput (modo 1 — mais rápido)
    let slateIntercept = false;
    try {
      const testEv = new InputEvent('beforeinput', {
        bubbles: true, cancelable: true, inputType: 'insertText', data: texto[0] || 'a'
      });
      campo.dispatchEvent(testEv);
      slateIntercept = testEv.defaultPrevented;
    } catch(e) {}

    if (slateIntercept) {
      log('Modo Slate nativo (beforeinput interceptado)');
      // Envia o texto inteiro de uma vez via beforeinput
      campo.dispatchEvent(new InputEvent('beforeinput', {
        bubbles: true, cancelable: true, inputType: 'insertText', data: texto
      }));
      await sleep(600);
    } else {
      log('Modo execCommand caractere a caractere');
      // Envia em blocos de 20 chars para ser mais rápido que 1 por 1
      const BLOCO = 20;
      for (let i = 0; i < texto.length; i += BLOCO) {
        const chunk = texto.slice(i, i + BLOCO);
        campo.dispatchEvent(new InputEvent('beforeinput', {
          bubbles: true, cancelable: true, inputType: 'insertText', data: chunk
        }));
        document.execCommand('insertText', false, chunk);
        await sleep(20);
      }
    }
    await sleep(400);

    // Confirma que o Slate registrou o estado (espaço + backspace = "toque" no React)
    campo.dispatchEvent(new InputEvent('beforeinput', {
      bubbles: true, cancelable: true, inputType: 'insertText', data: ' '
    }));
    document.execCommand('insertText', false, ' ');
    await sleep(200);
    campo.dispatchEvent(new InputEvent('beforeinput', {
      bubbles: true, cancelable: true, inputType: 'deleteContentBackward'
    }));
    document.execCommand('delete', false, null);
    await sleep(300);

    const atual = getFieldText(campo);
    const ok    = atual.length > 0;
    log('Resultado: ok=' + ok + ' "' + atual.substring(0, 50) + '"');
    return ok;
  }

  // ── Auto-config Veo 3 ──────────────────────────
  function acharCapsule() {
    // 1. Botão da cápsula de config do Flow — tem aria-haspopup e fica na barra inferior
    const porHaspopup = [...document.querySelectorAll('button[aria-haspopup]')]
      .filter(b => {
        const r = b.getBoundingClientRect();
        return r.top > window.innerHeight * 0.5 && r.width > 60 && r.height > 20;
      });
    if (porHaspopup.length > 0) return porHaspopup[0];

    // 2. Busca por texto de modelo/config na barra inferior
    const kw = ['veo 3','veo 2','veo3','nano banana','imagen','vídeo','video','x1','x2','x3','x4','16:9','9:16'];
    const porTexto = [...document.querySelectorAll('button')].find(b => {
      const t = (b.textContent||'').toLowerCase();
      const r = b.getBoundingClientRect();
      return r.top > window.innerHeight * 0.5 && r.width > 0 &&
             kw.filter(k => t.includes(k)).length >= 2;
    });
    if (porTexto) return porTexto;

    // 3. Qualquer botão na barra inferior com data-state (Radix UI)
    const porState = [...document.querySelectorAll('button[data-state]')]
      .find(b => {
        const r = b.getBoundingClientRect();
        return r.top > window.innerHeight * 0.55 && r.width > 40;
      });
    return porState || null;
  }

  function btnPorTexto(textos) {
    // 1. Dentro de painéis abertos do Radix UI (popper, menu, dialog)
    const paineis = document.querySelectorAll(
      '[data-radix-popper-content-wrapper],[role="menu"],[role="listbox"],[data-state="open"],[role="dialog"]'
    );
    for (const pop of paineis) {
      for (const el of pop.querySelectorAll('button,[role="tab"],[role="menuitem"],[role="option"]')) {
        const t = (el.textContent||'').toLowerCase().trim();
        if (textos.some(x => t === x || t.includes(x))) return el;
      }
    }
    // 2. Fallback global — qualquer elemento interativo com o texto
    for (const el of document.querySelectorAll('button,[role="tab"],[role="menuitem"],[role="option"]')) {
      const t = (el.textContent||'').toLowerCase().trim();
      if (textos.some(x => t === x || t.includes(x))) return el;
    }
    // 3. Tenta em li e divs com role
    for (const el of document.querySelectorAll('li,[role="radio"],[role="switch"]')) {
      const t = (el.textContent||'').toLowerCase().trim();
      if (textos.some(x => t === x || t.includes(x))) return el;
    }
    return null;
  }

  async function autoConfigurar(settings) {
    log('Auto-config iniciando...');
    document.dispatchEvent(new KeyboardEvent('keydown', { key:'Escape', keyCode:27, bubbles:true }));
    await sleep(400);

    const cap = acharCapsule();
    if (!cap) { log('Cápsula não encontrada'); return; }
    cap.click(); await sleep(800);

    // ── Tipo: vídeo ou imagem ──
    const tipoTxt = (settings.tipo === 'imagem') ? ['imagem','image','foto'] : ['vídeo','video'];
    const tipoBtn = btnPorTexto(tipoTxt);
    if (tipoBtn) { tipoBtn.click(); await sleep(500); log('Tipo OK'); }

    // ── Modo de entrada ──
    // "frame" = modo de imagem para vídeo / "elementos" = modo com referências
    const modoTxt = (settings.modo === 'frame' || settings.modo === 'frames')
      ? ['frames','frame','image to video','imagem para vídeo']
      : ['elementos','elements','ingredients','ingredient','referências'];
    const modoBtn = btnPorTexto(modoTxt);
    if (modoBtn) { modoBtn.click(); await sleep(500); log('Modo OK: ' + settings.modo); }
    else log('AVISO modo não encontrado — textos: ' + modoTxt.join(','));

    // ── Orientação ──
    if (settings.orientacao) {
      const orientTxt = (settings.orientacao === '9:16' || settings.orientacao === 'retrato')
        ? ['9:16','retrato','portrait']
        : ['16:9','paisagem','landscape'];
      const orientBtn = btnPorTexto(orientTxt);
      if (orientBtn) { orientBtn.click(); await sleep(400); log('Orientação OK'); }
    }

    // ── Quantidade (x1, x2, x3, x4) ──
    if (settings.qtd) {
      const num = settings.qtd.replace('x','');
      // Procura botão com texto exatamente "x1", "x2" etc
      const qtdBtn = [...document.querySelectorAll('button,[role="button"],[role="radio"],[role="tab"]')]
        .find(b => {
          const t = (b.textContent||'').replace(/\s+/g,'').toLowerCase();
          return t === ('x'+num);
        });
      if (qtdBtn) { qtdBtn.click(); await sleep(400); log('Qtd OK: x'+num); }
    }

    // ── Modelo de IA ──
    if (settings.modelo) {
      const modeloLower = settings.modelo.toLowerCase();
      // Procura dropdown de modelo — botão que já mostra o modelo atual
      const modeloKw = ['veo 3.1','veo 2','veo3','nano banana','imagen 4','imagen'];
      const dropBtn = [...document.querySelectorAll('button,[role="button"],[aria-haspopup]')]
        .find(b => {
          const t = (b.textContent||'').toLowerCase();
          return modeloKw.some(k => t.includes(k));
        });
      if (dropBtn) {
        dropBtn.click(); await sleep(700);
        // Dentro do dropdown aberto, acha a opção pelo nome
        const opcaoModelo = [...document.querySelectorAll(
          '[role="option"],[role="menuitem"],[role="radio"],li,button'
        )].find(e => (e.textContent||'').toLowerCase().includes(modeloLower));
        if (opcaoModelo) {
          opcaoModelo.scrollIntoView({ block:'nearest' });
          await sleep(100);
          opcaoModelo.click();
          await sleep(500);
          log('Modelo OK: ' + settings.modelo);
        } else {
          log('AVISO: modelo não encontrado no dropdown: ' + settings.modelo);
          document.dispatchEvent(new KeyboardEvent('keydown', { key:'Escape', keyCode:27, bubbles:true }));
          await sleep(300);
        }
      }
    }

    // Fecha painel
    document.dispatchEvent(new KeyboardEvent('keydown', { key:'Escape', keyCode:27, bubbles:true }));
    await sleep(700);
    log('Auto-config concluído');
  }

  // ── clickSendButton ───────────────────────────
  async function clickSendButton() {
    for (let t = 0; t < 20; t++) {
      const btns = [...document.querySelectorAll('button')];

      // 1. aria-label explícito de envio
      for (const sel of [
        'button[aria-label="Send prompt"]',
        'button[aria-label*="Send"]',
        'button[aria-label*="Enviar"]',
        'button[aria-label*="Criar"]',
        'button[aria-label*="Generate"]',
        'button[aria-label*="Gerar"]',
      ]) {
        const b = document.querySelector(sel);
        if (b && !b.disabled) {
          const r = b.getBoundingClientRect();
          if (r.width > 0 && r.top > window.innerHeight * 0.4) {
            b.focus(); await sleep(80); b.click();
            b.dispatchEvent(new MouseEvent('mousedown', { bubbles:true }));
            b.dispatchEvent(new MouseEvent('mouseup',   { bubbles:true }));
            return true;
          }
        }
      }

      // 2. Botão com ícone "arrow_forward" (Material Icons — texto no DOM)
      const sendArrow = btns.find(b => {
        const txt = (b.innerText||b.textContent||'').trim();
        const r = b.getBoundingClientRect();
        return txt.includes('arrow_forward') &&
               r.width > 0 && !b.disabled &&
               r.top > window.innerHeight * 0.5 &&
               !txt.includes('close') && !txt.includes('arrow_back') && !txt.includes('add_2');
      });
      if (sendArrow) {
        log('Send via arrow_forward: "' + sendArrow.innerText.trim().substring(0,30) + '"');
        sendArrow.focus(); await sleep(80); sendArrow.click();
        sendArrow.dispatchEvent(new MouseEvent('mousedown', { bubbles:true }));
        sendArrow.dispatchEvent(new MouseEvent('mouseup',   { bubbles:true }));
        return true;
      }

      // 3. Botão mais à direita na barra inferior com SVG (submit icon)
      const botoesDir = btns
        .filter(b => {
          const r = b.getBoundingClientRect();
          const txt = (b.innerText||'').trim();
          return r.top > window.innerHeight * 0.55 &&
                 r.right > window.innerWidth * 0.6 &&
                 r.width > 0 && !b.disabled && b.querySelector('svg') &&
                 !txt.includes('close') && !txt.includes('add_2') && !txt.includes('arrow_back');
        })
        .sort((a, b) => b.getBoundingClientRect().right - a.getBoundingClientRect().right);
      if (botoesDir.length > 0) {
        botoesDir[0].focus(); await sleep(80); botoesDir[0].click();
        return true;
      }

      // 4. Qualquer botão enabled perto do campo de texto
      const campo = getSlateField();
      if (campo) {
        const campoR = campo.getBoundingClientRect();
        const perto = btns.find(b => {
          const r = b.getBoundingClientRect();
          return !b.disabled && r.width > 0 &&
                 Math.abs(r.top - campoR.bottom) < 120 &&
                 r.right > campoR.left;
        });
        if (perto) { perto.focus(); await sleep(80); perto.click(); return true; }
      }

      log('Tentativa ' + (t+1) + '/20 — botão não encontrado');
      await sleep(500);
    }
    return false;
  }

  // ── Contagem / wait vídeo ─────────────────────
  function countVideos() {
    return [...document.querySelectorAll('video')].filter(v => {
      const s = v.src || v.currentSrc || '';
      return s.startsWith('http') || s.startsWith('blob:');
    }).length;
  }

  async function waitForNewVideo(before, urlsBefore, maxMs, onTick) {
    const start = Date.now();

    // Snapshot de imagens grandes já presentes antes do envio (para modo imagem)
    const imgsBefore = new Set(
      [...document.querySelectorAll('img[src*="ame="],img[src*="googleusercontent"],img[src*="googleapis"]')]
        .map(i => i.src || i.currentSrc || '').filter(Boolean)
    );

    while (Date.now() - start < maxMs) {
      if (onTick) onTick(Math.round(((Date.now()-start)/maxMs)*100), Date.now()-start);

      // 1. Vídeo novo por URL (modo vídeo)
      const cur = [...document.querySelectorAll('video')].filter(v => v.src || v.currentSrc);
      const novoVideo = cur.find(v => {
        const s = v.src || v.currentSrc || '';
        return s && !urlsBefore.has(s);
      });
      if (novoVideo) {
        log('Vídeo novo! ' + (novoVideo.src||'').substring(0,60));
        return { success: true, video: novoVideo };
      }

      // 2. Contagem de vídeos aumentou
      if (countVideos() > before) {
        const all = [...document.querySelectorAll('video')].filter(v => v.src);
        log('Contagem vídeos: ' + all.length);
        return { success: true, video: all[all.length-1] };
      }

      // 3. Imagem nova grande (modo imagem — CDN googleusercontent)
      const novaImg = [...document.querySelectorAll(
        'img[src*="ame="],img[src*="googleusercontent"],img[src*="googleapis"]'
      )].find(img => {
        const s = img.src || img.currentSrc || '';
        if (!s || imgsBefore.has(s)) return false;
        const r = img.getBoundingClientRect();
        return r.width > 80 && r.height > 80;
      });
      if (novaImg) {
        log('Imagem nova! ' + (novaImg.src||'').substring(0,60));
        return { success: true, video: novaImg, isImage: true };
      }

      // 4. Botão de download apareceu (indica geração concluída)
      const dlBtn = document.querySelector(
        '[aria-label*="download" i],[aria-label*="baixar" i],[aria-label*="Download" i]'
      );
      if (dlBtn) {
        const r = dlBtn.getBoundingClientRect();
        if (r.width > 0 && r.top > 0) {
          log('Botão download detectado!');
          return { success: true, video: dlBtn };
        }
      }

      await sleep(2000);
    }
    return { success: false, error: 'Timeout — vídeo não gerado em ' + Math.round(maxMs/1000) + 's' };
  }
  async function waitForFieldReady(maxMs) {
    maxMs = maxMs || 30000;
    const start = Date.now();
    while (Date.now() - start < maxMs) {
      const c = getSlateField();
      if (c) {
        const isEditable = c.getAttribute('contenteditable') === 'true' || c.tagName === 'TEXTAREA';
        if (isEditable) {
          const r = c.getBoundingClientRect();
          if (r.width > 0 && r.height > 0) {
            const carregando = [...document.querySelectorAll(
              '[class*="loading"],[class*="generat"],[aria-busy="true"],[class*="spinner"]'
            )].some(e => {
              const er = e.getBoundingClientRect();
              return er.width > 0 && er.height > 0;
            });
            if (!carregando) {
              log('Campo pronto em ' + Math.round((Date.now()-start)/1000) + 's');
              return true;
            }
          }
        }
      }
      await sleep(1000);
    }
    const c = getSlateField();
    if (c) { log('Timeout campo — usando mesmo assim'); return true; }
    log('Timeout campo — não encontrado');
    return false;
  }

  async function resetFieldForNextPrompt() {
    document.dispatchEvent(new KeyboardEvent('keydown', { key:'Escape', keyCode:27, bubbles:true }));
    await sleep(600);
    const c = getSlateField();
    if (!c) return;
    c.click(); c.focus(); await sleep(300);
    if (!isFieldEmpty(c)) await clearField(c);
    await sleep(200);
  }

  // ═══════════════════════════════════════════════
  // SELECIONAR INGREDIENTES — v3
  //
  // UI real do Flow (imagem do usuário):
  //   [thumb 40px] "Elderly woman standing..."
  //   [thumb 40px] "Calico cat standing neu..."
  //
  // Estratégia definitiva:
  // 1. Tira snapshot de todos os elementos antes do clique
  // 2. Clica no botão +
  // 3. Compara DOM depois — elementos NOVOS = dropdown
  // 4. Dentro dos novos, procura itens com thumbnail
  // 5. Clica no N-ésimo item
  // ═══════════════════════════════════════════════

  function extrairIndices(promptText) {
    var match = promptText.match(/\[\s*([\d\s,]+)\s*\]/);
    if (!match) return [];
    return match[1].split(',')
      .map(function(s) { return parseInt(s.trim(), 10); })
      .filter(function(n) { return !isNaN(n) && n >= 1 && n <= 10; });
  }

  // Encontra o botão "+" na barra de ingredientes/referências do Flow
  function acharBotaoMais() {
    const todos = [...document.querySelectorAll('button, [role="button"]')];
    const inferiores = todos.filter(function(b) {
      const r = b.getBoundingClientRect();
      return r.top > window.innerHeight * 0.5 && r.width > 0 && r.height > 0;
    });

    log('Botões barra inferior: ' + inferiores.map(function(b) {
      return '"' + (b.innerText||b.textContent||'').trim().substring(0,12) + '"(' +
             Math.round(b.getBoundingClientRect().left) + ')';
    }).join(' | '));

    // 1. aria-label explícito de adicionar
    const r0 = inferiores.find(b => {
      const label = (b.getAttribute('aria-label')||'').toLowerCase();
      return label.includes('add') || label.includes('adicionar') || label.includes('inserir');
    });
    if (r0) return r0;

    // 2. Texto exatamente "+" ou "add" ou ícone Material "add"
    const r1 = inferiores.find(b => {
      const t = (b.innerText||b.textContent||'').trim();
      return t === '+' || t === 'add' || t === 'add_2' || t.toLowerCase() === 'add';
    });
    if (r1) return r1;

    // 3. Botão com SVG na posição mais à esquerda da barra (< 25% da tela)
    const r2 = inferiores.find(b => {
      const r = b.getBoundingClientRect();
      return b.querySelector('svg') && r.left < window.innerWidth * 0.25;
    });
    if (r2) return r2;

    // 4. Botão mais à esquerda na barra inferior (o "+" é sempre o primeiro)
    if (inferiores.length > 0) {
      return inferiores.reduce(function(a, b) {
        return b.getBoundingClientRect().left < a.getBoundingClientRect().left ? b : a;
      });
    }
    return null;
  }

  // Encontra o container do dropdown de ingredientes/imagens após abrir
  function encontrarDropdownContainer() {
    // Prioridade: painéis Radix UI abertos (o Flow usa Radix)
    const radix = [...document.querySelectorAll('[data-radix-popper-content-wrapper]')]
      .filter(el => {
        const r = el.getBoundingClientRect();
        return r.width > 50 && r.height > 50;
      });
    if (radix.length > 0) return radix[0];

    // Painéis abertos com data-state
    const abertos = [...document.querySelectorAll('[data-state="open"]')]
      .filter(el => {
        const r = el.getBoundingClientRect();
        return r.width > 80 && r.height > 80;
      })
      .sort((a, b) => b.getBoundingClientRect().height - a.getBoundingClientRect().height);
    if (abertos.length > 0) return abertos[0];

    // Roles semânticos de lista/menu
    const porRole = ['[role="listbox"]','[role="menu"]','[role="dialog"]','[aria-modal="true"]'];
    for (const sel of porRole) {
      const els = [...document.querySelectorAll(sel)].filter(el => {
        const r = el.getBoundingClientRect();
        return r.width > 50 && r.height > 50;
      });
      if (els.length > 0) return els[0];
    }

    // Painel flutuante: posição fixed/absolute com z-index alto e tamanho razoável
    const flutuante = [...document.querySelectorAll('div')]
      .filter(el => {
        const s = window.getComputedStyle(el);
        const r = el.getBoundingClientRect();
        const z = parseInt(s.zIndex) || 0;
        return (s.position === 'fixed' || s.position === 'absolute') &&
               z > 100 && r.width > 100 && r.height > 80 &&
               el.querySelectorAll('img').length > 0;
      })
      .sort((a, b) => {
        const za = parseInt(window.getComputedStyle(a).zIndex) || 0;
        const zb = parseInt(window.getComputedStyle(b).zIndex) || 0;
        return zb - za;
      });
    if (flutuante.length > 0) return flutuante[0];

    return null;
  }

  // Coleta itens clicáveis dentro do dropdown de imagens/personagens
  function coletarItensNoContainer(container) {
    if (!container) return [];

    // 1. Roles semânticos diretos (listbox > option, menu > menuitem)
    const porRole = [...container.querySelectorAll('[role="option"],[role="menuitem"],[role="row"]')]
      .filter(el => {
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 10;
      });
    if (porRole.length > 0) { log('Itens role=option/menuitem: ' + porRole.length); return porRole; }

    // 2. li com imagem — padrão de lista de personagens do Flow
    const lisComImg = [...container.querySelectorAll('li')]
      .filter(el => {
        const r = el.getBoundingClientRect();
        return r.width > 0 && r.height > 0 && el.querySelector('img');
      });
    if (lisComImg.length > 0) { log('Itens li+img: ' + lisComImg.length); return lisComImg; }

    // 3. li sem img (lista simples)
    const lis = [...container.querySelectorAll('li')]
      .filter(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0; });
    if (lis.length > 0) { log('Itens li: ' + lis.length); return lis; }

    // 4. Padrão real do Flow: div/button com thumbnail (img ~40px) + texto ao lado
    //    Estrutura: <div> <img width~40> <span>Elderly woman...</span> </div>
    const comThumb = [...container.querySelectorAll('div,button')]
      .filter(el => {
        const r = el.getBoundingClientRect();
        if (r.width < 80 || r.height < 28 || r.height > 200) return false;
        const img = el.querySelector('img');
        if (!img) return false;
        const imgR = img.getBoundingClientRect();
        return imgR.width >= 24 && imgR.width <= 120;
      });

    // Remove ancestrais — fica com os elementos mais específicos (sem filhos que também batam)
    const deduplicados = comThumb.filter(el =>
      !comThumb.some(outro => outro !== el && el.contains(outro))
    );

    if (deduplicados.length > 0) { log('Itens div+thumb: ' + deduplicados.length); return deduplicados; }

    // 5. Fallback: filhos diretos do container com tamanho razoável
    const filhos = [...container.children]
      .filter(el => { const r = el.getBoundingClientRect(); return r.width > 0 && r.height > 10; });
    if (filhos.length > 0) { log('Filhos diretos: ' + filhos.length); return filhos; }

    return [];
  }

  // Aguarda dropdown abrir — retorna {container, items}
  async function aguardarDropdown(maxMs) {
    const start = Date.now();
    while (Date.now() - start < maxMs) {
      const c = encontrarDropdownContainer();
      if (c) {
        await sleep(400); // aguarda renderização completa dos itens
        const items = coletarItensNoContainer(c);
        if (items.length > 0) {
          log('Dropdown OK: container=' + c.tagName + ' items=' + items.length);
          // Loga os itens encontrados para debug
          items.forEach((it, ii) => {
            log('  [' + (ii+1) + '] "' + (it.innerText||it.textContent||'').trim().substring(0,50) + '"');
          });
          return { container: c, items };
        }
        // Container encontrado mas sem itens — aguarda mais um pouco
        await sleep(300);
        const items2 = coletarItensNoContainer(c);
        if (items2.length > 0) return { container: c, items: items2 };
      }
      await sleep(250);
    }
    log('TIMEOUT dropdown (' + maxMs + 'ms) — nenhum item encontrado');
    return { container: null, items: [] };
  }

  // Clica num item do dropdown com múltiplos eventos para garantir que o React/Radix processe
  async function clicarItem(item, indice) {
    const txt = (item.innerText || item.textContent || '').trim().substring(0, 50);
    log('Clicando item [' + indice + ']: "' + txt + '"');

    item.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    await sleep(150);

    // Sequência completa de eventos de mouse (necessário para Radix UI)
    item.dispatchEvent(new MouseEvent('mouseover',  { bubbles: true, cancelable: true }));
    item.dispatchEvent(new MouseEvent('mouseenter', { bubbles: true, cancelable: true }));
    await sleep(50);
    item.dispatchEvent(new MouseEvent('mousedown',  { bubbles: true, cancelable: true, buttons: 1 }));
    await sleep(50);
    item.dispatchEvent(new MouseEvent('mouseup',    { bubbles: true, cancelable: true }));
    item.dispatchEvent(new MouseEvent('click',      { bubbles: true, cancelable: true }));
    await sleep(150);

    // Tenta também a img filha (thumbnails clicáveis)
    const img = item.querySelector('img');
    if (img) {
      img.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, buttons: 1 }));
      img.dispatchEvent(new MouseEvent('mouseup',   { bubbles: true }));
      img.dispatchEvent(new MouseEvent('click',     { bubbles: true }));
      await sleep(80);
    }

    // Tenta o primeiro filho interativo (role=button, a, button)
    const filho = item.querySelector('[role="button"], button, a');
    if (filho && filho !== item) {
      filho.dispatchEvent(new MouseEvent('click', { bubbles: true }));
      await sleep(80);
    }

    // Pointer events (alguns componentes modernos precisam)
    item.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true }));
    item.dispatchEvent(new PointerEvent('pointerup',   { bubbles: true, cancelable: true }));
    await sleep(100);

    return txt;
  }

  // FUNÇÃO PRINCIPAL — seleciona imagens/ingredientes no Flow
  async function selecionarIngredientes(promptText, personagens, onLog, onStep) {
    const indices = extrairIndices(promptText);
    if (indices.length === 0) return true;

    log('=== INGREDIENTES [' + indices.join(',') + '] ===');
    onStep('Selecionando ingredientes [' + indices.join(',') + ']...');

    for (let i = 0; i < indices.length; i++) {
      const indice = indices[i];
      const nomePersonagem = (personagens && personagens[indice - 1])
        ? (personagens[indice - 1].nome || null) : null;

      onLog('📍 Selecionando [' + indice + ']' + (nomePersonagem ? ' — ' + nomePersonagem : ''), 'info');

      // Fecha qualquer overlay aberto antes de cada seleção
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true }));
      await sleep(600);

      // Acha e clica no botão "+"
      const btnMais = acharBotaoMais();
      if (!btnMais) {
        onLog('⚠ Botão + não encontrado para [' + indice + ']', 'warn');
        continue;
      }

      log('Clicando "+"... ' + (btnMais.innerText||'').trim().substring(0,10));
      // Dispara sequência de eventos para garantir abertura
      btnMais.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, buttons: 1 }));
      await sleep(50);
      btnMais.dispatchEvent(new MouseEvent('mouseup',   { bubbles: true }));
      btnMais.dispatchEvent(new MouseEvent('click',     { bubbles: true }));
      await sleep(1200); // aguarda animação do dropdown

      // Aguarda e coleta itens
      let result = await aguardarDropdown(7000);

      // Se não achou — tenta clicar no botão de novo (às vezes o primeiro clique falha)
      if (result.items.length === 0) {
        log('Retry: clicando "+" novamente...');
        btnMais.click();
        await sleep(1500);
        result = await aguardarDropdown(5000);
      }

      if (result.items.length === 0) {
        onLog('⚠ Dropdown vazio para [' + indice + '] — sem itens', 'warn');
        const c2 = encontrarDropdownContainer();
        log('DOM container: ' + (c2 ? c2.outerHTML.substring(0,400) : 'null'));
        continue;
      }

      onLog('📋 ' + result.items.length + ' item(ns) disponível(is)', 'info');

      // Determina o item alvo
      let itemAlvo = null;

      // Prioridade 1: por nome de personagem (correspondência parcial)
      if (nomePersonagem) {
        const nl = nomePersonagem.toLowerCase();
        itemAlvo = result.items.find(it =>
          (it.innerText || it.textContent || '').toLowerCase().includes(nl)
        );
        if (itemAlvo) log('Achou pelo nome: ' + nomePersonagem);
      }

      // Prioridade 2: por índice posicional (1-based → 0-based)
      if (!itemAlvo) {
        const pos = Math.min(indice - 1, result.items.length - 1);
        itemAlvo = result.items[pos];
        log('Usando posição ' + (pos + 1) + '/' + result.items.length);
      }

      const nomeClicado = await clicarItem(itemAlvo, indice);
      await sleep(900);

      // Fecha dropdown após seleção
      document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', keyCode: 27, bubbles: true }));
      await sleep(300);
      document.body.click();
      await sleep(500);

      onLog('✓ [' + indice + '] selecionado: "' + nomeClicado.substring(0, 30) + '"', 'success');

      // Delay entre seleções múltiplas
      if (i < indices.length - 1) await sleep(700);
    }

    return true;
  }

  // ── Injeta imagem de frame no input[type=file] do Flow ──────────
  async function injetarFrameImage(dataUrl, nome) {
    try {
      // Converte dataUrl para File
      const res   = await fetch(dataUrl);
      const blob  = await res.blob();
      const file  = new File([blob], nome || 'frame.jpg', { type: blob.type || 'image/jpeg' });
      const dt    = new DataTransfer();
      dt.items.add(file);

      // Procura o input[type=file] visível ou oculto perto da barra de ferramentas
      const inputs = [...document.querySelectorAll('input[type="file"]')]
        .filter(i => i.accept && (i.accept.includes('image') || i.accept.includes('video') || i.accept === '*'));
      if (inputs.length === 0) {
        log('AVISO: input[type=file] não encontrado para frame');
        return false;
      }
      const input = inputs[0];
      input.files = dt.files;
      input.dispatchEvent(new Event('change', { bubbles: true }));
      input.dispatchEvent(new Event('input',  { bubbles: true }));
      log('Frame injetado: ' + nome + ' (' + Math.round(blob.size/1024) + 'kb)');
      return true;
    } catch(e) {
      log('Erro ao injetar frame: ' + e.message);
      return false;
    }
  }

  // ── processPrompt ─────────────────────────────
  async function processPrompt(promptText, index, settings, cbs) {
    const { onLog, onProgress, onStep } = cbs;
    onLog('[' + index + '] → "' + promptText.substring(0,60) + '..."');

    // ── 1. Auto-configuração (modelo, orientação, quantidade, modo) ──
    if (settings.autoConfig !== false) {
      onStep('Configurando Veo 3...'); onProgress(5, 'Configurando...');
      await autoConfigurar(settings);
    }

    // ── 2. Upload do frame inicial (modo frame) ──
    if (settings.frameImageDataUrl) {
      onStep('Fazendo upload do frame inicial...'); onProgress(7, 'Upload frame...');
      const uploadOk = await injetarFrameImage(settings.frameImageDataUrl, settings.frameImageName || 'frame.jpg');
      if (!uploadOk) onLog('[' + index + '] ⚠ Frame não injetado — continuando sem ele', 'warn');
      await sleep(800);
    }

    // ── 3. Selecionar ingredientes/personagens [N] ──
    const indices = extrairIndices(promptText);
    if (indices.length > 0) {
      onProgress(8, 'Selecionando ingredientes...');
      await selecionarIngredientes(
        promptText,
        settings.personagens || [],
        onLog,
        onStep
      );
      await sleep(500);
    }

    // ── 4. Aguarda campo de texto estar disponível ──
    onStep('Aguardando campo...'); await waitForFieldReady(20000);

    const campo = getSlateField();
    if (!campo) {
      onLog('[' + index + '] ✗ Campo de texto não encontrado', 'error');
      return { success: false, error: 'Campo não encontrado' };
    }

    // ── 5. Digita o prompt (sem o marcador [N]) ──
    const textoLimpo = promptText.replace(/\[\s*[\d\s,]+\s*\]/g, '').trim();
    onStep('Inserindo prompt...'); onProgress(10, 'Digitando...');

    const ok = await typeIntoSlate(campo, textoLimpo);
    if (!ok) {
      onLog('[' + index + '] ✗ Falha ao inserir texto', 'error');
      return { success: false, error: 'Falha ao digitar' };
    }

    // ── 6. Envia ──
    onProgress(30, 'Enviando...'); onStep('Clicando em enviar...');

    const vBefore   = countVideos();
    const urlsBefore = new Set(
      [...document.querySelectorAll('video')].map(v => v.src || v.currentSrc || '').filter(Boolean)
    );
    await sleep(600);

    let clicou = await clickSendButton();

    // Retry de envio se não achou o botão da primeira vez
    if (!clicou) {
      log('Retry envio em 2s...');
      await sleep(2000);
      clicou = await clickSendButton();
    }

    if (!clicou) {
      onLog('[' + index + '] ✗ Botão enviar não encontrado', 'error');
      return { success: false, error: 'Botão enviar não encontrado' };
    }

    onLog('[' + index + '] ✓ Enviado! Aguardando geração...', 'success');
    onProgress(35, 'Gerando...'); onStep('Aguardando vídeo...');

    // ── 7. Aguarda geração ──
    const res = await waitForNewVideo(vBefore, urlsBefore, settings.maxWaitMs || 180000, (pct, el) => {
      onProgress(35 + Math.round(pct * 0.55), 'Gerando... ' + Math.round(el/1000) + 's');
    });

    if (!res.success) {
      onLog('[' + index + '] ✗ ' + res.error, 'error');
      return { success: false, error: res.error };
    }

    const tipoResultado = res.isImage ? 'Imagem' : 'Vídeo';
    onLog('[' + index + '] ✓ ' + tipoResultado + ' pronto!', 'success');
    onProgress(100, 'Concluído!');
    await sleep(1000);
    await resetFieldForNextPrompt();
    return { success: true };
  }

  // ── Listener ──────────────────────────────────
  chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
    if (msg.type === 'PING') { sendResponse({ ok:true, url:location.href }); return false; }
    if (msg.type === 'STOP') { umbraStopped = true; sendResponse({ ok:true }); return false; }

    // ── Rastrear personagens ─────────────────────
    if (msg.type === 'RASTREAR_PERSONAGENS') {
      try {
        const imagens = [];
        const vistos  = new Set();

        // Seletores em ordem de prioridade para thumbnails do Flow
        // O Flow usa Google CDN para as imagens dos personagens
        const seletores = [
          // Dentro de painéis abertos (Radix UI / dropdowns)
          '[data-radix-popper-content-wrapper] img',
          '[data-state="open"] img',
          '[role="menu"] img',
          '[role="listbox"] img',
          '[role="dialog"] img',
          // Imagens do Google CDN (uploads do usuário)
          'img[src*="lh3.googleusercontent"]',
          'img[src*="googleapis"]',
          'img[src*="googleusercontent"]',
          // Blobs locais
          'img[src*="blob:"]',
        ];

        for (const sel of seletores) {
          const imgs = document.querySelectorAll(sel);
          for (const img of imgs) {
            const src = img.src || img.currentSrc || '';
            if (!src || vistos.has(src)) continue;
            if (src.startsWith('chrome-extension')) continue;
            if (src.startsWith('data:image/svg')) continue; // ignora ícones SVG inline

            const r = img.getBoundingClientRect();
            if (r.width < 28 || r.height < 28) continue; // ignora ícones pequenos

            vistos.add(src);

            // Tenta capturar como canvas para ter o dataUrl
            let dataUrl = null;
            try {
              const canvas = document.createElement('canvas');
              canvas.width  = Math.min(img.naturalWidth  || 80, 80);
              canvas.height = Math.min(img.naturalHeight || 80, 80);
              const ctx = canvas.getContext('2d');
              ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
              dataUrl = canvas.toDataURL('image/jpeg', 0.75);
            } catch(ce) {
              // Cross-origin — usa o src diretamente
              dataUrl = null;
            }

            // Captura texto próximo como label do personagem (pai imediato ou avô)
            let labelHint = '';
            try {
              const pai = img.closest('li,[role="option"],[role="menuitem"],div') || img.parentElement;
              if (pai) {
                const textos = [...pai.querySelectorAll('span,p,div')]
                  .map(el => (el.innerText||'').trim())
                  .filter(t => t.length > 2 && t.length < 60);
                labelHint = textos[0] || '';
              }
            } catch(le) {}

            imagens.push({ src, dataUrl, label: labelHint });
            if (imagens.length >= 3) break;
          }
          if (imagens.length >= 3) break;
        }

        sendResponse({ ok: true, imagens });
      } catch(e) {
        sendResponse({ ok: false, imagens: [], err: e.message });
      }
      return false;
    }

    if (msg.type === 'DISPARAR') {
      sendResponse({ ok:true, status:'iniciado' });
      umbraStopped = false;
      const cbs = {
        onLog:      function(m,t){ chrome.runtime.sendMessage({ type:'LOG',      msg:m, logType:t||'info' }, function(){ void chrome.runtime.lastError; }); },
        onProgress: function(p,l){ chrome.runtime.sendMessage({ type:'PROGRESS', pct:p, label:l          }, function(){ void chrome.runtime.lastError; }); },
        onStep:     function(s)  { chrome.runtime.sendMessage({ type:'STEP',     step:s                  }, function(){ void chrome.runtime.lastError; }); },
      };

      // Modo download
      if (msg.tipo === 'download') {
        const dcfg = msg.config || {};
        waitAndDownloadAll(dcfg.count||1, dcfg, cbs, dcfg.alreadyDownloaded||0, null)
          .then(function(r){ chrome.storage.local.set({ umbraLastResult:{ ok:r.success, timestamp:Date.now() } }); })
          .catch(function(e){ chrome.storage.local.set({ umbraLastResult:{ ok:false, err:e.message, timestamp:Date.now() } }); });
        return false;
      }

      processPrompt(msg.prompt, msg.index||1, msg.config||{}, cbs)
        .then(function(r){
          chrome.storage.local.set({ umbraLastResult:{ ok:r.success, err:r.error||null, timestamp:Date.now() } });
        })
        .catch(function(e){
          chrome.storage.local.set({ umbraLastResult:{ ok:false, err:e.message, timestamp:Date.now() } });
        });
      return false;
    }

    sendResponse({ ok:false, err:'desconhecida' });
    return false;
  });

  // ─────────────────────────────────────────────
  // SISTEMA DE DOWNLOAD — scroll + captura + baixar
  // ─────────────────────────────────────────────

  // Encontra o container scrollável principal da timeline do Flow
  function findScrollContainer() {
    // 1. Tenta pelo atributo data do Flow (muda entre versões — não confiável sozinho)
    const byClass = document.querySelector('[class*="sc-8cc14b4"]');
    if (byClass && byClass.scrollHeight > byClass.clientHeight + 100) return byClass;

    // 2. O container da timeline costuma ser o maior elemento scrollável da página
    const candidatos = [...document.querySelectorAll('*')]
      .filter(el => {
        const s = window.getComputedStyle(el);
        const r = el.getBoundingClientRect();
        return (s.overflowY === 'auto' || s.overflowY === 'scroll') &&
               el.scrollHeight > el.clientHeight + 200 &&
               el.clientHeight > 200 &&
               r.width > window.innerWidth * 0.3; // ignora sidebars estreitas
      })
      .sort((a, b) => b.scrollHeight - a.scrollHeight);

    if (candidatos.length > 0) return candidatos[0];

    // 3. Fallback: document.documentElement ou body se tiver scroll
    for (const el of [document.documentElement, document.body]) {
      if (el.scrollHeight > el.clientHeight + 200) return el;
    }
    return null;
  }

  // Extrai o número do prompt a partir dos ancestrais de um elemento de mídia
  function extractPromptNumber(el) {
    let parent = el.parentElement;
    for (let i = 0; i < 20 && parent; i++) {
      const text = parent.innerText || parent.textContent || '';

      // Padrão "PROMPT 1", "PROMPT_001", "Prompt 3" etc.
      const matchPrompt = text.match(/P(?:ROMPT)?[_\s]*0*(\d+)/i);
      if (matchPrompt) {
        const num = parseInt(matchPrompt[1], 10);
        if (num > 0 && num < 10000) return num;
      }

      // Padrão de índice de tile: data-tile-id, data-index
      const tileId = parent.dataset?.tileId || parent.dataset?.index || parent.getAttribute('data-tile-id');
      if (tileId) {
        const num = parseInt(tileId, 10);
        if (!isNaN(num) && num > 0) return num;
      }

      parent = parent.parentElement;
    }
    return null;
  }

  // Coleta todos os vídeos e imagens visíveis no container
  function coletarMediaVisiveis(container, ameMap) {
    let counter = ameMap.size;

    // ── Vídeos com parâmetro ame= (padrão do Flow para vídeos gerados) ──
    container.querySelectorAll('video').forEach(v => {
      const src = v.src || v.currentSrc || '';
      if (!src) return;

      // Usa ame= como chave única se disponível, senão usa a URL completa
      const ameMatch = src.match(/ame=([a-f0-9-]+)/);
      const chave = ameMatch ? ameMatch[1] : src;

      if (!ameMap.has(chave)) {
        const promptNum = extractPromptNumber(v);
        ameMap.set(chave, { url: src, pos: counter++, promptNum, tipo: 'video' });
      }
    });

    // ── Imagens grandes do CDN do Google (modo imagem) ──
    container.querySelectorAll(
      'img[src*="googleusercontent"],img[src*="googleapis"],img[src*="ame="]'
    ).forEach(img => {
      const src = img.src || img.currentSrc || '';
      if (!src) return;
      const r = img.getBoundingClientRect();
      if (r.width < 100 || r.height < 100) return; // ignora thumbnails

      const ameMatch = src.match(/ame=([a-f0-9-]+)/);
      const chave = ameMatch ? ('img_' + ameMatch[1]) : ('img_' + src.slice(-40));

      if (!ameMap.has(chave)) {
        const promptNum = extractPromptNumber(img);
        ameMap.set(chave, { url: src, pos: counter++, promptNum, tipo: 'imagem' });
      }
    });

    return counter;
  }

  async function downloadByUrl(src, name) {
    return new Promise(resolve => {
      // Timeout de 15s (vídeos grandes podem demorar mais para iniciar)
      const timer = setTimeout(() => resolve({ timedOut: true }), 15000);
      try {
        chrome.runtime.sendMessage(
          { type: 'DOWNLOAD_FILE', url: src, filename: name },
          resp => { clearTimeout(timer); resolve(resp || { success: true }); }
        );
      } catch(e) {
        clearTimeout(timer);
        resolve({ success: false, error: e.message });
      }
    });
  }

  async function scrollAndCollect(container, count, onLog) {
    const ameMap  = new Map();
    const totalH  = container.scrollHeight;
    const viewH   = container.clientHeight;
    const step    = Math.max(Math.floor(viewH * 0.4), 200);

    async function umaPassagem() {
      container.scrollTop = 0;
      await sleep(700);
      coletarMediaVisiveis(container, ameMap);

      for (let pos = step; pos <= totalH + step && !umbraStopped; pos += step) {
        container.scrollTop = pos;
        await sleep(800);
        coletarMediaVisiveis(container, ameMap);
        if (ameMap.size >= count) break; // achou tudo — para de scrollar
      }

      container.scrollTop = totalH;
      await sleep(700);
      coletarMediaVisiveis(container, ameMap);
    }

    await umaPassagem();

    // Se não achou tudo ainda, faz uma segunda passagem mais lenta
    if (ameMap.size < count && !umbraStopped) {
      onLog('Passagem extra (' + ameMap.size + '/' + count + ')...', 'info');
      await sleep(3000); // aguarda mais carregamento
      await umaPassagem();
    }

    return ameMap;
  }

  async function waitAndDownloadAll(count, settings, cbs, alreadyDownloaded) {
    const onLog      = cbs.onLog;
    const onProgress = cbs.onProgress;
    const maxMs      = Math.min((settings.maxWaitMs || 300000) * Math.max(count, 1), 3600000);
    const startTime  = Date.now();
    const pasta      = settings.pasta || 'UmbraVideos';

    let downloaded     = alreadyDownloaded || 0;
    let noProgressRounds = 0;
    const downloadedUrls = new Set();

    onProgress(Math.round((downloaded / count) * 90), downloaded + '/' + count + ' — iniciando...');

    if (downloaded >= count) {
      onProgress(100, 'Concluído! ' + downloaded + ' arquivo(s).');
      onLog('✓ Todos os ' + downloaded + ' arquivo(s) já baixados!', 'success');
      return { success: true, downloaded };
    }

    await sleep(1500);

    // Tenta encontrar o container — aguarda até 15s se necessário
    let container = findScrollContainer();
    for (let t = 0; !container && t < 15; t++) {
      await sleep(1000);
      container = findScrollContainer();
    }
    onLog(
      container
        ? 'Container de scroll: ' + Math.round(container.scrollHeight) + 'px'
        : '⚠ Container não encontrado — tentando coleta direta',
      container ? 'success' : 'warn'
    );

    while (downloaded < count && Date.now() - startTime < maxMs) {
      if (umbraStopped) break;

      let ameMap;
      if (container) {
        ameMap = await scrollAndCollect(container, count, onLog);
      } else {
        // Sem container: tenta coletar do document inteiro
        ameMap = new Map();
        coletarMediaVisiveis(document.body, ameMap);
      }

      // Ordena pelos mais recentes (maior pos = mais recente na timeline)
      const sorted = Array.from(ameMap.values())
        .sort((a, b) => b.pos - a.pos);

      // Loga o que achou
      sorted.forEach(item => {
        const num = item.promptNum ? String(item.promptNum).padStart(3, '0') : '???';
        const chave = item.url.slice(-20);
        onLog((item.tipo === 'imagem' ? '🖼 ' : '🎬 ') + 'PROMPT_' + num + ' ← ...' + chave, 'info');
        if (item.promptNum) {
          chrome.runtime.sendMessage(
            { type: 'VIDEO_FOUND', promptNum: item.promptNum },
            () => { void chrome.runtime.lastError; }
          );
        }
      });
      onLog('Coletados: ' + sorted.length + '/' + count, sorted.length >= count ? 'success' : 'info');

      // ── Baixa os que ainda não foram baixados ──
      for (let i = 0; i < sorted.length && downloaded < count && !umbraStopped; i++) {
        const item      = sorted[i];
        const src       = item.url;
        const promptNum = item.promptNum || (downloaded + 1);
        const realNum   = String(promptNum).padStart(3, '0');
        const ext       = item.tipo === 'imagem' ? 'jpg' : 'mp4';
        const name      = pasta + '/PROMPT_' + realNum + '.' + ext;

        if (downloadedUrls.has(src)) continue;
        downloadedUrls.add(src);
        downloaded++;

        // ETA
        const elapsed   = Math.max(1, Math.round((Date.now() - startTime) / 1000));
        const remaining = count - downloaded;
        const avgSec    = downloaded > 1 ? elapsed / downloaded : elapsed;
        const etaSec    = Math.round(avgSec * remaining);
        const etaStr    = etaSec > 60
          ? Math.floor(etaSec / 60) + 'min ' + (etaSec % 60) + 's'
          : etaSec + 's';

        onProgress(
          Math.round((downloaded / count) * 90),
          downloaded + '/' + count + ' — ' + (remaining > 0 ? 'faltam ~' + etaStr : 'finalizando...')
        );

        const res = await downloadByUrl(src, name);
        if (res && res.timedOut) {
          onLog('⚠ PROMPT_' + realNum + '.' + ext + ' timeout — tentando novamente', 'warn');
          downloaded--;
          downloadedUrls.delete(src);
        } else {
          onLog('✓ ' + downloaded + '/' + count + ': PROMPT_' + realNum + '.' + ext, 'success');
          chrome.storage.local.set({ umbra_confirmed: downloaded });
          chrome.runtime.sendMessage(
            { type: 'VIDEO_DOWNLOADED', promptNum },
            () => { void chrome.runtime.lastError; }
          );
          await sleep(1500);
        }
      }

      if (downloaded < count && !umbraStopped) {
        noProgressRounds++;
        if (noProgressRounds >= 3) {
          onLog('⚠ ' + downloaded + '/' + count + ' baixados. ' + (count - downloaded) + ' não encontrado(s).', 'warn');
          break;
        }
        // Aguarda mais vídeos gerarem (countdown visível)
        const espera = 25;
        for (let s = espera; s > 0 && !umbraStopped; s--) {
          onProgress(
            Math.round((downloaded / count) * 90),
            downloaded + '/' + count + ' — aguardando ' + s + 's...'
          );
          await sleep(1000);
        }
        // Re-adquire container (pode ter mudado)
        container = findScrollContainer() || container;
      }
    }

    if (downloaded >= count) {
      chrome.storage.local.remove('umbra_confirmed');
      onProgress(100, '✓ Todos os ' + downloaded + ' arquivo(s) baixados!');
      onLog('✓ Download completo: ' + downloaded + ' arquivo(s)!', 'success');
    } else {
      onProgress(Math.round((downloaded / count) * 100), downloaded + '/' + count + ' baixados');
      onLog('⚠ ' + downloaded + '/' + count + ' baixados.', 'warn');
    }

    return { success: true, downloaded };
  }

  log('v2.5.0 carregado — ' + location.href);
})();
