// ═══════════════════════════════════════════════════════
// UMBRA CHAT AUTOMATION - Content Script
// ═══════════════════════════════════════════════════════

(function () {
  'use strict';
  if (document.getElementById('umbra-panel-wrapper')) return;

  // ─── Inject Panel HTML ─────────────────────────────
  const wrapper = document.createElement('div');
  wrapper.id = 'umbra-panel-wrapper';
  wrapper.classList.add('umbra-visible');
  wrapper.innerHTML = `
    <div id="umbra-panel">

      <!-- Header (sempre visível) -->
      <div id="umbra-header">
        <div class="umbra-logo">
          <div class="umbra-logo-icon">
            <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9V8h2v8zm4 0h-2V8h2v8z"/></svg>
          </div>
          <span class="umbra-title"><span>Umbra</span> Automation</span>
        </div>
        <div class="umbra-header-btns">
          <button class="umbra-btn-icon" id="umbra-minimize-btn" title="Minimizar">─</button>
          <button class="umbra-btn-icon" id="umbra-close-btn" title="Fechar">✕</button>
        </div>
      </div>

      <!-- TELA DE ATIVAÇÃO -->
      <div id="umbra-view-activation">
        <div class="umbra-license-icon">🔐</div>
        <p class="umbra-license-desc">Insira sua licença do Umbra Hub para liberar o acesso:</p>
        <div class="umbra-license-input-group">
          <input type="text" id="umbra-key-input" placeholder="UMBRA-XXXX-XXXX-XXXX" spellcheck="false" autocomplete="off" />
        </div>
        <button id="umbra-activate-btn" class="umbra-btn-activate">Ativar Agora</button>
        <p id="umbra-license-error"></p>
        <a href="https://umbrahubb.vercel.app/" target="_blank" class="umbra-license-link">Obter licença →</a>
      </div>

      <!-- TELA DO APP -->
      <div id="umbra-view-app" style="display:none">
        <div id="umbra-body">

          <div id="umbra-status"><span class="umbra-spinner"></span> Automação em execução...</div>

          <div id="umbra-review">
            <strong>🌟 Curtindo a extensão?</strong>
            <p>Deixe uma avaliação e nos ajude a crescer!</p>
            <div class="umbra-review-btns">
              <button class="umbra-rate-now" id="umbra-rate-now">Avaliar agora</button>
              <button class="umbra-rate-later" id="umbra-rate-later">Depois</button>
              <button class="umbra-rate-never" id="umbra-rate-never">Não mostrar</button>
            </div>
          </div>

          <div class="umbra-section">
            <label class="umbra-label">Nova mensagem</label>
            <div class="umbra-input-group">
              <textarea id="umbra-message-input" placeholder="Digite a mensagem e pressione + para adicionar..."></textarea>
              <div class="umbra-input-actions">
                <select id="umbra-var-select" title="Inserir variável">
                  <option value="" disabled selected>Vars</option>
                  <option value="NEW_VAR">+ Nova</option>
                </select>
                <button id="umbra-add-btn" title="Adicionar mensagem">+</button>
              </div>
            </div>
            <div class="umbra-var-hint">Use <strong>{{x}}</strong> para adicionar variáveis.</div>
          </div>

          <div class="umbra-section">
            <label class="umbra-label">Fila de mensagens</label>
            <div id="umbra-messages-box">
              <div id="umbra-messages-list"><div class="umbra-msg-empty">Nenhuma mensagem adicionada</div></div>
              <div class="umbra-msg-actions">
                <button id="umbra-save-seq-btn">💾 Salvar Sequência</button>
                <button id="umbra-clear-btn">🗑 Limpar</button>
              </div>
            </div>
          </div>

          <div class="umbra-section">
            <label class="umbra-label">Sequências salvas</label>
            <div class="umbra-seq-row">
              <select id="umbra-seq-dropdown"><option value="" disabled selected>Salve uma sequência primeiro</option></select>
              <button id="umbra-delete-seq" title="Excluir sequência">✕</button>
            </div>
          </div>

          <div class="umbra-section">
            <button id="umbra-send-btn">▶ Enviar Mensagens</button>
            <button id="umbra-stop-btn">⏹ Parar Automação</button>
          </div>

        </div>

        <!-- Footer do app -->
        <div id="umbra-footer">
          <a href="https://umbrahubb.vercel.app/" target="_blank" class="umbra-footer-link">🌐 umbrahubb.vercel.app</a>
          <button id="umbra-logout-btn" class="umbra-logout-btn" title="Sair da licença">Sair</button>
        </div>
      </div>

      <div id="umbra-resizer">⋰</div>
    </div>`;

  document.body.appendChild(wrapper);

  // ─── Element Refs ──────────────────────────────────
  const panel           = document.getElementById('umbra-panel');
  const header          = document.getElementById('umbra-header');
  const minimizeBtn     = document.getElementById('umbra-minimize-btn');
  const closeBtn        = document.getElementById('umbra-close-btn');
  const viewActivation  = document.getElementById('umbra-view-activation');
  const viewApp         = document.getElementById('umbra-view-app');
  const keyInput        = document.getElementById('umbra-key-input');
  const activateBtn     = document.getElementById('umbra-activate-btn');
  const licenseError    = document.getElementById('umbra-license-error');
  const logoutBtn       = document.getElementById('umbra-logout-btn');
  const statusEl        = document.getElementById('umbra-status');
  const reviewEl        = document.getElementById('umbra-review');
  const msgInput        = document.getElementById('umbra-message-input');
  const varSelect       = document.getElementById('umbra-var-select');
  const addBtn          = document.getElementById('umbra-add-btn');
  const msgList         = document.getElementById('umbra-messages-list');
  const saveSeqBtn      = document.getElementById('umbra-save-seq-btn');
  const clearBtn        = document.getElementById('umbra-clear-btn');
  const seqDropdown     = document.getElementById('umbra-seq-dropdown');
  const deleteSeqBtn    = document.getElementById('umbra-delete-seq');
  const sendBtn         = document.getElementById('umbra-send-btn');
  const stopBtn         = document.getElementById('umbra-stop-btn');
  const resizer         = document.getElementById('umbra-resizer');
  const rateNowBtn      = document.getElementById('umbra-rate-now');
  const rateLaterBtn    = document.getElementById('umbra-rate-later');
  const rateNeverBtn    = document.getElementById('umbra-rate-never');

  // ─── State ─────────────────────────────────────────
  let messages = [];
  let savedSequences = {};
  let isMinimized = false;

  // ═══════════════════════════════════════════════════
  // LICENSE GATE
  // ═══════════════════════════════════════════════════

  function showActivation() {
    viewActivation.style.display = 'flex';
    viewApp.style.display = 'none';
    // Shrink panel height for license screen
    panel.style.height = '360px';
  }

  function showApp() {
    viewActivation.style.display = 'none';
    viewApp.style.display = 'block';
    panel.style.height = '650px';
    loadAppData();
  }

  // Check license on load
  chrome.runtime.sendMessage({ action: 'GET_STATUS' }, function(response) {
    if (response && response.valido) {
      showApp();
    } else {
      showActivation();
    }
  });

  // Activate button
  activateBtn.addEventListener('click', function() {
    const chave = keyInput.value.trim().toUpperCase();
    if (!chave) return;

    activateBtn.disabled = true;
    activateBtn.textContent = 'Validando...';
    licenseError.textContent = '';

    chrome.runtime.sendMessage({ action: 'ACTIVATE', chave }, function(response) {
      activateBtn.disabled = false;
      activateBtn.textContent = 'Ativar Agora';
      if (response && response.valido) {
        showApp();
      } else {
        licenseError.textContent = (response && response.motivo) || 'Chave inválida ou limite atingido.';
      }
    });
  });

  // Enter key on input
  keyInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') activateBtn.click();
  });

  // Logout
  logoutBtn.addEventListener('click', function() {
    chrome.runtime.sendMessage({ action: 'LOGOUT' }, function() {
      messages = [];
      savedSequences = {};
      showActivation();
    });
  });

  // ═══════════════════════════════════════════════════
  // APP LOGIC (only runs after license is valid)
  // ═══════════════════════════════════════════════════

  function loadAppData() {
    chrome.storage.local.get(['messages','sequences','isRunning','showReviewBanner'], function(data) {
      if (data.messages)         { messages = data.messages; renderMessages(); }
      if (data.sequences)        { savedSequences = data.sequences; renderSequences(); }
      if (data.isRunning)        { setUIRunning(true); }
      if (data.showReviewBanner) { reviewEl.style.display = 'block'; }
      refreshVarDropdown();
    });
  }

  // ─── Background messages ───────────────────────────
  chrome.runtime.onMessage.addListener(function(request) {
    if (request.action === 'togglePanel') {
      wrapper.classList.toggle('umbra-visible');
    } else if (request.action === 'automationFinished') {
      handleAutomationFinished();
    }
  });

  // ─── Drag ──────────────────────────────────────────
  let dragging = false, dragOffX = 0, dragOffY = 0;
  header.addEventListener('mousedown', function(e) {
    if (e.target.closest('.umbra-btn-icon')) return;
    dragging = true;
    const r = wrapper.getBoundingClientRect();
    dragOffX = e.clientX - r.left;
    dragOffY = e.clientY - r.top;
    document.body.style.userSelect = 'none';
  });
  document.addEventListener('mousemove', function(e) {
    if (!dragging) return;
    let x = e.clientX - dragOffX, y = e.clientY - dragOffY;
    const mv = 60;
    x = Math.max(-wrapper.offsetWidth + mv, Math.min(x, window.innerWidth - mv));
    y = Math.max(0, Math.min(y, window.innerHeight - mv));
    wrapper.style.left = x + 'px'; wrapper.style.top = y + 'px'; wrapper.style.right = 'auto';
  });
  document.addEventListener('mouseup', function() {
    if (dragging) { dragging = false; document.body.style.userSelect = ''; }
  });

  // ─── Minimize / Close ──────────────────────────────
  minimizeBtn.addEventListener('click', function() {
    isMinimized = !isMinimized;
    panel.classList.toggle('umbra-minimized', isMinimized);
    minimizeBtn.textContent = isMinimized ? '▢' : '─';
  });
  closeBtn.addEventListener('click', function() { wrapper.classList.remove('umbra-visible'); });

  // ─── Resize ────────────────────────────────────────
  let resizing = false, rsX = 0, rsY = 0, rsW = 0, rsH = 0;
  resizer.addEventListener('mousedown', function(e) {
    e.preventDefault(); e.stopPropagation();
    resizing = true; rsX = e.clientX; rsY = e.clientY;
    rsW = panel.offsetWidth; rsH = panel.offsetHeight;
    document.body.style.userSelect = 'none';
  });
  document.addEventListener('mousemove', function(e) {
    if (!resizing) return;
    panel.style.width  = Math.max(320, rsW + (e.clientX - rsX)) + 'px';
    panel.style.height = Math.max(300, rsH + (e.clientY - rsY)) + 'px';
  });
  document.addEventListener('mouseup', function() {
    if (resizing) { resizing = false; document.body.style.userSelect = ''; }
  });

  // ─── Variables ─────────────────────────────────────
  function getVariables() {
    const vars = new Set();
    const scan = (str) => { const r = /\{\{(.*?)\}\}/g; let m; while((m=r.exec(str))!==null) if(m[1].trim()) vars.add(m[1].trim()); };
    messages.forEach(scan);
    scan(msgInput.value);
    return Array.from(vars);
  }
  function refreshVarDropdown() {
    varSelect.innerHTML = `<option value="" disabled selected>Vars</option><option value="NEW_VAR">+ Nova</option>`;
    getVariables().forEach(v => { const o = document.createElement('option'); o.value = v; o.textContent = v; varSelect.appendChild(o); });
  }
  msgInput.addEventListener('input', refreshVarDropdown);
  varSelect.addEventListener('change', function() {
    const val = this.value;
    if (val === 'NEW_VAR') { const n = prompt('Nome da nova variável:'); if (n && n.trim()) { insertAtCursor(`{{${n.trim()}}}`); refreshVarDropdown(); } }
    else if (val) insertAtCursor(`{{${val}}}`);
    this.value = '';
  });
  function insertAtCursor(text) {
    const s = msgInput.selectionStart, v = msgInput.value;
    msgInput.value = v.slice(0, s) + text + v.slice(msgInput.selectionEnd);
    msgInput.focus(); msgInput.setSelectionRange(s + text.length, s + text.length);
  }

  // ─── Add Message ───────────────────────────────────
  addBtn.addEventListener('click', function() {
    const msg = msgInput.value.trim(); if (!msg) return;
    messages.push(msg); msgInput.value = '';
    saveMessages(); renderMessages(); refreshVarDropdown();
  });
  msgInput.addEventListener('keydown', function(e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); addBtn.click(); } });

  // ─── Render ────────────────────────────────────────
  function renderMessages() {
    msgList.innerHTML = messages.length === 0
      ? '<div class="umbra-msg-empty">Nenhuma mensagem adicionada</div>'
      : messages.map((m,i) => `<div class="umbra-msg-item"><span class="umbra-msg-num">${i+1}</span><span class="umbra-msg-text">${esc(m)}</span></div>`).join('');
  }
  function esc(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  clearBtn.addEventListener('click', function() { messages = []; saveMessages(); renderMessages(); refreshVarDropdown(); });

  // ─── Sequences ─────────────────────────────────────
  saveSeqBtn.addEventListener('click', function() {
    if (!messages.length) { alert('Adicione mensagens antes de salvar.'); return; }
    const name = prompt('Nome para esta sequência:'); if (!name || !name.trim()) return;
    savedSequences[name.trim()] = [...messages];
    chrome.storage.local.set({ sequences: savedSequences }, () => renderSequences(name.trim()));
  });
  function renderSequences(selectName) {
    const names = Object.keys(savedSequences);
    if (!names.length) { seqDropdown.innerHTML = '<option value="" disabled selected>Salve uma sequência primeiro</option>'; messages = []; }
    else {
      seqDropdown.innerHTML = names.map(n => `<option value="${esc(n)}">${esc(n)}</option>`).join('');
      const t = (selectName && savedSequences[selectName]) ? selectName : names[0];
      seqDropdown.value = t; messages = [...savedSequences[t]];
    }
    saveMessages(); renderMessages(); refreshVarDropdown();
  }
  seqDropdown.addEventListener('change', function() {
    const n = this.value;
    if (n && savedSequences[n]) { messages = [...savedSequences[n]]; saveMessages(); renderMessages(); refreshVarDropdown(); }
  });
  deleteSeqBtn.addEventListener('click', function() {
    const n = seqDropdown.value; if (!n || !savedSequences[n]) return;
    if (!confirm(`Excluir a sequência "${n}"?`)) return;
    delete savedSequences[n]; chrome.storage.local.set({ sequences: savedSequences }, () => renderSequences());
  });

  // ─── Send ──────────────────────────────────────────
  sendBtn.addEventListener('click', function() {
    if (!messages.length) { alert('Adicione mensagens à fila antes de enviar.'); return; }
    const vars = getVariables();
    let resolved = [...messages];
    if (vars.length > 0) {
      const values = {};
      for (const v of vars) { const val = prompt(`Valor para {{${v}}}:`); if (val === null) return; values[v] = val; }
      resolved = resolved.map(msg => { let t = msg; for (const [k,v] of Object.entries(values)) t = t.split(`{{${k}}}`).join(v); return t; });
    }
    setUIRunning(true);
    chrome.runtime.sendMessage({ action: 'startSequence', messages: resolved });
  });
  stopBtn.addEventListener('click', function() { chrome.runtime.sendMessage({ action: 'stopSequence' }); setUIRunning(false); });

  // ─── UI State ──────────────────────────────────────
  function setUIRunning(running) {
    sendBtn.style.display  = running ? 'none'  : 'block';
    stopBtn.style.display  = running ? 'block' : 'none';
    statusEl.style.display = running ? 'flex'  : 'none';
    statusEl.classList.remove('umbra-success');
    statusEl.innerHTML = '<span class="umbra-spinner"></span> Automação em execução...';
  }
  function handleAutomationFinished() {
    setUIRunning(false);
    statusEl.style.display = 'flex'; statusEl.classList.add('umbra-success');
    statusEl.innerHTML = '✔ Automação concluída!';
    setTimeout(() => { statusEl.style.display = 'none'; statusEl.classList.remove('umbra-success'); }, 3000);
    chrome.storage.local.get(['showReviewBanner'], function(data) { if (data.showReviewBanner) reviewEl.style.display = 'block'; });
  }

  // ─── Review ────────────────────────────────────────
  rateNowBtn.addEventListener('click', function() { window.open('https://umbrahubb.vercel.app/', '_blank'); chrome.storage.local.set({ reviewStatus: 'rated', showReviewBanner: false }); reviewEl.style.display = 'none'; });
  rateLaterBtn.addEventListener('click', function() { chrome.storage.local.set({ showReviewBanner: false }); reviewEl.style.display = 'none'; });
  rateNeverBtn.addEventListener('click', function() { chrome.storage.local.set({ reviewStatus: 'never', showReviewBanner: false }); reviewEl.style.display = 'none'; });

  function saveMessages() { chrome.storage.local.set({ messages }); }

})();
