// ═══════════════════════════════════════════════════════
// UMBRA CHAT AUTOMATION - Background Service Worker
// ═══════════════════════════════════════════════════════

// ─── Automation State ────────────────────────────────
let isRunning = false;
let lockedTabId = null;

// ─── License SDK Config ───────────────────────────────
const SDK = {
  endpoint: 'https://cvrdcupvqvkpwllwlkfw.functions.supabase.co/validar-licenca',
  slug: 'umbrahub-all',
  version: '2.0.0',
  sessionHours: 24,
  heartbeatHours: 6,
};

// ─── Generate or retrieve device ID ──────────────────
async function getDeviceId() {
  return new Promise(resolve => {
    chrome.storage.local.get(['umbra_device_id'], data => {
      if (data.umbra_device_id) return resolve(data.umbra_device_id);
      const id = 'dev_' + Date.now() + '_' + Math.random().toString(36).slice(2, 10);
      chrome.storage.local.set({ umbra_device_id: id }, () => resolve(id));
    });
  });
}

// ─── Call the Supabase Edge Function ─────────────────
async function callLicenseAPI(payload) {
  try {
    const res = await fetch(SDK.endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return await res.json();
  } catch (e) {
    console.error('[Umbra SDK] API error:', e);
    return null;
  }
}

// ─── ACTIVATE license ─────────────────────────────────
async function activateLicense(chave) {
  const device_id = await getDeviceId();
  const result = await callLicenseAPI({
    action: 'activate',
    chave,
    device_id,
    slug: SDK.slug,
    version: SDK.version,
  });

  if (result && result.valido) {
    const expiry = Date.now() + SDK.sessionHours * 3600 * 1000;
    await chrome.storage.local.set({
      umbra_chave: chave,
      umbra_token: result.token || '',
      umbra_expiry: expiry,
    });
    scheduleHeartbeat();
    return { valido: true };
  }
  return { valido: false, motivo: result?.motivo || 'Chave inválida ou limite atingido.' };
}

// ─── VERIFY license (local + remote) ─────────────────
async function verifyLicense() {
  return new Promise(resolve => {
    chrome.storage.local.get(['umbra_chave', 'umbra_token', 'umbra_expiry'], async data => {
      // No license stored
      if (!data.umbra_chave) return resolve({ valido: false, motivo: 'Sem licença.' });

      // Local session still valid (24h cache)
      if (data.umbra_expiry && Date.now() < data.umbra_expiry) {
        return resolve({ valido: true });
      }

      // Session expired — verify remotely
      const device_id = await getDeviceId();
      const result = await callLicenseAPI({
        action: 'verify',
        chave: data.umbra_chave,
        device_id,
        token: data.umbra_token || '',
        slug: SDK.slug,
        version: SDK.version,
      });

      if (result && result.valido) {
        const expiry = Date.now() + SDK.sessionHours * 3600 * 1000;
        await chrome.storage.local.set({
          umbra_token: result.token || data.umbra_token,
          umbra_expiry: expiry,
        });
        return resolve({ valido: true });
      }

      // Invalid — clear stored license
      await chrome.storage.local.remove(['umbra_chave', 'umbra_token', 'umbra_expiry']);
      resolve({ valido: false, motivo: result?.motivo || 'Licença revogada.' });
    });
  });
}

// ─── Heartbeat (every 6h) ────────────────────────────
function scheduleHeartbeat() {
  chrome.alarms.create('umbra_heartbeat', { periodInMinutes: SDK.heartbeatHours * 60 });
}

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'umbra_heartbeat') verifyLicense();
});

// Schedule heartbeat on startup if license exists
chrome.storage.local.get(['umbra_chave'], data => {
  if (data.umbra_chave) scheduleHeartbeat();
});

// ─── Message Listener ────────────────────────────────
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // License actions
  if (request.action === 'GET_STATUS') {
    verifyLicense().then(sendResponse);
    return true; // async
  }

  if (request.action === 'ACTIVATE') {
    activateLicense(request.chave).then(sendResponse);
    return true; // async
  }

  if (request.action === 'LOGOUT') {
    chrome.storage.local.remove(['umbra_chave', 'umbra_token', 'umbra_expiry'], () => {
      sendResponse({ ok: true });
    });
    return true;
  }

  // Automation actions
  if (request.action === 'startSequence') {
    isRunning = true;
    lockedTabId = sender.tab.id;
    chrome.storage.local.set({ isRunning: true });
    processQueue(request.messages);
  } else if (request.action === 'stopSequence') {
    isRunning = false;
    lockedTabId = null;
    chrome.storage.local.set({ isRunning: false });
  }
});

// ─── Toggle panel when icon clicked ──────────────────
chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.sendMessage(tab.id, { action: 'togglePanel' }, () => {
    if (chrome.runtime.lastError) {}
  });
});

// ═══════════════════════════════════════════════════════
// AUTOMATION ENGINE
// ═══════════════════════════════════════════════════════

async function processQueue(messages) {
  let queue = [...messages];
  try {
    while (queue.length > 0 && isRunning && lockedTabId) {
      const currentMessage = queue[0];
      const success = await sendPromptToSpecificTab(lockedTabId, currentMessage);
      if (!success) throw new Error('Tab not found or input unavailable.');
      await waitForTabResponse(lockedTabId);
      if (!isRunning) break;
      queue.shift();
      await chrome.storage.local.set({ messages: queue });
      if (queue.length > 0) await new Promise(r => setTimeout(r, 2000));
    }
  } catch (error) {
    console.error('[Umbra] Automation error:', error);
  } finally {
    isRunning = false;
    lockedTabId = null;
    chrome.storage.local.get(['reviewStatus', 'successCount'], function (data) {
      const status = data.reviewStatus || 'pending';
      const newCount = (data.successCount || 0) + 1;
      let update = { successCount: newCount, isRunning: false };
      if (status === 'pending' && (newCount === 3 || (newCount > 3 && newCount % 10 === 0))) {
        update.showReviewBanner = true;
      }
      chrome.storage.local.set(update, () => {
        chrome.tabs.query({ url: 'https://chatgpt.com/*' }, (tabs) => {
          tabs.forEach(tab => {
            chrome.tabs.sendMessage(tab.id, { action: 'automationFinished', successCount: newCount }, () => {
              if (chrome.runtime.lastError) {}
            });
          });
        });
      });
    });
  }
}

async function sendPromptToSpecificTab(tabId, text) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: (msg) => {
        const input = document.querySelector('#prompt-textarea') ||
                      document.querySelector('div[contenteditable="true"]');
        if (!input) return false;
        input.focus();
        input.innerHTML = '';
        const p = document.createElement('p');
        p.textContent = msg;
        input.appendChild(p);
        input.dispatchEvent(new Event('focus', { bubbles: true }));
        input.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, data: msg }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        const range = document.createRange();
        const sel = window.getSelection();
        range.selectNodeContents(input);
        range.collapse(false);
        sel.removeAllRanges();
        sel.addRange(range);
        return new Promise(resolve => {
          setTimeout(() => {
            const btn = document.querySelector('button[data-testid="send-button"]') ||
                        document.querySelector('button[aria-label="Send prompt"]') ||
                        document.querySelector('button[aria-label="Enviar prompt"]') ||
                        document.querySelector('form button[type="submit"]');
            if (btn && !btn.disabled) { btn.click(); resolve(true); }
            else {
              input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true, cancelable: true }));
              resolve(true);
            }
          }, 800);
        });
      },
      args: [text]
    });
    return results[0]?.result;
  } catch (e) {
    console.error('[Umbra] sendPrompt error:', e);
    return false;
  }
}

async function waitForTabResponse(tabId) {
  await new Promise(r => setTimeout(r, 2500));
  return new Promise((resolve) => {
    let consecutiveIdle = 0;
    const checkInterval = setInterval(() => {
      if (!isRunning) { clearInterval(checkInterval); resolve(); return; }
      try {
        chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            const stopBtn = document.querySelector('button[data-testid="stop-button"]');
            const streaming = document.querySelector('.result-streaming, [class*="streaming"]');
            const generating = document.querySelector('[aria-label="Stop generating"]') ||
                               document.querySelector('[aria-label="Parar geração"]');
            return !!(stopBtn || streaming || generating);
          }
        }, (results) => {
          if (chrome.runtime.lastError) { clearInterval(checkInterval); resolve(); return; }
          const stillWorking = results && results[0] && results[0].result;
          if (!stillWorking) {
            consecutiveIdle++;
            if (consecutiveIdle >= 3) { clearInterval(checkInterval); setTimeout(resolve, 500); }
          } else { consecutiveIdle = 0; }
        });
      } catch (e) { clearInterval(checkInterval); resolve(); }
    }, 1000);
  });
}
