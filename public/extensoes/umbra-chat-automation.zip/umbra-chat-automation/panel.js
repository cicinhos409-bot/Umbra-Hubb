// panel.js - reserved for future iframe use
// All panel logic is handled by content.js (the content script)
