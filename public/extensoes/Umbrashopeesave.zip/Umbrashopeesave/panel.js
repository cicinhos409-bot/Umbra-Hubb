document.addEventListener('DOMContentLoaded', () => {
  const imgCount = document.getElementById('img-count');
  const vidCount = document.getElementById('vid-count');
  const downloadAllBtn = document.getElementById('download-all');
  const autoSave = document.getElementById('auto-save');
  const mediaListContainer = document.getElementById('media-list');

  let detectedMedia = [];

  // Load settings
  chrome.storage.sync.get(['autoSave'], (result) => {
    autoSave.checked = result.autoSave || false;
  });

  autoSave.addEventListener('change', () => {
    chrome.storage.sync.set({ autoSave: autoSave.checked });
  });

  // Handle Download All
  downloadAllBtn.addEventListener('click', () => {
    if (detectedMedia.length === 0) return;
    
    downloadAllBtn.textContent = 'Baixando Tudo...';
    downloadAllBtn.disabled = true;

    detectedMedia.forEach((media, index) => {
      setTimeout(() => {
        chrome.runtime.sendMessage({ action: "download", url: media.url }).catch(() => {});
      }, index * 200); // Stagger downloads
    });

    setTimeout(() => {
      downloadAllBtn.textContent = 'Baixar Tudo';
      downloadAllBtn.disabled = false;
    }, 2000);
  });

  // Update Media List UI
  function updateMediaUI() {
    if (detectedMedia.length === 0) return;

    mediaListContainer.innerHTML = '';
    
    const images = detectedMedia.filter(m => m.type === 'image');
    const videos = detectedMedia.filter(m => m.type === 'video');

    imgCount.textContent = images.length;
    vidCount.textContent = videos.length;

    detectedMedia.slice(-10).reverse().forEach(media => { // Show last 10
      const item = document.createElement('div');
      item.className = 'media-item';
      
      const isVideo = media.type === 'video';
      
      item.innerHTML = `
        <img class="media-preview" src="${isVideo ? 'icons/icon128.png' : media.url}" alt="Preview">
        <div class="media-info">
          <div class="media-type">${isVideo ? 'Vídeo' : 'Imagem'}</div>
          <div>${media.url.split('/').pop().substring(0, 20)}...</div>
        </div>
        <button class="download-single" title="Baixar">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
        </button>
      `;

      item.querySelector('.download-single').onclick = () => {
        chrome.runtime.sendMessage({ action: "download", url: media.url }).catch(() => {});
      };

      mediaListContainer.appendChild(item);
    });
  }

  // Listen for media from content script
  chrome.runtime.onMessage.addListener((request) => {
    if (request.action === 'media_detected') {
      request.media.forEach(newMedia => {
        if (!detectedMedia.some(m => m.url === newMedia.url)) {
          detectedMedia.push(newMedia);
        }
      });
      updateMediaUI();
    }
  });

});
