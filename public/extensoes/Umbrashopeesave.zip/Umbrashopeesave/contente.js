(function() {
  if (document.getElementById('umbra-shopeesave-container')) return;

  const container = document.createElement('div');
  container.id = 'umbra-shopeesave-container';
  container.style.width = '420px';
  container.style.height = '650px';
  container.style.right = '20px';
  container.style.top = '20px';

  const header = document.createElement('div');
  header.id = 'umbra-shopeesave-header';
  header.innerHTML = `
    <div id="umbra-shopeesave-title">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>
      Umbra ShopeeSave
    </div>
    <div id="umbra-shopeesave-controls">
      <div id="umbra-minimize" class="umbra-control-btn" title="Minimize">_</div>
      <div id="umbra-close" class="umbra-control-btn" title="Close">✕</div>
    </div>
  `;

  const iframe = document.createElement('iframe');
  iframe.id = 'umbra-shopeesave-iframe';
  iframe.src = chrome.runtime.getURL('panel.html');

  const resizer = document.createElement('div');
  resizer.id = 'umbra-shopeesave-resizer';

  container.appendChild(header);
  container.appendChild(iframe);
  container.appendChild(resizer);
  document.body.appendChild(container);

  // Drag logic
  let isDragging = false;
  let offsetX, offsetY;

  header.addEventListener('mousedown', (e) => {
    if (e.target.closest('.umbra-control-btn')) return;
    isDragging = true;
    offsetX = e.clientX - container.offsetLeft;
    offsetY = e.clientY - container.offsetTop;
    container.style.transition = 'none';
    iframe.style.pointerEvents = 'none';
  });

  window.addEventListener('mousemove', (e) => {
    if (isDragging) {
      container.style.left = (e.clientX - offsetX) + 'px';
      container.style.top = (e.clientY - offsetY) + 'px';
      container.style.right = 'auto';
    }
  });

  window.addEventListener('mouseup', () => {
    isDragging = false;
    container.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
    iframe.style.pointerEvents = 'auto';
  });

  // Resize logic
  let isResizing = false;
  let startWidth, startHeight, startX, startY;

  resizer.addEventListener('mousedown', (e) => {
    isResizing = true;
    startWidth = parseInt(document.defaultView.getComputedStyle(container).width, 10);
    startHeight = parseInt(document.defaultView.getComputedStyle(container).height, 10);
    startX = e.clientX;
    startY = e.clientY;
    iframe.style.pointerEvents = 'none';
    e.preventDefault();
  });

  window.addEventListener('mousemove', (e) => {
    if (isResizing) {
      const width = startWidth + (e.clientX - startX);
      const height = startHeight + (e.clientY - startY);
      container.style.width = width + 'px';
      container.style.height = height + 'px';
    }
  });

  window.addEventListener('mouseup', () => {
    isResizing = false;
    iframe.style.pointerEvents = 'auto';
  });

  // Minimize logic
  let isMinimized = false;
  const minimizeBtn = document.getElementById('umbra-minimize');
  minimizeBtn.addEventListener('click', () => {
    isMinimized = !isMinimized;
    if (isMinimized) {
      container.classList.add('minimized');
      minimizeBtn.textContent = '□';
    } else {
      container.classList.remove('minimized');
      minimizeBtn.textContent = '_';
    }
  });

  // Close logic (Robust fix)
  document.getElementById('umbra-close').addEventListener('click', () => {
    container.style.opacity = '0';
    container.style.transform = 'scale(0.95)';
    setTimeout(() => {
      container.remove();
      // Also stop listeners
      if (mediaInterval) clearInterval(mediaInterval);
      if (observer) observer.disconnect();
    }, 200);
  });

  // --- Media Detection & Individual Download ---

  function createDownloadBtn(url, parent) {
    if (parent.querySelector('.umbra-quick-download')) return;
    
    const btn = document.createElement('div');
    btn.className = 'umbra-quick-download';
    btn.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="7 10 12 15 17 10"></polyline><line x1="12" y1="15" x2="12" y2="3"></line></svg>`;
    btn.title = "Baixar esta mídia";
    
    btn.onclick = (e) => {
      e.stopPropagation();
      e.preventDefault();
      try {
        if (chrome.runtime?.id) {
          chrome.runtime.sendMessage({ action: "download", url: url }).catch(() => {});
        }
      } catch (err) {
        console.warn('Umbra: Extension context invalidated. Please refresh the page.');
        cleanup();
      }
    };
    
    // Ensure parent is relative for positioning
    if (getComputedStyle(parent).position === 'static') {
      parent.style.position = 'relative';
    }
    
    parent.appendChild(btn);
  }

  function scanMedia() {
    // Critical context check
    if (!chrome.runtime?.id) {
      cleanup();
      return;
    }

    const videoSelector = '.o5ubXd.rating-media-list__zoomed-video-item';
    const imageSelector = '.HcSdrS.lazyload.rating-media-list__zoomed-image-item';
    
    const videos = document.querySelectorAll(videoSelector);
    const images = document.querySelectorAll(imageSelector);
    
    const detected = [];

    videos.forEach(v => {
      const src = v.src || v.querySelector('source')?.src;
      if (src) {
        createDownloadBtn(src, v.parentElement);
        detected.push({ type: 'video', url: src });
      }
    });

    images.forEach(img => {
      const src = img.src;
      if (src && !src.startsWith('data:')) {
        createDownloadBtn(src, img.parentElement);
        detected.push({ type: 'image', url: src });
      }
    });

    if (detected.length > 0) {
      try {
        chrome.runtime.sendMessage({ action: 'media_detected', media: detected }).catch(() => {});
      } catch (err) {
        cleanup();
      }
    }
  }

  function cleanup() {
    if (mediaInterval) clearInterval(mediaInterval);
    if (observer) observer.disconnect();
    const container = document.getElementById('umbra-shopeesave-container');
    if (container) container.remove();
    console.log('Umbra ShopeeSave: Scripts cleaned up due to context invalidation.');
  }

  // Periodic scan + MutationObserver
  const mediaInterval = setInterval(scanMedia, 2000);
  const observer = new MutationObserver(scanMedia);
  observer.observe(document.body, { childList: true, subtree: true });

})();
