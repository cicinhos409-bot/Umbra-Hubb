chrome.runtime.onInstalled.addListener(() => {
  console.log('Umbra ShopeeSave installed');
});

// Listener for messages
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "ping") {
    sendResponse({ status: "pong" });
  } else if (request.action === "download") {
    chrome.downloads.download({
      url: request.url,
      filename: request.filename || `umbra_shopee_${Date.now()}.${request.url.split('.').pop().split('?')[0]}`
    });
  } else if (request.action === "media_detected") {
    // Forward to panel if open
    chrome.runtime.sendMessage(request).catch(() => {});
  }
});
