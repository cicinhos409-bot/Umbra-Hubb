/**
 * Umbra Vision - Content Script v4.0.0
 * Meta.ai Only + License System
 */

console.log('[Umbra] 🚀 Content Script v4.0.0 loading...');

// ============================================
// LICENSE CHECK
// ============================================
async function checkLicense() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ action: 'GET_STATUS' }, (response) => {
      resolve(response && response.valido);
    });
  });
}

// ============================================
// PLATFORM DETECTION - META.AI ONLY
// ============================================
function detectPlatform() {
  const url = window.location.href;
  const hostname = window.location.hostname;

  if (url.includes('meta.ai') || hostname.includes('meta.ai')) {
    console.log('[Umbra] ✅ Platform: META.AI');
    return 'meta';
  }

  console.log('[Umbra] ⚠️ Platform: UNKNOWN');
  return null;
}

const platform = detectPlatform();

if (!platform) {
  console.log('[Umbra] ❌ Not on supported platform, exiting');
}

// ============================================
// SELECTORS (UPDATED & IMPROVED)
// ============================================
const SELECTORS = {
  meta: {
    // Input textarea - ATUALIZADO para Meta.ai (Janeiro 2025)
    promptTextbox: [
      // Novo seletor principal do Meta.ai
      "div[contenteditable='true'][aria-label*='Message']",
      "div[contenteditable='true'][data-placeholder*='Ask']",
      "div[contenteditable='true'][role='textbox']",
      "div[contenteditable='true'][data-lexical-editor='true']",
      // Fallbacks
      "textarea[placeholder*='Ask']",
      "textarea[placeholder*='Message']",
      "div[contenteditable='true']"
    ],
    
    // Botão de enviar - MÚLTIPLOS SELETORES (inclui "Animar" para geração de imagem/vídeo)
    generateButton: [
      // === SELETORES PARA META.AI (PT-BR) ===
      "button[aria-label='Animar']",
      "button[aria-label='Gerar']",
      "button[aria-label='Criar']",
      "div[role='button'][aria-label='Animar']",
      "div[role='button'][aria-label='Gerar']",
      // === SELETORES PARA META.AI (EN) ===
      "button[aria-label='Generate']",
      "button[aria-label='Create']",
      "button[aria-label='Animate']",
      "button[aria-label='Send']",
      "button[aria-label='Enviar']",
      "div[role='button'][aria-label='Send']",
      "div[role='button'][aria-label='Enviar']",
      "div[role='button'][aria-label='Generate']",
      // === FALLBACK GENÉRICO ===
      "form button[type='submit']",
      "form div[role='button']:last-child",
      // Último recurso - SVG do ícone
      "svg path[d*='M16.0279']",
      "svg path[d*='M5 5.14']"
    ],
    
    // Imagens geradas - MELHORADO
    images: [
      'img[src*="scontent"]',
      'img[src*="fbcdn.net"]',
      'img[src*="lookaside"]',
      'img[src*="cdninstagram"]',
      'img[class*="img"]',
      'img[alt*="AI"]',
      'img[alt*="generated"]',
      'img[alt*="Image"]',
      // Backup: todas as imagens grandes (exclui ícones pequenos)
      'img[width]:not([width="16"]):not([width="24"]):not([width="32"])'
    ],
    
    // Vídeos - MELHORADO
    videos: [
      'video[src*="scontent"]',
      'video[src*="fbcdn"]',
      'video[src*="lookaside"]',
      'video source[src*="scontent"]',
      'video source[src*="fbcdn"]',
      'video source[src*="lookaside"]',
      // Backup: todos os vídeos
      'video'
    ],
    
    // Loading indicators
    loading: [
      '[aria-busy="true"]',
      '[aria-label*="Loading"]',
      '[aria-label*="Generating"]',
      '[class*="loading"]',
      '[class*="generating"]',
      '[class*="spinner"]'
    ]
  }
};

const selectors = SELECTORS.meta;

// ============================================
// STATE
// ============================================
const state = {
  panel: null,
  panelContent: null,
  isMinimized: false,
  isDragging: false,
  isResizing: false,
  dragOffset: { x: 0, y: 0 },
  resizeStart: { width: 0, height: 0, x: 0, y: 0 },
  
  // Generation state
  isGenerating: false,
  isPaused: false,
  prompts: [],
  currentIndex: 0,
  successCount: 0,
  failCount: 0,
  
  // Settings
  platform: platform,
  aspectRatio: '16:9',
  interval: 5,
  imagesPerPrompt: 1,
  generationType: 'image', // 'image' ou 'video'
  
  // Tracking de imagens/vídeos processados
  processedImages: new Set(),
  processedVideos: new Set()
};

// ============================================
// IMAGE/VIDEO VALIDATION FUNCTIONS
// ============================================

/**
 * Valida se é uma imagem gerada (não ícone/avatar/perfil)
 * Versão 3.0.8 - Validação separada por plataforma
 */
function isValidGeneratedImage(src, imgElement) {
  return isValidMetaImage(src, imgElement);
}

/**
 * Validação de imagens geradas pelo Meta.ai
 */
function isValidMetaImage(src, imgElement) {
  const lowercaseSrc = src.toLowerCase();
  
  // Padrões inválidos na URL (ícones, avatares, etc)
  const invalidUrlPatterns = [
    'emoji', 'avatar', 'icon', 'logo', 'profile', 'thumb',
    '16x16', '32x32', '48x48', '64x64', '128x128', 'favicon',
    'placeholder', 'loading', 'spinner', 'sticker',
    '.svg', '.gif', '_s.jpg', '_t.jpg',
    'profile_pic', 'userpic', 'pp.jpg', 'pp.png',
    '/p/', '/t/', '/s/'
  ];
  
  if (invalidUrlPatterns.some(p => lowercaseSrc.includes(p))) {
    return false;
  }
  
  // Padrões válidos (CDN do Meta para imagens geradas)
  const validUrlPatterns = ['scontent', 'fbcdn', 'lookaside'];
  const hasValidDomain = validUrlPatterns.some(p => lowercaseSrc.includes(p));
  if (!hasValidDomain) return false;
  
  // Filtro por tamanho
  if (imgElement) {
    const naturalW = imgElement.naturalWidth || 0;
    const naturalH = imgElement.naturalHeight || 0;
    const displayW = imgElement.width || imgElement.offsetWidth || 0;
    const displayH = imgElement.height || imgElement.offsetHeight || 0;
    
    if (naturalW > 0 && naturalH > 0) {
      if (naturalW < 200 || naturalH < 200) return false;
      const isSquare = Math.abs(naturalW - naturalH) < 10;
      if (isSquare && naturalW < 400) return false;
    }
    
    if (displayW > 0 && displayW < 60 && displayH > 0 && displayH < 60) return false;
    
    const avatarParent = imgElement.closest([
      '[class*="avatar"]', '[class*="profile"]', '[class*="user-pic"]',
      '[class*="userpic"]', '[class*="author"]', '[class*="sender"]',
      '[data-testid*="avatar"]', '[aria-label*="profile"]',
      'header', 'nav', '.nav', '[role="banner"]'
    ].join(','));
    
    if (avatarParent) return false;
    
    const alt = (imgElement.getAttribute('alt') || '').toLowerCase();
    const altInvalid = ['profile', 'avatar', 'user', 'photo of', 'picture of', 'pp', 'icon'];
    if (altInvalid.some(a => alt === a || alt.startsWith(a + ' '))) return false;
    
    const resultParent = imgElement.closest([
      '[class*="result"]', '[class*="generated"]', '[class*="image-"]',
      '[class*="imagine"]', '[class*="output"]', '[class*="media"]',
      '[class*="attachment"]', '[class*="content"]', 'article',
      '[data-testid*="image"]', '[data-testid*="result"]'
    ].join(','));
    
    const naturalWCheck = imgElement.naturalWidth || 0;
    if (!resultParent && naturalWCheck < 400) return false;
  }
  
  return true;
}

/**
 * Valida se é um vídeo válido (não thumbnail/poster)
 */
function isValidVideoUrl(url) {
  if (!url || !url.startsWith('http')) {
    // Aceitar blobs de vídeo
    if (url && url.startsWith('blob:')) return true;
    return false;
  }
  
  const lowercaseUrl = url.toLowerCase();
  
  // URLs inválidas (thumbnails, posters, etc)
  const invalidPatterns = [
    'thumbnail', 'preview', 'poster', 'avatar', 
    'icon', 'logo', '.jpg', '.png', '.gif', '.webp'
  ];
  
  if (invalidPatterns.some(p => lowercaseUrl.includes(p))) {
    return false;
  }
  
  // URLs válidas para vídeos do Meta
  const validPatterns = [
    'scontent', 'fbcdn', 'video', '.mp4', 
    'lookaside', 'fna.fbcdn', 'video.fna'
  ];
  
  return validPatterns.some(p => lowercaseUrl.includes(p));
}

/**
 * Coleta todos os vídeos válidos da página
 */
function collectVideos() {
  const allVideos = [];
  const seenUrls = new Set();
  
  console.log('[Umbra] 🎬 Coletando vídeos...');
  
  // Método 1: Elementos <video> diretos
  const videoElements = document.querySelectorAll('video');
  console.log('[Umbra] Found', videoElements.length, 'video elements');
  
  for (const video of videoElements) {
    let videoUrl = null;
    
    // Verificar src do video
    if (video.src && isValidVideoUrl(video.src)) {
      videoUrl = video.src;
    }
    
    // Verificar source dentro do video
    if (!videoUrl) {
      const source = video.querySelector('source');
      if (source && source.src && isValidVideoUrl(source.src)) {
        videoUrl = source.src;
      }
    }
    
    // Verificar currentSrc
    if (!videoUrl && video.currentSrc && isValidVideoUrl(video.currentSrc)) {
      videoUrl = video.currentSrc;
    }
    
    if (videoUrl && !seenUrls.has(videoUrl) && !state.processedVideos.has(videoUrl)) {
      allVideos.push({
        url: videoUrl,
        element: video,
        poster: video.poster || null
      });
      seenUrls.add(videoUrl);
      console.log('[Umbra] ✓ Video found:', videoUrl.substring(0, 60) + '...');
    }
  }
  
  // Método 2: Buscar em seletores específicos
  const videoSelectors = selectors.videos || [];
  for (const selector of videoSelectors) {
    try {
      const elements = document.querySelectorAll(selector);
      for (const el of elements) {
        let videoUrl = null;
        
        if (el.tagName === 'VIDEO') {
          videoUrl = el.src || el.currentSrc;
          if (!videoUrl) {
            const source = el.querySelector('source');
            if (source) videoUrl = source.src;
          }
        } else if (el.tagName === 'SOURCE') {
          videoUrl = el.src;
        }
        
        if (videoUrl && isValidVideoUrl(videoUrl) && !seenUrls.has(videoUrl) && !state.processedVideos.has(videoUrl)) {
          allVideos.push({
            url: videoUrl,
            element: el,
            poster: el.poster || null
          });
          seenUrls.add(videoUrl);
        }
      }
    } catch (e) {
      continue;
    }
  }
  
  console.log('[Umbra] Total unique videos:', allVideos.length);
  return allVideos;
}

// ============================================
// UTILITY FUNCTIONS
// ============================================
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function isVisible(element) {
  if (!element) return false;
  const rect = element.getBoundingClientRect();
  const style = window.getComputedStyle(element);
  return rect.width > 0 && rect.height > 0 && 
         style.display !== 'none' && style.visibility !== 'hidden' && 
         style.opacity !== '0';
}

async function waitForElement(selectorList, timeout = 10000) {
  const selectors = Array.isArray(selectorList) ? selectorList : [selectorList];
  const startTime = Date.now();
  
  console.log('[Umbra] 🔍 Waiting for element...', selectors);
  
  // Palavras-chave de botões de geração (PT-BR e EN)
  const generateKeywords = [
    'animar', 'gerar', 'criar', 'generate', 'create', 'animate', 
    'send', 'enviar', 'submit', 'imagine', 'run'
  ];
  
  while (Date.now() - startTime < timeout) {
    for (let i = 0; i < selectors.length; i++) {
      const selector = selectors[i];
      try {
        let element = document.querySelector(selector);
        
        if (!element && selector.includes('svg')) {
          const svgEl = document.querySelector(selector);
          if (svgEl) {
            element = svgEl.closest('button, div[role="button"]');
          }
        }
        
        if (element && isVisible(element)) {
          console.log(`[Umbra] ✅ Found element with selector #${i + 1}: ${selector}`);
          return element;
        }
      } catch (e) {
        console.log(`[Umbra] ⚠️ Selector failed: ${selector}`);
        continue;
      }
    }
    
    // ===== FALLBACK INTELIGENTE: busca botão por aria-label ou texto =====
    // Só ativa se a lista de seletores for a de generateButton
    if (selectorList === selectors && selectors.some(s => s.includes('Animar') || s.includes('Send') || s.includes('Generate'))) {
      const allButtons = document.querySelectorAll('button, div[role="button"]');
      for (const btn of allButtons) {
        if (!isVisible(btn)) continue;
        const label = (btn.getAttribute('aria-label') || btn.textContent || '').toLowerCase().trim();
        if (generateKeywords.some(kw => label === kw || label.startsWith(kw))) {
          console.log(`[Umbra] ✅ Found button via keyword fallback: "${label}"`);
          return btn;
        }
      }
    }
    
    await sleep(200);
  }
  
  console.log('[Umbra] ❌ Element not found after timeout');
  return null;
}

function dispatchClick(element) {
  if (!element) return false;
  
  console.log('[Umbra] 🖱️ Attempting click on:', element.tagName, element.className);
  
  try {
    // Método 1: Eventos de mouse completos
    const eventOptions = {
      bubbles: true,
      cancelable: true,
      view: window,
      clientX: 0,
      clientY: 0
    };
    
    element.dispatchEvent(new MouseEvent('mousedown', eventOptions));
    element.dispatchEvent(new MouseEvent('mouseup', eventOptions));
    element.dispatchEvent(new MouseEvent('click', eventOptions));
    
    console.log('[Umbra] ✅ Click events dispatched');
    return true;
    
  } catch (e) {
    console.log('[Umbra] ⚠️ Event dispatch failed, trying direct click');
    
    // Método 2: Click direto
    try {
      element.click();
      console.log('[Umbra] ✅ Direct click successful');
      return true;
    } catch (e2) {
      console.log('[Umbra] ❌ All click methods failed');
      return false;
    }
  }
}

async function dispatchInput(element, value) {
  if (!element) {
    console.log('[Umbra] ❌ Element is null');
    return false;
  }
  
  console.log('[Umbra] ⌨️ Attempting text insertion...');
  console.log('[Umbra] Element:', element.tagName, 'class:', element.className.substring(0, 30));
  console.log('[Umbra] ContentEditable:', element.contentEditable);
  console.log('[Umbra] Text:', value.substring(0, 50) + '...');
  
  // Para contenteditable (Meta.ai)
  if (element.contentEditable === 'true' || element.getAttribute('contenteditable') === 'true') {
    console.log('[Umbra] 🎯 Using contenteditable methods');

    // ===== LIMPEZA FORÇADA ANTES DE TUDO =====
    // Garante que o campo esteja 100% vazio antes de inserir novo prompt
    try {
      element.focus();
      await sleep(200);

      // Selecionar tudo com Ctrl+A e deletar
      element.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', code: 'KeyA', ctrlKey: true, bubbles: true }));
      await sleep(50);
      element.dispatchEvent(new KeyboardEvent('keydown', { key: 'Delete', code: 'Delete', bubbles: true }));
      element.dispatchEvent(new KeyboardEvent('keydown', { key: 'Backspace', code: 'Backspace', bubbles: true }));
      await sleep(50);

      // Limpeza direta
      element.innerHTML = '';
      element.innerText = '';
      element.textContent = '';

      // Selecionar e deletar via Selection API
      const range = document.createRange();
      range.selectNodeContents(element);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
      document.execCommand('delete', false, null);

      element.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
      await sleep(150);

      console.log('[Umbra] 🧹 Field cleared, current content:', (element.innerText || '(empty)').substring(0, 30));
    } catch (e) {
      console.log('[Umbra] ⚠️ Clear error (non-fatal):', e.message);
    }
    // ===== FIM DA LIMPEZA =====
    
    // Método 1: execCommand selectAll + insertText (mais confiável para Lexical/React)
    try {
      console.log('[Umbra] 🔄 Method 1: execCommand selectAll + insertText');
      element.focus();
      await sleep(100);

      // Selecionar tudo e substituir
      document.execCommand('selectAll', false, null);
      await sleep(50);
      document.execCommand('insertText', false, value);

      element.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
      element.dispatchEvent(new InputEvent('input', { bubbles: true, data: value, inputType: 'insertText' }));

      await sleep(100);

      const check = element.innerText || element.textContent || '';
      if (check.trim().includes(value.substring(0, 15))) {
        console.log('[Umbra] ✅ Method 1 SUCCESS!');
        return true;
      }
      console.log('[Umbra] ⚠️ Method 1 failed, current:', check.substring(0, 30));
    } catch (e) {
      console.log('[Umbra] ⚠️ Method 1 error:', e.message);
    }
    
    // Método 2: innerText com limpeza extra
    try {
      console.log('[Umbra] 🔄 Method 2: innerText');
      element.focus();
      await sleep(100);
      
      element.innerText = '';
      await sleep(80);
      element.innerText = value;
      
      element.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
      element.dispatchEvent(new Event('change', { bubbles: true }));
      element.dispatchEvent(new InputEvent('input', { bubbles: true, data: value }));
      
      await sleep(100);
      
      const check = element.innerText || element.textContent || '';
      if (check.trim().includes(value.substring(0, 15))) {
        console.log('[Umbra] ✅ Method 2 SUCCESS!');
        return true;
      }
      console.log('[Umbra] ⚠️ Method 2 failed');
    } catch (e) {
      console.log('[Umbra] ⚠️ Method 2 error:', e.message);
    }

    // Método 3: textContent
    try {
      console.log('[Umbra] 🔄 Method 3: textContent');
      element.focus();
      await sleep(100);
      
      element.textContent = '';
      await sleep(80);
      element.textContent = value;
      
      element.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
      element.dispatchEvent(new Event('change', { bubbles: true }));
      
      await sleep(100);
      
      const check = element.innerText || element.textContent || '';
      if (check.trim().includes(value.substring(0, 15))) {
        console.log('[Umbra] ✅ Method 3 SUCCESS!');
        return true;
      }
      console.log('[Umbra] ⚠️ Method 3 failed');
    } catch (e) {
      console.log('[Umbra] ⚠️ Method 3 error:', e.message);
    }
    
    // Método 4: innerHTML com parágrafo
    try {
      console.log('[Umbra] 🔄 Method 4: innerHTML');
      element.focus();
      element.innerHTML = '';
      await sleep(50);
      element.innerHTML = `<p>${value}</p>`;
      element.dispatchEvent(new Event('input', { bubbles: true, composed: true }));
      
      await sleep(100);
      
      const check = element.innerText || '';
      if (check.trim().length > 5) {
        console.log('[Umbra] ✅ Method 4 SUCCESS!');
        return true;
      }
    } catch (e) {
      console.log('[Umbra] ⚠️ Method 4 error:', e.message);
    }
  }
  
  // Para textarea/input
  if (element.tagName === 'TEXTAREA' || element.tagName === 'INPUT') {
    console.log('[Umbra] 🎯 Using textarea/input method');
    try {
      element.focus();
      element.value = '';
      await sleep(50);
      element.value = value;
      element.dispatchEvent(new Event('input', { bubbles: true }));
      element.dispatchEvent(new Event('change', { bubbles: true }));
      
      if (element.value === value) {
        console.log('[Umbra] ✅ Textarea method SUCCESS');
        return true;
      }
    } catch (e) {
      console.log('[Umbra] ⚠️ Textarea error:', e.message);
    }
  }
  
  console.log('[Umbra] ❌ ALL METHODS FAILED');
  console.log('[Umbra] Final:', (element.innerText || element.value || '(empty)').substring(0, 50));
  return false;
}

// ============================================
// PANEL CREATION
// ============================================
async function createPanel() {
  if (state.panel) {
    console.log('[Umbra] ⚠️ Panel already exists');
    return;
  }
  
  console.log('[Umbra] 📦 Creating floating panel...');
  
  // Create main panel container
  state.panel = document.createElement('div');
  state.panel.id = 'umbra-vision-panel';
  
  // Create header
  const header = document.createElement('div');
  header.className = 'umbra-panel-header';
  header.innerHTML = `
    <div class="umbra-panel-logo">
      <div class="umbra-logo-icon">💎</div>
      <div class="umbra-logo-text">Umbra Vision</div>
    </div>
    <div class="umbra-panel-actions">
      <button class="umbra-header-btn minimize" id="umbra-minimize-btn" title="Minimizar">−</button>
      <button class="umbra-header-btn close" id="umbra-close-btn" title="Fechar">×</button>
    </div>
  `;
  
  // Create content container
  state.panelContent = document.createElement('div');
  state.panelContent.className = 'umbra-panel-content';
  
  // Create resize handle
  const resizeHandle = document.createElement('div');
  resizeHandle.className = 'umbra-resize-handle';
  
  // Panel HTML inline (não precisa de fetch)
  const panelHTMLContent = `
    <!-- ============ TELA DE LICENÇA ============ -->
    <div id="umbra-license-view" style="display:none; padding: 8px 0;">
      <div class="umbra-section" style="text-align:center; border: 1px solid #BD00FF33; background: #15151f;">
        <div style="font-size: 32px; margin-bottom: 12px;">🔒</div>
        <div style="font-size: 15px; font-weight: 700; margin-bottom: 6px; background: linear-gradient(135deg, #00D9FF, #BD00FF); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;">Umbra Vision</div>
        <div style="font-size: 12px; color: #a0a0b0; margin-bottom: 16px; line-height: 1.5;">Insira sua licença do Umbra Hub<br>para liberar o acesso:</div>
        <input
          type="text"
          id="umbra-license-input"
          class="umbra-input"
          placeholder="UMBRA-XXXX-XXXX-XXXX"
          autocomplete="off"
          spellcheck="false"
          style="text-align:center; letter-spacing:2px; margin-bottom:10px;"
        />
        <button class="umbra-btn umbra-btn-primary" id="umbra-license-btn" style="width:100%;">
          🔑 Ativar Licença
        </button>
        <p id="umbra-license-error" style="color:#FF4444; font-size:12px; margin-top:10px; min-height:16px;"></p>
        <a href="https://umbrahubb.vercel.app" target="_blank" style="display:block; margin-top:8px; font-size:11px; color:#555; text-decoration:none;">
          Não tem licença? <span style="color:#00D9FF;">Adquirir →</span>
        </a>
      </div>
    </div>

    <!-- ============ CONTEÚDO PRINCIPAL ============ -->
    <div id="umbra-main-view" style="display:none;">

    <!-- Status -->
    <div class="umbra-section">
      <div class="umbra-status connected" id="umbra-status">
        <span class="umbra-status-dot"></span>
        <span id="umbra-status-text">Meta.ai</span>
      </div>
    </div>

    <!-- Generation Type -->
    <div class="umbra-section" id="umbra-type-section">
      <div class="umbra-section-title">🎬 Tipo de Geração</div>
      <div class="umbra-btn-group">
        <button class="umbra-btn umbra-btn-secondary active" data-type="image">🖼️ Imagens</button>
        <button class="umbra-btn umbra-btn-secondary" data-type="video">🎥 Vídeos</button>
      </div>
      <div class="umbra-text-small umbra-text-muted umbra-mt-1" style="text-align: center;">
        <span id="umbra-type-hint">Use Meta.ai Imagine para imagens</span>
      </div>
    </div>

    <!-- Aspect Ratio -->
    <div class="umbra-section">
      <div class="umbra-section-title">📐 Formato</div>
      <div class="umbra-btn-group">
        <button class="umbra-btn umbra-btn-secondary active" data-ratio="16:9">16:9</button>
        <button class="umbra-btn umbra-btn-secondary" data-ratio="1:1">1:1</button>
        <button class="umbra-btn umbra-btn-secondary" data-ratio="9:16">9:16</button>
      </div>
    </div>

    <!-- Prompts Input -->
    <div class="umbra-section">
      <div class="umbra-section-title">
        ✨ Prompts
        <span class="umbra-text-muted umbra-text-small" id="umbra-prompt-count">(0)</span>
      </div>
      <textarea 
        id="umbra-prompts-input" 
        class="umbra-textarea" 
        placeholder="Cole seus prompts aqui (um por linha)

Exemplo:
A futuristic city at sunset
A magical forest with glowing mushrooms
A cute robot playing guitar"
        spellcheck="false"
      ></textarea>
      <div class="umbra-btn-group umbra-mt-1">
        <button class="umbra-btn umbra-btn-secondary" id="umbra-clear-btn">🗑️ Limpar</button>
        <button class="umbra-btn umbra-btn-secondary" id="umbra-paste-btn">📋 Colar</button>
      </div>
    </div>

    <!-- Settings -->
    <div class="umbra-section">
      <div class="umbra-section-title">⚙️ Configurações</div>
      
      <label class="umbra-label">
        Intervalo entre prompts (segundos)
        <input type="number" id="umbra-interval" class="umbra-input" value="5" min="3" max="60">
      </label>
      
      <label class="umbra-label umbra-mt-1">
        Imagens por prompt
        <input type="number" id="umbra-images" class="umbra-input" value="1" min="1" max="4">
      </label>
    </div>

    <!-- Progress -->
    <div class="umbra-section umbra-hidden" id="umbra-progress-section">
      <div class="umbra-section-title">📊 Progresso</div>
      
      <div class="umbra-progress">
        <div class="umbra-progress-bar">
          <div class="umbra-progress-fill" id="umbra-progress-fill" style="width: 0%"></div>
        </div>
        <div class="umbra-progress-text">
          <span id="umbra-progress-text">0%</span>
          <span id="umbra-progress-count">0 / 0</span>
        </div>
      </div>
      
      <div class="umbra-progress-text">
        <span>✅ Sucesso: <strong id="umbra-success-count">0</strong></span>
        <span>❌ Falhas: <strong id="umbra-fail-count">0</strong></span>
      </div>
      
      <div class="umbra-text-muted umbra-text-small umbra-mt-1" id="umbra-current-prompt">
        Aguardando...
      </div>
    </div>

    <!-- Action Buttons -->
    <div class="umbra-section">
      <button class="umbra-btn umbra-btn-primary" id="umbra-start-btn" style="width: 100%">
        ▶️ Iniciar Geração
      </button>
      
      <div class="umbra-btn-group umbra-mt-1 umbra-hidden" id="umbra-control-btns">
        <button class="umbra-btn umbra-btn-secondary" id="umbra-pause-btn">⏸️ Pausar</button>
        <button class="umbra-btn umbra-btn-danger" id="umbra-stop-btn">⏹️ Parar</button>
      </div>
    </div>

    <!-- Download Section -->
    <div class="umbra-section">
      <div class="umbra-section-title">📥 Download de Imagens</div>
      <div class="umbra-btn-group">
        <button class="umbra-btn umbra-btn-secondary" id="umbra-download-visible">Visíveis</button>
        <button class="umbra-btn umbra-btn-secondary" id="umbra-download-all">Todas</button>
      </div>
      <div class="umbra-btn-group umbra-mt-1">
        <button class="umbra-btn umbra-btn-secondary" id="umbra-debug-btn" style="width:100%; font-size:11px; opacity:0.7;">🔍 Debug: Listar imagens no console</button>
      </div>
    </div>

    <!-- Video Download Section -->
    <div class="umbra-section">
      <div class="umbra-section-title">🎬 Download de Vídeos</div>
      <div class="umbra-btn-group">
        <button class="umbra-btn umbra-btn-secondary" id="umbra-download-videos">Baixar Vídeos</button>
      </div>
      <div class="umbra-text-small umbra-text-muted umbra-mt-1" style="text-align: center;">
        <span id="umbra-video-count">Verificando...</span>
      </div>
    </div>

    <!-- Footer -->
    <div class="umbra-section" style="text-align: center;">
      <div class="umbra-text-small umbra-text-muted">
        Umbra Vision v4.0.0 •
        <a href="#" id="umbra-logout-btn" style="color: #555; text-decoration: none; font-size: 11px;">Sair da licença</a>
      </div>
    </div>

    </div><!-- fim umbra-main-view -->
  `;
  
  state.panelContent.innerHTML = panelHTMLContent;
  console.log('[Umbra] ✅ Panel HTML loaded (inline)');
  
  // Assemble panel
  state.panel.appendChild(header);
  state.panel.appendChild(state.panelContent);
  state.panel.appendChild(resizeHandle);
  
  // Add to page
  document.body.appendChild(state.panel);
  
  // Initialize
  initializeDragging(header);
  initializeResizing(resizeHandle);
  initializePanelControls();
  initializePanelEvents();
  initializeLicenseView();
  
  // Update platform status
  updatePlatformStatus();
  
  console.log('[Umbra] ✅ Panel created and initialized!');
}

// ============================================
// LICENSE VIEW (dentro do painel flutuante)
// ============================================
async function initializeLicenseView() {
  const licenseView = state.panelContent.querySelector('#umbra-license-view');
  const mainView    = state.panelContent.querySelector('#umbra-main-view');
  const licenseInput = state.panelContent.querySelector('#umbra-license-input');
  const licenseBtn   = state.panelContent.querySelector('#umbra-license-btn');
  const licenseError = state.panelContent.querySelector('#umbra-license-error');
  const logoutBtn    = state.panelContent.querySelector('#umbra-logout-btn');

  // Verificar licença ao abrir
  const licensed = await checkLicense();
  if (licensed) {
    licenseView.style.display = 'none';
    mainView.style.display = 'block';
  } else {
    licenseView.style.display = 'block';
    mainView.style.display = 'none';
  }

  // Formatar input (maiúsculas)
  licenseInput.addEventListener('input', () => {
    licenseInput.value = licenseInput.value.toUpperCase();
  });

  // Enter para ativar
  licenseInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') licenseBtn.click();
  });

  // Botão ativar
  licenseBtn.addEventListener('click', async () => {
    const chave = licenseInput.value.trim().toUpperCase();
    if (!chave) { licenseError.textContent = 'Digite sua chave de licença.'; return; }

    licenseBtn.disabled = true;
    licenseBtn.textContent = '⏳ Validando...';
    licenseError.textContent = '';

    chrome.runtime.sendMessage({ action: 'ACTIVATE', chave }, (response) => {
      licenseBtn.disabled = false;
      licenseBtn.textContent = '🔑 Ativar Licença';

      if (response && response.valido) {
        licenseView.style.display = 'none';
        mainView.style.display = 'block';
        showToast('✅ Licença ativada com sucesso!');
      } else {
        licenseError.textContent = (response && response.motivo) || 'Chave inválida ou limite atingido.';
      }
    });
  });

  // Logout
  if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
      e.preventDefault();
      chrome.runtime.sendMessage({ action: 'LOGOUT' }, () => {
        mainView.style.display = 'none';
        licenseView.style.display = 'block';
        licenseInput.value = '';
        licenseError.textContent = '';
        showToast('👋 Licença removida');
      });
    });
  }
}

function updatePlatformStatus() {
  if (!state.panelContent) return;
  
  const statusEl = state.panelContent.querySelector('#umbra-status');
  const statusText = state.panelContent.querySelector('#umbra-status-text');
  
  if (statusEl && statusText) {
    if (platform) {
      statusEl.className = 'umbra-status connected';
      statusText.textContent = 'Meta.ai';
    } else {
      statusEl.className = 'umbra-status disconnected';
      statusText.textContent = 'Plataforma não suportada';
    }
  }
}

// ============================================
// DRAGGING
// ============================================
function initializeDragging(header) {
  header.addEventListener('mousedown', (e) => {
    if (e.target.closest('.umbra-header-btn')) return;
    
    state.isDragging = true;
    state.panel.classList.add('dragging');
    
    const rect = state.panel.getBoundingClientRect();
    state.dragOffset = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
  });
  
  document.addEventListener('mousemove', (e) => {
    if (!state.isDragging) return;
    
    const x = e.clientX - state.dragOffset.x;
    const y = e.clientY - state.dragOffset.y;
    
    state.panel.style.left = `${x}px`;
    state.panel.style.top = `${y}px`;
    state.panel.style.right = 'auto';
    state.panel.style.bottom = 'auto';
  });
  
  document.addEventListener('mouseup', () => {
    if (state.isDragging) {
      state.isDragging = false;
      state.panel.classList.remove('dragging');
    }
  });
}

// ============================================
// RESIZING
// ============================================
function initializeResizing(resizeHandle) {
  resizeHandle.addEventListener('mousedown', (e) => {
    e.preventDefault();
    state.isResizing = true;
    state.panel.classList.add('resizing');
    
    const rect = state.panel.getBoundingClientRect();
    state.resizeStart = {
      width: rect.width,
      height: rect.height,
      x: e.clientX,
      y: e.clientY
    };
  });
  
  document.addEventListener('mousemove', (e) => {
    if (!state.isResizing) return;
    
    const deltaX = e.clientX - state.resizeStart.x;
    const deltaY = e.clientY - state.resizeStart.y;
    
    const newWidth = Math.max(320, state.resizeStart.width + deltaX);
    const newHeight = Math.max(200, state.resizeStart.height + deltaY);
    
    state.panel.style.width = `${newWidth}px`;
    state.panel.style.height = `${newHeight}px`;
  });
  
  document.addEventListener('mouseup', () => {
    if (state.isResizing) {
      state.isResizing = false;
      state.panel.classList.remove('resizing');
    }
  });
}

// ============================================
// PANEL CONTROLS
// ============================================
function initializePanelControls() {
  // Minimize/Maximize
  const minimizeBtn = state.panel.querySelector('#umbra-minimize-btn');
  minimizeBtn.addEventListener('click', () => {
    state.isMinimized = !state.isMinimized;
    state.panel.classList.toggle('minimized', state.isMinimized);
    minimizeBtn.textContent = state.isMinimized ? '+' : '−';
    minimizeBtn.title = state.isMinimized ? 'Expandir' : 'Minimizar';
  });
  
  // Close
  const closeBtn = state.panel.querySelector('#umbra-close-btn');
  closeBtn.addEventListener('click', () => {
    state.panel.classList.add('hidden');
  });
}

// ============================================
// PANEL EVENTS
// ============================================
function initializePanelEvents() {
  // Generation Type selector (image/video)
  state.panelContent.querySelectorAll('[data-type]').forEach(btn => {
    btn.addEventListener('click', () => {
      state.panelContent.querySelectorAll('[data-type]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.generationType = btn.dataset.type;
      
      // Atualizar hint
      const hintEl = state.panelContent.querySelector('#umbra-type-hint');
      if (hintEl) {
        hintEl.textContent = state.generationType === 'video' ? 
          'Use Meta.ai Imagine Video para vídeos' : 
          'Use Meta.ai Imagine para imagens';
      }
      
      console.log('[Umbra] Generation type changed to:', state.generationType);
    });
  });
  
  // Aspect ratio
  state.panelContent.querySelectorAll('[data-ratio]').forEach(btn => {
    btn.addEventListener('click', () => {
      state.panelContent.querySelectorAll('[data-ratio]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.aspectRatio = btn.dataset.ratio;
    });
  });
  
  // Prompt count
  const promptsInput = state.panelContent.querySelector('#umbra-prompts-input');
  if (promptsInput) {
    promptsInput.addEventListener('input', () => {
      const prompts = promptsInput.value.split('\n').filter(p => p.trim());
      state.panelContent.querySelector('#umbra-prompt-count').textContent = `(${prompts.length})`;
    });
  }
  
  // Clear button
  const clearBtn = state.panelContent.querySelector('#umbra-clear-btn');
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      if (promptsInput) {
        promptsInput.value = '';
        state.panelContent.querySelector('#umbra-prompt-count').textContent = '(0)';
        showToast('🗑️ Prompts limpos');
      }
    });
  }
  
  // Paste button
  const pasteBtn = state.panelContent.querySelector('#umbra-paste-btn');
  if (pasteBtn) {
    pasteBtn.addEventListener('click', async () => {
      try {
        const text = await navigator.clipboard.readText();
        if (promptsInput) {
          promptsInput.value = text;
          const prompts = text.split('\n').filter(p => p.trim());
          state.panelContent.querySelector('#umbra-prompt-count').textContent = `(${prompts.length})`;
          showToast('📋 Prompts colados');
        }
      } catch (error) {
        showToast('❌ Erro ao colar. Use Ctrl+V');
      }
    });
  }
  
  // Settings
  const intervalInput = state.panelContent.querySelector('#umbra-interval');
  const imagesInput = state.panelContent.querySelector('#umbra-images');
  
  if (intervalInput) {
    intervalInput.addEventListener('change', () => {
      state.interval = parseInt(intervalInput.value);
    });
  }
  
  if (imagesInput) {
    imagesInput.addEventListener('change', () => {
      state.imagesPerPrompt = parseInt(imagesInput.value);
    });
  }
  
  // Start button
  const startBtn = state.panelContent.querySelector('#umbra-start-btn');
  if (startBtn) {
    startBtn.addEventListener('click', startGeneration);
  }
  
  // Pause button
  const pauseBtn = state.panelContent.querySelector('#umbra-pause-btn');
  if (pauseBtn) {
    pauseBtn.addEventListener('click', togglePause);
  }
  
  // Stop button
  const stopBtn = state.panelContent.querySelector('#umbra-stop-btn');
  if (stopBtn) {
    stopBtn.addEventListener('click', stopGeneration);
  }
  
  // Download buttons
  const downloadVisibleBtn = state.panelContent.querySelector('#umbra-download-visible');
  const downloadAllBtn = state.panelContent.querySelector('#umbra-download-all');
  const downloadVideosBtn = state.panelContent.querySelector('#umbra-download-videos');
  
  if (downloadVisibleBtn) {
    downloadVisibleBtn.addEventListener('click', () => downloadImages('visible'));
  }
  
  if (downloadAllBtn) {
    downloadAllBtn.addEventListener('click', () => downloadImages('all'));
  }
  
  if (downloadVideosBtn) {
    downloadVideosBtn.addEventListener('click', () => downloadVideos('all'));
  }

  // Debug button
  const debugBtn = state.panelContent.querySelector('#umbra-debug-btn');
  if (debugBtn) {
    debugBtn.addEventListener('click', () => debugListAllImages());
  }
  
  // Atualizar contador de vídeos periodicamente
  updateVideoCount();
  setInterval(updateVideoCount, 5000);
}

// ============================================
// VIDEO COUNT UPDATER
// ============================================
function updateVideoCount() {
  if (!state.panelContent) return;
  
  const videoCountEl = state.panelContent.querySelector('#umbra-video-count');
  if (!videoCountEl) return;
  
  const videos = collectVideos();
  videoCountEl.textContent = videos.length > 0 ? 
    `${videos.length} vídeo${videos.length > 1 ? 's' : ''} encontrado${videos.length > 1 ? 's' : ''}` : 
    'Nenhum vídeo encontrado';
}

// ============================================
// GENERATION
// ============================================
async function startGeneration() {
  const promptsInput = state.panelContent.querySelector('#umbra-prompts-input');
  if (!promptsInput) return;
  
  const promptText = promptsInput.value.trim();
  if (!promptText) {
    showToast('⚠️ Cole seus prompts primeiro');
    return;
  }
  
  if (!platform) {
    showToast('❌ Plataforma não suportada');
    return;
  }
  
  // Verificar se está no contexto correto
  if (state.generationType === 'video' && state.platform === 'meta') {
    const url = window.location.href;
    if (!url.includes('imagine') && !url.includes('video')) {
      showToast('⚠️ Acesse Meta.ai Imagine Video primeiro!');
      console.log('[Umbra] ⚠️ Video generation requires Imagine Video page');
      console.log('[Umbra] Current URL:', url);
      return;
    }
  }
  
  state.prompts = promptText.split('\n').filter(p => p.trim());
  if (state.prompts.length === 0) {
    showToast('⚠️ Nenhum prompt válido');
    return;
  }
  
  state.isGenerating = true;
  state.isPaused = false;
  state.currentIndex = 0;
  state.successCount = 0;
  state.failCount = 0;
  
  console.log('[Umbra] 🚀 Starting generation with', state.prompts.length, 'prompts');
  console.log('[Umbra] 🎬 Generation type:', state.generationType);
  console.log('[Umbra] 🎯 Platform:', state.platform);
  
  if (state.generationType === 'video') {
    showToast(`🎥 Gerando ${state.prompts.length} vídeos...`);
  } else {
    showToast(`🖼️ Gerando ${state.prompts.length} imagens...`);
  }
  
  // Update UI
  state.panelContent.querySelector('#umbra-start-btn').disabled = true;
  state.panelContent.querySelector('#umbra-control-btns').classList.remove('umbra-hidden');
  state.panelContent.querySelector('#umbra-progress-section').classList.remove('umbra-hidden');
  
  showToast(`🚀 Iniciando! ${state.prompts.length} prompts`);
  
  // Start processing
  processNextPrompt();
}

async function processNextPrompt() {
  if (!state.isGenerating || state.isPaused) {
    console.log('[Umbra] ⏸️ Generation paused or stopped');
    return;
  }
  
  if (state.currentIndex >= state.prompts.length) {
    console.log('[Umbra] ✅ All prompts processed');
    finishGeneration();
    return;
  }
  
  const currentPrompt = state.prompts[state.currentIndex];
  console.log(`[Umbra] 📝 Processing prompt ${state.currentIndex + 1}/${state.prompts.length}`);
  console.log('[Umbra] Prompt:', currentPrompt.substring(0, 50) + '...');
  
  updateProgress();
  
  try {
    // Step 1: Find input
    console.log('[Umbra] 🔍 Step 1: Finding input...');
    const input = await waitForElement(selectors.promptTextbox, 15000);
    if (!input) {
      throw new Error('Input não encontrado após 15s');
    }
    console.log('[Umbra] ✅ Input found:', input.tagName);
    
    // Step 2: Insert prompt
    console.log('[Umbra] ⌨️ Step 2: Inserting prompt...');
    const inserted = await dispatchInput(input, currentPrompt);
    if (!inserted) {
      throw new Error('Falha ao inserir prompt');
    }
    console.log('[Umbra] ✅ Prompt inserted');
    
    await sleep(1000);
    
    // Step 3: Find and click button
    console.log('[Umbra] 🔍 Step 3: Finding send button...');
    const button = await waitForElement(selectors.generateButton, 10000);
    if (!button) {
      throw new Error('Botão de enviar não encontrado após 10s');
    }
    console.log('[Umbra] ✅ Button found:', button.tagName);
    
    // Step 4: Click button
    console.log('[Umbra] 🖱️ Step 4: Clicking button...');
    if (!dispatchClick(button)) {
      throw new Error('Falha ao clicar no botão');
    }
    console.log('[Umbra] ✅ Button clicked');
    
    await sleep(1500);
    
    // Step 5: Wait for generation
    console.log('[Umbra] ⏳ Step 5: Waiting for generation...');
    await waitForGeneration(35);
    console.log('[Umbra] ✅ Generation complete');
    
    state.successCount++;
    showToast(`✅ Prompt ${state.currentIndex + 1} concluído`);
    
  } catch (error) {
    console.error('[Umbra] ❌ Error processing prompt:', error);
    state.failCount++;
    showToast(`❌ Erro no prompt ${state.currentIndex + 1}`);
  }
  
  state.currentIndex++;
  updateProgress();
  
  // Wait interval before next
  if (state.currentIndex < state.prompts.length) {
    console.log(`[Umbra] ⏰ Waiting ${state.interval}s before next prompt...`);
    const interval = state.interval * 1000;
    setTimeout(() => processNextPrompt(), interval);
  } else {
    finishGeneration();
  }
}

async function waitForGeneration(timeout) {
  const startTime = Date.now();
  let lastImageCount = 0;
  let stableCount = 0;
  const currentPlatform = state.platform || platform;
  
  while (Date.now() - startTime < timeout * 1000) {
    const loadingElement = document.querySelector(selectors.loading.join(','));
    
    if (!loadingElement) {
      let images = [];
      try {
        images = document.querySelectorAll(selectors.images.join(','));
      } catch(e) { images = []; }
      
      const currentImageCount = images.length;
      
      if (currentImageCount > lastImageCount) {
        lastImageCount = currentImageCount;
        stableCount = 0;
        console.log('[Umbra] 🖼️ New image detected, total:', currentImageCount);
      } else {
        stableCount++;
        if (stableCount >= 6) {
          console.log('[Umbra] ✅ Images stable for 3 seconds');
          return;
        }
      }
    } else {
      stableCount = 0;
    }
    
    await sleep(500);
  }
  
  console.log('[Umbra] ⚠️ Generation timeout reached');
}

function updateProgress() {
  const progress = (state.currentIndex / state.prompts.length) * 100;
  
  state.panelContent.querySelector('#umbra-progress-fill').style.width = `${progress}%`;
  state.panelContent.querySelector('#umbra-progress-text').textContent = `${Math.round(progress)}%`;
  state.panelContent.querySelector('#umbra-progress-count').textContent = 
    `${state.currentIndex} / ${state.prompts.length}`;
  state.panelContent.querySelector('#umbra-success-count').textContent = state.successCount;
  state.panelContent.querySelector('#umbra-fail-count').textContent = state.failCount;
  
  if (state.currentIndex < state.prompts.length) {
    const promptPreview = state.prompts[state.currentIndex].substring(0, 50);
    state.panelContent.querySelector('#umbra-current-prompt').textContent = 
      `Processando: ${promptPreview}${promptPreview.length >= 50 ? '...' : ''}`;
  }
}

function togglePause() {
  state.isPaused = !state.isPaused;
  const pauseBtn = state.panelContent.querySelector('#umbra-pause-btn');
  pauseBtn.textContent = state.isPaused ? '▶️ Retomar' : '⏸️ Pausar';
  
  if (!state.isPaused) {
    processNextPrompt();
  }
  
  showToast(state.isPaused ? '⏸️ Pausado' : '▶️ Retomado');
}

function stopGeneration() {
  console.log('[Umbra] ⏹️ Stopping generation...');
  state.isGenerating = false;
  state.isPaused = false;
  finishGeneration();
  showToast('⏹️ Geração parada');
}

function finishGeneration() {
  state.isGenerating = false;
  
  console.log('[Umbra] 🏁 Generation finished');
  console.log('[Umbra] Success:', state.successCount);
  console.log('[Umbra] Failed:', state.failCount);
  
  // Update UI
  state.panelContent.querySelector('#umbra-start-btn').disabled = false;
  state.panelContent.querySelector('#umbra-control-btns').classList.add('umbra-hidden');
  state.panelContent.querySelector('#umbra-current-prompt').textContent = 
    `✅ Concluído! Sucesso: ${state.successCount}, Falhas: ${state.failCount}`;
  
  showToast(`🎉 Concluído! ${state.successCount}/${state.prompts.length} sucesso`);
}

// ============================================
// DEBUG - Lista TODAS as imagens da página
// ============================================
function debugListAllImages() {
  console.log('='.repeat(60));
  console.log('[UMBRA DEBUG] 🔍 LISTANDO TODAS AS IMAGENS DA PÁGINA');
  console.log('[UMBRA DEBUG] Plataforma ativa:', state.platform || platform);
  console.log('='.repeat(60));

  const allImgs = document.querySelectorAll('img');
  console.log(`[UMBRA DEBUG] Total de <img> encontradas: ${allImgs.length}`);
  console.log('');

  allImgs.forEach((img, i) => {
    const info = {
      index: i,
      src: img.src ? img.src.substring(0, 120) : '(sem src)',
      naturalSize: `${img.naturalWidth}x${img.naturalHeight}`,
      displaySize: `${img.offsetWidth}x${img.offsetHeight}`,
      alt: img.getAttribute('alt') || '',
      className: img.className ? img.className.substring(0, 60) : '',
      parentTag: img.parentElement ? img.parentElement.tagName : '',
      parentClass: img.parentElement ? (img.parentElement.className || '').substring(0, 60) : '',
      visible: isVisible(img),
    };
    console.log(`[IMG ${i}]`, JSON.stringify(info));
  });

  console.log('');
  console.log('[UMBRA DEBUG] ✅ Fim do debug. Copie e cole isso para o suporte!');
  console.log('='.repeat(60));

  showToast(`🔍 ${allImgs.length} imgs logadas no console (F12)`);
}

// ============================================
// DOWNLOAD
// ============================================
async function downloadImages(type) {
  console.log('[Umbra] 📥 Starting image download:', type);
  console.log('[Umbra] Platform:', state.platform || platform);
  
  const currentPlatform = state.platform || platform;
  const allImages = [];
  const seenUrls = new Set();
  
  // ===== SCAN POR SELETORES DA PLATAFORMA =====
  for (const selector of selectors.images) {
    try {
      const images = document.querySelectorAll(selector);
      for (const img of images) {
        if (img.src && 
            isValidGeneratedImage(img.src, img) && 
            !seenUrls.has(img.src) &&
            !state.processedImages.has(img.src) &&
            img.naturalWidth > 50 && 
            img.naturalHeight > 50) {
          allImages.push(img);
          seenUrls.add(img.src);
        }
      }
    } catch (e) { 
      continue; 
    }
  }
  
  console.log('[Umbra] Valid images found:', allImages.length);
  
  // Filtrar por visibilidade se necessário
  const imagesToDownload = type === 'visible' ? 
    allImages.filter(img => isVisible(img)) : 
    allImages;
  
  console.log('[Umbra] Images to download:', imagesToDownload.length);
  
  if (imagesToDownload.length === 0) {
    showToast('⚠️ Nenhuma imagem válida encontrada');
    
    // Debug detalhado
    const debugImages = document.querySelectorAll('img');
    console.log('[Umbra] DEBUG: Total img tags:', debugImages.length);
    debugImages.forEach((img, i) => {
      if (i < 10) {
        console.log(`[Umbra] DEBUG img ${i}:`, 
          img.src?.substring(0, 80), 
          'size:', img.naturalWidth, 'x', img.naturalHeight,
          'display:', img.offsetWidth, 'x', img.offsetHeight,
          'valid:', isValidGeneratedImage(img.src, img));
      }
    });
    
    return;
  }
  
  showToast(`📥 Baixando ${imagesToDownload.length} imagens...`);
  
  let downloaded = 0;
  for (let i = 0; i < imagesToDownload.length; i++) {
    const img = imagesToDownload[i];
    const url = img.src;
    
    console.log(`[Umbra] Downloading ${i + 1}/${imagesToDownload.length}:`, url?.substring(0, 60));
    
    if (url) {
      try {
        await chrome.runtime.sendMessage({
          action: 'downloadImage',
          data: {
            url: url,
            filename: `umbra-vision-${Date.now()}-${i + 1}.png`
          }
        });
        
        state.processedImages.add(url);
        downloaded++;
        await sleep(200);
      } catch (error) {
        console.error('[Umbra] Download error:', error);
      }
    }
  }
  
  showToast(`✅ ${downloaded} imagens baixadas!`);
  console.log('[Umbra] Download complete:', downloaded, 'images');
}

// ============================================
// VIDEO DOWNLOAD
// ============================================
async function downloadVideos(type) {
  console.log('[Umbra] 🎬 Starting video download:', type);
  
  const videos = collectVideos();
  
  if (videos.length === 0) {
    showToast('⚠️ Nenhum vídeo encontrado');
    
    // Debug
    const allVideos = document.querySelectorAll('video');
    console.log('[Umbra] DEBUG: Total video tags:', allVideos.length);
    allVideos.forEach((v, i) => {
      if (i < 3) {
        console.log(`[Umbra] DEBUG video ${i}:`, 
          v.src || v.currentSrc, 
          'valid:', isValidVideoUrl(v.src || v.currentSrc));
      }
    });
    
    return;
  }
  
  showToast(`🎬 Baixando ${videos.length} vídeos...`);
  
  let downloaded = 0;
  for (let i = 0; i < videos.length; i++) {
    const video = videos[i];
    
    console.log(`[Umbra] Downloading video ${i + 1}/${videos.length}:`, 
      video.url.substring(0, 60));
    
    try {
      await chrome.runtime.sendMessage({
        action: 'downloadVideo',
        data: {
          url: video.url,
          filename: `umbra-vision-video-${Date.now()}-${i + 1}.mp4`
        }
      });
      
      // Marcar como processado
      state.processedVideos.add(video.url);
      downloaded++;
      await sleep(800); // Mais tempo entre vídeos
    } catch (error) {
      console.error('[Umbra] Video download error:', error);
    }
  }
  
  showToast(`✅ ${downloaded} vídeos baixados!`);
  console.log('[Umbra] Video download complete:', downloaded, 'videos');
}

// ============================================
// TOAST
// ============================================
function showToast(message) {
  const existingToast = document.querySelector('.umbra-toast');
  if (existingToast) existingToast.remove();
  
  const toast = document.createElement('div');
  toast.className = 'umbra-toast';
  toast.textContent = message;
  
  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.style.opacity = '0';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// ============================================
// TOGGLE PANEL
// ============================================
function togglePanel() {
  if (!state.panel) {
    createPanel();
  } else {
    state.panel.classList.toggle('hidden');
  }
}

// ============================================
// MESSAGE LISTENER
// ============================================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[Umbra] 📨 Message received:', message.action);
  
  if (message.action === 'togglePanel') {
    togglePanel();
    sendResponse({ success: true });
  }
  
  return true;
});

// ============================================
// INITIALIZATION
// ============================================
if (platform) {
  setTimeout(() => {
    createPanel();
    console.log('[Umbra] ✅ Initialized on Meta.ai');
  }, 1500);
} else {
  console.log('[Umbra] ❌ Not initializing - unsupported platform');
}
