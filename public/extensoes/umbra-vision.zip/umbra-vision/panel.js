/**
 * Umbra Vision - Panel Helper Functions
 * Version 3.0.0
 * 
 * Este arquivo contém funções auxiliares para o painel.
 * A lógica principal está em content.js, que injeta e controla o painel.
 */

// ============================================
// UTILITY FUNCTIONS
// ============================================

/**
 * Parse prompts de texto
 * @param {string} text - Texto com prompts (um por linha)
 * @returns {string[]} Array de prompts
 */
function parsePrompts(text) {
  return text
    .split('\n')
    .map(line => line.trim())
    .filter(line => line.length > 0);
}

/**
 * Format time em MM:SS
 * @param {number} ms - Milissegundos
 * @returns {string} Tempo formatado
 */
function formatTime(ms) {
  const seconds = Math.floor(ms / 1000);
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
}

/**
 * Generate filename
 * @param {string} prefix - Prefixo do arquivo
 * @param {number} index - Índice
 * @param {string} extension - Extensão
 * @returns {string} Nome do arquivo
 */
function generateFilename(prefix, index, extension = 'png') {
  return `${prefix}-${String(index).padStart(4, '0')}.${extension}`;
}

/**
 * Save panel position
 * @param {number} top - Posição top
 * @param {number} left - Posição left
 */
async function savePanelPosition(top, left) {
  try {
    await chrome.storage.local.set({
      panelPosition: { top, left }
    });
  } catch (error) {
    console.error('Error saving position:', error);
  }
}

/**
 * Load panel position
 * @returns {Promise<{top: number, left: number}>} Posição salva
 */
async function loadPanelPosition() {
  try {
    const result = await chrome.storage.local.get(['panelPosition']);
    return result.panelPosition || { top: 20, left: null };
  } catch (error) {
    console.error('Error loading position:', error);
    return { top: 20, left: null };
  }
}

/**
 * Save panel size
 * @param {number} width - Largura
 * @param {number} height - Altura
 */
async function savePanelSize(width, height) {
  try {
    await chrome.storage.local.set({
      panelSize: { width, height }
    });
  } catch (error) {
    console.error('Error saving size:', error);
  }
}

/**
 * Load panel size
 * @returns {Promise<{width: number, height: number}>} Tamanho salvo
 */
async function loadPanelSize() {
  try {
    const result = await chrome.storage.local.get(['panelSize']);
    return result.panelSize || { width: 420, height: 650 };
  } catch (error) {
    console.error('Error loading size:', error);
    return { width: 420, height: 650 };
  }
}

/**
 * Validate prompt
 * @param {string} prompt - Prompt para validar
 * @returns {boolean} Se é válido
 */
function isValidPrompt(prompt) {
  return prompt && prompt.trim().length > 0 && prompt.length < 1000;
}

/**
 * Sanitize filename
 * @param {string} filename - Nome do arquivo
 * @returns {string} Nome sanitizado
 */
function sanitizeFilename(filename) {
  return filename
    .replace(/[^a-z0-9.-]/gi, '_')
    .replace(/_+/g, '_')
    .toLowerCase();
}

// ============================================
// EXPORT (se necessário)
// ============================================

// Se este arquivo for carregado como módulo, exportar funções
if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    parsePrompts,
    formatTime,
    generateFilename,
    savePanelPosition,
    loadPanelPosition,
    savePanelSize,
    loadPanelSize,
    isValidPrompt,
    sanitizeFilename
  };
}

console.log('[Panel.js] ✅ Helper functions loaded');
