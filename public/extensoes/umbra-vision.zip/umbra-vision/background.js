/**
 * Umbra Vision - Background Service Worker
 * Version 4.0.0 - License System + Meta.ai Only
 */

console.log('[Background] 🚀 Umbra Vision Background v4.0.0');

const LICENSE_CONFIG = {
  endpoint: 'https://cvrdcupvqvkpwllwlkfw.functions.supabase.co/validar-licenca',
  slug: 'umbrahub-all',
  version: '4.0.0'
};

async function getDeviceId() {
  const result = await chrome.storage.local.get(['umbra_device_id']);
  if (result.umbra_device_id) return result.umbra_device_id;
  const raw = navigator.userAgent + Date.now() + Math.random();
  const encoder = new TextEncoder();
  const data = encoder.encode(raw);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const deviceId = hashArray.map(b => b.toString(16).padStart(2, '0')).join('').substring(0, 32);
  await chrome.storage.local.set({ umbra_device_id: deviceId });
  return deviceId;
}

async function activateLicense(chave) {
  try {
    const device_id = await getDeviceId();
    const response = await fetch(LICENSE_CONFIG.endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'activate', chave, device_id, slug: LICENSE_CONFIG.slug, version: LICENSE_CONFIG.version })
    });
    const data = await response.json();
    if (data.valido || data.token) {
      await chrome.storage.local.set({ umbra_chave: chave, umbra_token: data.token || '', umbra_expiry: Date.now() + 86400000, umbra_valido: true });
      return { valido: true };
    }
    return { valido: false, motivo: data.motivo || data.message || 'Chave inválida ou limite atingido.' };
  } catch (e) {
    return { valido: false, motivo: 'Erro de conexão. Verifique sua internet.' };
  }
}

async function verifyLicense() {
  try {
    const s = await chrome.storage.local.get(['umbra_chave','umbra_token','umbra_expiry','umbra_valido']);
    if (!s.umbra_chave) return { valido: false, motivo: 'Nenhuma licença ativada.' };
    if (s.umbra_valido && s.umbra_expiry && Date.now() < s.umbra_expiry) return { valido: true };
    const device_id = await getDeviceId();
    const response = await fetch(LICENSE_CONFIG.endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'verify', chave: s.umbra_chave, device_id, token: s.umbra_token || '', slug: LICENSE_CONFIG.slug, version: LICENSE_CONFIG.version })
    });
    const data = await response.json();
    if (data.valido) {
      await chrome.storage.local.set({ umbra_token: data.token || s.umbra_token, umbra_expiry: Date.now() + 86400000, umbra_valido: true });
      return { valido: true };
    }
    await chrome.storage.local.remove(['umbra_token','umbra_chave','umbra_expiry','umbra_valido']);
    return { valido: false, motivo: data.motivo || 'Licença revogada ou expirada.' };
  } catch (e) {
    const s = await chrome.storage.local.get(['umbra_valido','umbra_expiry']);
    if (s.umbra_valido && s.umbra_expiry && Date.now() < s.umbra_expiry) return { valido: true };
    return { valido: false, motivo: 'Sem conexão e sessão expirada.' };
  }
}

async function logoutLicense() {
  await chrome.storage.local.remove(['umbra_token','umbra_chave','umbra_expiry','umbra_valido']);
  return { success: true };
}

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('chrome-extension://')) return;
  if (!tab.url.includes('meta.ai')) { console.log('[Background] ⚠️ Somente Meta.ai é suportado'); return; }
  try {
    await chrome.tabs.sendMessage(tab.id, { action: 'togglePanel' });
  } catch (e) {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
      await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['content.css'] });
      setTimeout(async () => { try { await chrome.tabs.sendMessage(tab.id, { action: 'togglePanel' }); } catch(e){} }, 1000);
    } catch (err) { console.error('[Background] ❌ Inject failed:', err); }
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'GET_STATUS') { verifyLicense().then(sendResponse); return true; }
  if (message.action === 'ACTIVATE') { activateLicense(message.chave).then(sendResponse); return true; }
  if (message.action === 'LOGOUT') { logoutLicense().then(sendResponse); return true; }
  if (message.action === 'downloadImage') {
    chrome.downloads.download({ url: message.data.url, filename: message.data.filename || `umbra-${Date.now()}.png`, saveAs: false });
    sendResponse({ success: true }); return true;
  }
  if (message.action === 'downloadVideo') {
    chrome.downloads.download({ url: message.data.url, filename: message.data.filename || `umbra-video-${Date.now()}.mp4`, saveAs: false });
    sendResponse({ success: true }); return true;
  }
  return true;
});

chrome.alarms.create('licenseHeartbeat', { periodInMinutes: 360 });
chrome.alarms.create('keepAlive', { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'licenseHeartbeat') verifyLicense();
  if (alarm.name === 'keepAlive') console.log('[Background] 💓');
});

console.log('[Background] ✅ Ready v4.0.0');
