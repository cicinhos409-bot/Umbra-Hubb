// Umbra TikTok Downloader v2.0.2
(function () {
  'use strict';
  if (document.getElementById('umbra-panel-container')) return;

  // ── HTML DO PAINEL ────────────────────────────────────────────────
  const panel = document.createElement('div');
  panel.id = 'umbra-panel-container';
  panel.innerHTML = `
    <div id="umbra-header">
      <div id="umbra-header-logo">🎵</div>
      <div id="umbra-header-title">Umbra TikTok Downloader</div>
      <div id="umbra-header-controls">
        <button class="umbra-ctrl-btn" id="umbra-minimize-btn" title="Minimizar">—</button>
        <button class="umbra-ctrl-btn umbra-close" id="umbra-close-btn" title="Fechar">✕</button>
      </div>
    </div>

    <!-- ══ TELA DE LICENÇA ══ -->
    <div id="umbra-license-screen">
      <div id="umbra-license-icon">🔑</div>
      <div id="umbra-license-title">Ativar Licença</div>
      <div id="umbra-license-subtitle">Insira sua chave para liberar o Umbra TikTok Downloader</div>
      <div id="umbra-license-form">
        <input type="text" id="umbra-license-input" placeholder="UMBRA-XXXX-XXXX" maxlength="32" autocomplete="off" spellcheck="false" />
        <button id="umbra-license-btn">Ativar Agora</button>
        <div id="umbra-license-status"></div>
      </div>
      <div id="umbra-license-footer">
        Não tem uma chave?
        <a href="https://umbrahubb.vercel.app" target="_blank">Acesse o Umbra Hub →</a>
      </div>
    </div>

    <!-- ══ CONTEÚDO PRINCIPAL (bloqueado até licença) ══ -->
    <div id="umbra-body">

      <div id="umbra-auto-section">
        <div id="umbra-auto-label">📍 Vídeo detectado na página</div>
        <div id="umbra-auto-url">Navegue até um vídeo do TikTok...</div>
        <button id="umbra-auto-btn" disabled>⚡ Baixar Vídeo Atual</button>
      </div>

      <div class="umbra-divider"></div>

      <div id="umbra-input-row">
        <input type="text" id="umbra-url-input" placeholder="Cole um link do TikTok..." autocomplete="off" spellcheck="false" />
        <button id="umbra-fetch-btn">Buscar</button>
      </div>

      <div id="umbra-status"></div>

      <div id="umbra-video-info">
        <img id="umbra-video-thumb" src="" alt="" />
        <div id="umbra-video-meta">
          <div id="umbra-video-creator"></div>
          <div id="umbra-video-title"></div>
        </div>
      </div>

      <div id="umbra-download-btns"></div>

      <!-- Transcrição -->
      <div id="umbra-transcript-section">
        <div class="umbra-divider"></div>
        <div id="umbra-transcript-header">
          <span id="umbra-transcript-label">🎙️ Transcrição via Whisper</span>
          <button id="umbra-transcript-toggle-btn">▼ Configurar</button>
        </div>
        <div id="umbra-transcript-box">
          <div id="umbra-groq-config">
            <div class="umbra-config-label">
              🔑 Chave API Groq (gratuita)
              <a href="https://console.groq.com/keys" target="_blank" id="umbra-groq-link">Obter grátis →</a>
            </div>
            <div id="umbra-groq-key-row">
              <input type="password" id="umbra-groq-key-input" placeholder="gsk_..." autocomplete="off" spellcheck="false" />
              <button id="umbra-groq-save-btn">Salvar</button>
            </div>
            <div id="umbra-groq-key-status"></div>
          </div>
          <button id="umbra-transcribe-btn" disabled>🎙️ Transcrever com Whisper</button>
          <div id="umbra-ts-status"></div>
          <div id="umbra-ts-result">
            <div id="umbra-ts-text"></div>
            <div id="umbra-ts-actions">
              <button id="umbra-ts-copy-btn">📋 Copiar</button>
              <button id="umbra-ts-download-btn">💾 Baixar .txt</button>
            </div>
          </div>
        </div>
      </div>

      <div id="umbra-footer-links">
        <button id="umbra-logout-btn">🔓 Sair / Trocar Licença</button>
      </div>
    </div>

    <div id="umbra-resizer">
      <svg viewBox="0 0 10 10" fill="none">
        <path d="M9 1L1 9M9 5L5 9" stroke="white" stroke-width="1.5" stroke-linecap="round"/>
      </svg>
    </div>
  `;
  document.body.appendChild(panel);

  // ── REFS ──────────────────────────────────────────────────────────
  const $ = id => document.getElementById(id);
  const header           = $('umbra-header');
  const minimizeBtn      = $('umbra-minimize-btn');
  const closeBtn         = $('umbra-close-btn');
  const licenseScreen    = $('umbra-license-screen');
  const licenseInput     = $('umbra-license-input');
  const licenseBtn       = $('umbra-license-btn');
  const licenseStatus    = $('umbra-license-status');
  const body             = $('umbra-body');
  const autoSection      = $('umbra-auto-section');
  const autoUrlEl        = $('umbra-auto-url');
  const autoBtn          = $('umbra-auto-btn');
  const urlInput         = $('umbra-url-input');
  const fetchBtn         = $('umbra-fetch-btn');
  const statusEl         = $('umbra-status');
  const videoInfoEl      = $('umbra-video-info');
  const videoThumb       = $('umbra-video-thumb');
  const videoCreator     = $('umbra-video-creator');
  const videoTitleEl     = $('umbra-video-title');
  const downloadBtns     = $('umbra-download-btns');
  const transcriptSec    = $('umbra-transcript-section');
  const transcriptToggle = $('umbra-transcript-toggle-btn');
  const transcriptBox    = $('umbra-transcript-box');
  const groqKeyInput     = $('umbra-groq-key-input');
  const groqSaveBtn      = $('umbra-groq-save-btn');
  const groqKeyStatus    = $('umbra-groq-key-status');
  const transcribeBtn    = $('umbra-transcribe-btn');
  const tsStatus         = $('umbra-ts-status');
  const tsResult         = $('umbra-ts-result');
  const tsText           = $('umbra-ts-text');
  const tsCopyBtn        = $('umbra-ts-copy-btn');
  const tsDownloadBtn    = $('umbra-ts-download-btn');
  const logoutBtn        = $('umbra-logout-btn');
  const resizer          = $('umbra-resizer');

  // ── ESTADO ───────────────────────────────────────────────────────
  let isMinimized    = false;
  let tsBoxOpen      = false;
  let isFetching     = false;
  let isTranscribing = false;
  let currentUrl     = '';
  let lastResult     = null;
  let groqKey        = '';

  // ── HELPERS ──────────────────────────────────────────────────────
  const show = el => el.classList.add('u-show');
  const hide = el => el.classList.remove('u-show');

  function setStatus(msg, type) {
    statusEl.className = type ? `u-${type}` : '';
    statusEl.innerHTML = msg || '';
  }
  function setTsStatus(msg, type) {
    tsStatus.className = type ? `u-${type}` : '';
    tsStatus.innerHTML = msg || '';
  }
  function setLicStatus(msg, type) {
    licenseStatus.textContent = msg;
    licenseStatus.className   = type ? `u-lic-${type}` : '';
  }

  // ══════════════════════════════════════
  // SISTEMA DE LICENÇA
  // ══════════════════════════════════════

  function showLicenseScreen() {
    hide(body);
    show(licenseScreen);
    panel.style.height = '480px';
  }

  function showMainApp(planoLabel = '') {
    hide(licenseScreen);
    show(body);
    panel.style.height = '650px';
  }

  // Verificar licença ao carregar
  async function initLicense() {
    setLicStatus('<span class="umbra-spinner"></span> Verificando licença...', 'loading');
    show(licenseScreen);

    chrome.runtime.sendMessage({ action: 'GET_STATUS' }, res => {
      if (!res) { setLicStatus('❌ Erro ao verificar licença.', 'error'); return; }

      // Kill Switch remoto
      if (res.blocked) {
        showKillSwitch(res.motivo || 'Licença bloqueada remotamente.');
        return;
      }

      if (res.valido) {
        const plano = res.plano ? ` · Plano ${res.plano.toUpperCase()}` : '';
        const modo  = res.offline ? ' (offline)' : '';
        showMainApp(plano + modo);
        loadGroqKey();
      } else {
        setLicStatus('', '');
        showLicenseScreen();
      }
    });
  }

  function showKillSwitch(motivo) {
    licenseInput.disabled = true;
    licenseBtn.disabled   = true;
    setLicStatus(`🚫 ${motivo}`, 'error');
    show(licenseScreen);
    hide(body);
  }

  // Ativar licença
  licenseBtn.addEventListener('click', () => {
    const chave = licenseInput.value.trim().toUpperCase();
    if (!chave || chave.length < 8) {
      setLicStatus('❌ Digite uma chave válida.', 'error');
      return;
    }
    licenseBtn.disabled = true;
    setLicStatus('<span class="umbra-spinner"></span> Ativando...', 'loading');

    chrome.runtime.sendMessage({ action: 'ACTIVATE', chave }, res => {
      licenseBtn.disabled = false;
      if (res && res.valido) {
        setLicStatus('✅ Licença ativada!', 'ok');
        const plano = res.plano ? ` · Plano ${res.plano.toUpperCase()}` : '';
        setTimeout(() => { showMainApp(plano); loadGroqKey(); }, 800);
      } else {
        const motivo = res?.motivo || 'Chave inválida ou limite de dispositivos atingido.';
        setLicStatus(`❌ ${motivo}`, 'error');
      }
    });
  });

  // Formatar chave enquanto digita (UMBRA-XXXX-XXXX)
  licenseInput.addEventListener('input', () => {
    let v = licenseInput.value.toUpperCase().replace(/[^A-Z0-9-]/g, '');
    licenseInput.value = v;
    setLicStatus('', '');
  });
  licenseInput.addEventListener('keydown', e => {
    e.stopPropagation();
    if (e.key === 'Enter') licenseBtn.click();
  });
  licenseInput.addEventListener('keyup',    e => e.stopPropagation());
  licenseInput.addEventListener('keypress', e => e.stopPropagation());

  // Sair / trocar licença
  logoutBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'LOGOUT_LICENSE' }, () => {
      licenseInput.disabled = false;
      licenseBtn.disabled   = false;
      licenseInput.value    = '';
      setLicStatus('', '');
      showLicenseScreen();
    });
  });

  // Licença revogada remotamente (heartbeat)
  chrome.runtime.onMessage.addListener(req => {
    if (req.action === 'licenseRevoked') {
      setLicStatus('⚠️ Licença desativada remotamente.', 'error');
      showLicenseScreen();
    }
    if (req.action === 'togglePanel') {
      panel.classList.toggle('umbra-hidden');
      if (!panel.classList.contains('umbra-hidden') && isMinimized) {
        isMinimized = false;
        panel.classList.remove('umbra-collapsed');
        minimizeBtn.textContent = '—';
      }
    }
  });

  // ══════════════════════════════════════
  // MINIMIZE / FECHAR / DRAG / RESIZE
  // ══════════════════════════════════════

  minimizeBtn.addEventListener('click', () => {
    isMinimized = !isMinimized;
    panel.classList.toggle('umbra-collapsed', isMinimized);
    minimizeBtn.textContent = isMinimized ? '□' : '—';
    minimizeBtn.title       = isMinimized ? 'Restaurar' : 'Minimizar';
  });
  closeBtn.addEventListener('click', () => panel.classList.add('umbra-hidden'));

  let dragging = false, dX = 0, dY = 0;
  header.addEventListener('mousedown', e => {
    if (e.target.classList.contains('umbra-ctrl-btn')) return;
    dragging = true;
    const r = panel.getBoundingClientRect();
    dX = e.clientX - r.left; dY = e.clientY - r.top;
    e.preventDefault();
  });
  document.addEventListener('mousemove', e => {
    if (!dragging) return;
    panel.style.setProperty('left',  `${e.clientX - dX}px`, 'important');
    panel.style.setProperty('top',   `${e.clientY - dY}px`, 'important');
    panel.style.setProperty('right', 'auto', 'important');
  });
  document.addEventListener('mouseup', () => { dragging = false; });

  let resizing = false, rX = 0, rY = 0, rW = 0, rH = 0;
  resizer.addEventListener('mousedown', e => {
    resizing = true; rX = e.clientX; rY = e.clientY;
    rW = panel.offsetWidth; rH = panel.offsetHeight;
    e.preventDefault(); e.stopPropagation();
  });
  document.addEventListener('mousemove', e => {
    if (!resizing) return;
    panel.style.width  = `${Math.max(280, rW + e.clientX - rX)}px`;
    if (!isMinimized) panel.style.height = `${Math.max(46, rH + e.clientY - rY)}px`;
  });
  document.addEventListener('mouseup', () => { resizing = false; });

  // ══════════════════════════════════════
  // GROQ KEY
  // ══════════════════════════════════════

  function loadGroqKey() {
    chrome.storage.sync.get({ groqApiKey: '' }, s => {
      groqKey = s.groqApiKey || '';
      if (groqKey) {
        groqKeyInput.value        = groqKey;
        groqKeyStatus.textContent = '✅ Chave salva';
        groqKeyStatus.className   = 'u-key-ok';
      }
      updateTranscribeBtn();
    });
  }

  function updateTranscribeBtn() { transcribeBtn.disabled = !(groqKey && lastResult); }

  groqSaveBtn.addEventListener('click', () => {
    const k = groqKeyInput.value.trim();
    if (!k.startsWith('gsk_') || k.length < 20) {
      groqKeyStatus.textContent = '❌ Inválida — deve começar com gsk_';
      groqKeyStatus.className   = 'u-key-error'; return;
    }
    groqKey = k;
    chrome.storage.sync.set({ groqApiKey: k }, () => {
      groqKeyStatus.textContent = '✅ Chave salva!';
      groqKeyStatus.className   = 'u-key-ok';
      updateTranscribeBtn();
    });
  });

  [groqKeyInput, urlInput].forEach(inp => {
    inp.addEventListener('keydown',  e => e.stopPropagation());
    inp.addEventListener('keyup',    e => e.stopPropagation());
    inp.addEventListener('keypress', e => e.stopPropagation());
  });
  groqKeyInput.addEventListener('keydown', e => { if (e.key === 'Enter') groqSaveBtn.click(); });
  urlInput.addEventListener('keydown',     e => { if (e.key === 'Enter') fetchBtn.click(); });

  // ══════════════════════════════════════
  // DETECÇÃO DE VÍDEO
  // ══════════════════════════════════════

  function detectPage() {
    const url    = window.location.href;
    const isVid  = /tiktok\.com\/@[^/]+\/video\/\d+/.test(url);
    currentUrl   = isVid ? url : '';
    autoUrlEl.textContent      = isVid ? url.replace(/https?:\/\/(www\.)?/, '').substring(0, 50) + '...' : 'Navegue até um vídeo do TikTok...';
    autoSection.style.opacity  = isVid ? '1' : '0.5';
    autoBtn.disabled           = !isVid;
  }
  detectPage();

  let lastHref = location.href;
  new MutationObserver(() => {
    if (location.href === lastHref) return;
    lastHref = location.href;
    setTimeout(detectPage, 800);
    hide(videoInfoEl); hide(transcriptSec); hide(tsResult);
    setStatus(); setTsStatus();
    downloadBtns.innerHTML = '';
    lastResult = null;
    tsBoxOpen  = false; hide(transcriptBox);
    transcriptToggle.textContent = '▼ Configurar';
    updateTranscribeBtn();
  }).observe(document.body, { childList: true, subtree: true });

  // ── TRANSCRIPT TOGGLE ──
  transcriptToggle.addEventListener('click', () => {
    tsBoxOpen = !tsBoxOpen;
    tsBoxOpen ? show(transcriptBox) : hide(transcriptBox);
    transcriptToggle.textContent = tsBoxOpen ? '▲ Fechar' : '▼ Configurar';
  });

  // ══════════════════════════════════════
  // BUSCAR VÍDEO
  // ══════════════════════════════════════

  async function fetchAndShow(tiktokUrl) {
    if (isFetching) return;
    isFetching = true;
    fetchBtn.disabled = autoBtn.disabled = true;
    fetchBtn.textContent  = '...';
    downloadBtns.innerHTML = '';
    hide(videoInfoEl); hide(transcriptSec); hide(tsResult);
    setStatus('<span class="umbra-spinner"></span> Buscando vídeo...', 'info');

    try {
      const result = await new Promise((ok, fail) =>
        chrome.runtime.sendMessage({ action: 'fetchTikWM', url: tiktokUrl }, r =>
          chrome.runtime.lastError ? fail(new Error(chrome.runtime.lastError.message))
          : r.success ? ok(r.data) : fail(new Error(r.error || 'Erro'))
        )
      );

      const author = result.author?.unique_id || result.author?.nickname || 'Desconhecido';
      videoCreator.textContent = `@${author}`;
      videoTitleEl.textContent = (result.title || '').substring(0, 80);
      videoThumb.src           = result.cover || '';
      videoThumb.style.display = result.cover ? 'block' : 'none';
      show(videoInfoEl);

      lastResult = result;
      show(transcriptSec);
      updateTranscribeBtn();

      downloadBtns.innerHTML = '';
      const settings = await new Promise(r =>
        chrome.storage.sync.get({ useSubdirectory: true, subdirectoryName: 'TikTok' }, r)
      );

      const mkBtn = (label, url, cls, badge) => {
        const b = document.createElement('button');
        b.className = `umbra-dl-btn ${cls}`;
        b.innerHTML = `<span>${label}</span><span class="umbra-dl-badge">${badge}</span>`;
        b.onclick = () => {
          const filename = `@${author}_${result.id || Date.now()}.mp4`;
          chrome.runtime.sendMessage({ action: 'downloadVideo', url, filename, settings }, r => {
            if (r?.success) setStatus('✅ Download iniciado!', 'success');
            else { window.open(url, '_blank'); setStatus('⚠️ Abrindo em nova aba...', 'info'); }
          });
        };
        downloadBtns.appendChild(b);
      };

      if (result.hdplay) mkBtn('🎬 HD Sem Marca D\'água', result.hdplay, 'umbra-hd',    'HD');
      if (result.play)   mkBtn('📹 Qualidade Normal',    result.play,   'umbra-normal', 'SD');
      if (result.wmplay) mkBtn('⚡ Download Rápido',     result.wmplay, 'umbra-fast',   'COM LOGO');

      const noLinks = !result.hdplay && !result.play && !result.wmplay;
      setStatus(noLinks ? '❌ Nenhuma URL encontrada' : '✅ Vídeo encontrado! Escolha a qualidade:', noLinks ? 'error' : 'success');

    } catch (err) {
      setStatus(`❌ ${err.message}`, 'error');
    } finally {
      isFetching = false;
      fetchBtn.disabled    = false;
      fetchBtn.textContent = 'Buscar';
      detectPage();
    }
  }

  autoBtn.onclick  = () => { if (currentUrl) fetchAndShow(currentUrl); };
  fetchBtn.onclick = () => {
    const url = urlInput.value.trim();
    if (!url)                    { setStatus('❌ Cole um link do TikTok!', 'error'); return; }
    if (!url.includes('tiktok')) { setStatus('❌ Link inválido!', 'error'); return; }
    fetchAndShow(url);
  };

  // ══════════════════════════════════════
  // TRANSCRIÇÃO GROQ WHISPER
  // ══════════════════════════════════════

  transcribeBtn.addEventListener('click', () => {
    if (!groqKey || !lastResult || isTranscribing) return;
    transcribeWhisper();
  });

  async function transcribeWhisper() {
    isTranscribing = true;
    transcribeBtn.disabled = true;
    hide(tsResult);
    setTsStatus('<span class="umbra-spinner"></span> Baixando áudio... (1/3)', 'info');

    const author   = lastResult.author?.unique_id || 'tiktok';
    const videoId  = lastResult.id || Date.now();
    const audioUrl = lastResult.play || lastResult.hdplay || lastResult.wmplay;

    if (!audioUrl) {
      setTsStatus('❌ Nenhuma URL de áudio disponível.', 'error');
      isTranscribing = false; transcribeBtn.disabled = false; return;
    }

    try {
      const blobData = await new Promise((ok, fail) =>
        chrome.runtime.sendMessage({ action: 'fetchBlob', url: audioUrl }, r =>
          chrome.runtime.lastError ? fail(new Error(chrome.runtime.lastError.message))
          : r.success ? ok(r) : fail(new Error(r.error || 'Falha ao baixar áudio'))
        )
      );

      const bytes    = atob(blobData.base64);
      const arr      = new Uint8Array(bytes.length);
      for (let i = 0; i < bytes.length; i++) arr[i] = bytes.charCodeAt(i);
      const audioBlob = new Blob([arr], { type: blobData.mimeType || 'video/mp4' });

      setTsStatus('<span class="umbra-spinner"></span> Enviando para Groq Whisper... (2/3)', 'info');

      const form = new FormData();
      form.append('file',   audioBlob, `audio_${videoId}.mp4`);
      form.append('model',  'whisper-large-v3-turbo');
      form.append('response_format', 'verbose_json');
      form.append('timestamp_granularities[]', 'segment');

      const resp = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
        method: 'POST', headers: { 'Authorization': `Bearer ${groqKey}` }, body: form
      });

      if (!resp.ok) {
        const e = await resp.json().catch(() => ({}));
        throw new Error(e?.error?.message || `Groq HTTP ${resp.status}`);
      }

      const data = await resp.json();
      setTsStatus('<span class="umbra-spinner"></span> Processando... (3/3)', 'info');

      let plainText = '', html = '';

      if (data.segments?.length) {
        html = data.segments.map(s => {
          const mm = String(Math.floor(s.start / 60));
          const ss = String(Math.floor(s.start % 60)).padStart(2, '0');
          return `<div class="umbra-ts-entry"><span class="umbra-ts-time">${mm}:${ss}</span><span class="umbra-ts-txt">${esc(s.text.trim())}</span></div>`;
        }).join('');
        plainText = data.segments.map(s => {
          const mm = String(Math.floor(s.start / 60));
          const ss = String(Math.floor(s.start % 60)).padStart(2, '0');
          return `[${mm}:${ss}] ${s.text.trim()}`;
        }).join('\n');
      } else if (data.text) {
        html = `<div class="umbra-ts-entry"><span class="umbra-ts-txt">${esc(data.text)}</span></div>`;
        plainText = data.text;
      } else { throw new Error('Resposta vazia do Whisper.'); }

      const segs = data.segments?.length || 1;
      const lang = data.language ? ` · ${data.language}` : '';
      const dur  = data.duration  ? ` · ${Math.round(data.duration)}s` : '';
      setTsStatus(`✅ ${segs} segmentos${lang}${dur}`, 'success');

      tsText.innerHTML = html;
      show(tsResult);

      tsCopyBtn.onclick = () => {
        navigator.clipboard.writeText(plainText).then(() => {
          tsCopyBtn.textContent = '✅ Copiado!';
          setTimeout(() => { tsCopyBtn.textContent = '📋 Copiar'; }, 2000);
        });
      };
      tsDownloadBtn.onclick = () => {
        const hdr  = `Transcrição - @${author}\nID: ${lastResult.id || ''}\n${'─'.repeat(40)}\n\n`;
        const blob = new Blob([hdr + plainText], { type: 'text/plain;charset=utf-8' });
        const u    = URL.createObjectURL(blob);
        const a    = Object.assign(document.createElement('a'), { href: u, download: `@${author}_${videoId}_transcricao.txt` });
        document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(u);
      };

    } catch (err) {
      let msg = err.message || 'Erro desconhecido';
      if (msg.includes('401') || msg.includes('invalid_api_key')) msg = 'Chave Groq inválida. Verifique em console.groq.com/keys';
      else if (msg.includes('429')) msg = 'Limite atingido. Aguarde e tente novamente.';
      else if (msg.includes('413') || msg.includes('too large')) msg = 'Vídeo muito longo (máx ~25MB).';
      setTsStatus(`❌ ${msg}`, 'error');
    } finally {
      isTranscribing = false; updateTranscribeBtn();
    }
  }

  function esc(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  // ── INICIAR ───────────────────────────────────────────────────────
  initLicense();

  console.log('🎵 Umbra TikTok Downloader v2.0.2');
})();
