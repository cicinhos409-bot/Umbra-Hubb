// Umbra TikTok Downloader v2.0.2 - Background Service Worker
// Umbra SDK v2.0 (DottiFlow Style) — Kill Switch + Sessões 24h + Heartbeat + Fingerprint

// ══════════════════════════════════════════════════════════════════
// UMBRA SDK v2.0
// ══════════════════════════════════════════════════════════════════

const SDK_CONFIG = {
  url:               'https://cvrdcupvqvkpwllwlkfw.functions.supabase.co/validar-licenca',
  slug:              'umbrahub-all',
  version:           '2.0.2',
  heartbeatInterval: 6 * 60 * 60 * 1000
};

// ── Fingerprint estável do dispositivo (Service Worker compatible) ──
async function getDeviceId() {
  const data = await chrome.storage.local.get('umbra_device_id');
  if (data.umbra_device_id) return data.umbra_device_id;

  try {
    const platform = await new Promise(r => chrome.runtime.getPlatformInfo(r));

    const components = [
      navigator.userAgent,
      navigator.language,
      navigator.hardwareConcurrency || '8',
      platform.os,
      platform.arch,
      platform.nacl_arch || ''
    ];

    const rawId  = components.join('|');
    const hash   = btoa(rawId).replace(/[/+=]/g, '').slice(-24);
    const finalId = 'umb-' + hash.toLowerCase();

    await chrome.storage.local.set({ umbra_device_id: finalId });
    return finalId;
  } catch (e) {
    const fallback = 'dev-' + Math.random().toString(36).slice(2) + Date.now();
    await chrome.storage.local.set({ umbra_device_id: fallback });
    return fallback;
  }
}

// ── Chamada base ao SDK ───────────────────────────────────────────
async function callSDK(action, extra = {}) {
  const device_id = await getDeviceId();
  const storage   = await chrome.storage.local.get(['umbra_token', 'umbra_chave']);

  try {
    const res = await fetch(SDK_CONFIG.url, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({
        action,
        device_id,
        slug:    SDK_CONFIG.slug,
        version: SDK_CONFIG.version,
        token:   storage.umbra_token,
        chave:   storage.umbra_chave,
        ...extra
      })
    });
    return await res.json();
  } catch (e) {
    return { error: 'offline' };
  }
}

// ── Verificar status (Kill Switch + Sessão) ───────────────────────
async function checkStatus() {
  const data = await chrome.storage.local.get(['umbra_token', 'umbra_expiry', 'umbra_chave', 'umbra_plano']);

  // Sem chave/token → nunca foi ativado
  if (!data.umbra_chave || !data.umbra_token) {
    return { valido: false, motivo: 'Nenhuma licença ativada.' };
  }

  // Sessão local ainda válida → não bate no servidor
  const isExpired = !data.umbra_expiry || Date.now() > data.umbra_expiry;
  if (!isExpired) {
    return { valido: true, cached: true, plano: data.umbra_plano };
  }

  // Sessão expirada → verificar online
  const info = await callSDK('verify');

  // Kill Switch remoto
  if (info.blocked) {
    await chrome.storage.local.set({ umbra_blocked: true, umbra_motivo: info.motivo });
    notifyTabsRevoked(info.motivo);
    return { blocked: true, motivo: info.motivo };
  }

  // Sem internet mas tinha sessão → aceitar offline
  if (info.error === 'offline') {
    return { valido: true, offline: true, plano: data.umbra_plano };
  }

  if (info.valido) {
    const expiry = Date.now() + ((info.token_duration || 86400) * 1000);
    const update = { umbra_blocked: false, umbra_expiry: expiry, umbra_plano: info.plano || data.umbra_plano };
    if (info.token) update.umbra_token = info.token;
    await chrome.storage.local.set(update);
    return { valido: true, plano: info.plano || data.umbra_plano };
  } else {
    await chrome.storage.local.remove(['umbra_token', 'umbra_expiry']);
    return { valido: false, motivo: info.motivo };
  }
}

// ── Ativar chave ──────────────────────────────────────────────────
async function activate(chave) {
  const res = await callSDK('activate', { chave });
  if (res.valido) {
    const expiry = Date.now() + ((res.token_duration || 86400) * 1000);
    await chrome.storage.local.set({
      umbra_chave:   chave,
      umbra_token:   res.token,
      umbra_expiry:  expiry,
      umbra_plano:   res.plano,
      umbra_blocked: false
    });
  }
  return res;
}

// ── Heartbeat a cada 6h ───────────────────────────────────────────
chrome.alarms.create('umbra_heartbeat', { periodInMinutes: 360 });
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'umbra_heartbeat') checkStatus();
});

async function notifyTabsRevoked(motivo) {
  const tabs = await chrome.tabs.query({ url: '*://*.tiktok.com/*' });
  tabs.forEach(t => chrome.tabs.sendMessage(t.id, { action: 'licenseRevoked', motivo }).catch(() => {}));
}

// ══════════════════════════════════════════════════════════════════
// INSTALAÇÃO
// ══════════════════════════════════════════════════════════════════

chrome.runtime.onInstalled.addListener(async () => {
  console.log('Umbra TikTok Downloader v2.0.2 instalado!');
  await getDeviceId(); // garante que o fingerprint é gerado logo
  await chrome.storage.sync.set({
    useSubdirectory: true,
    subdirectoryName: 'TikTok',
    groqApiKey: ''
  });
});

// ══════════════════════════════════════════════════════════════════
// MESSAGE HANDLER
// ══════════════════════════════════════════════════════════════════

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

  if (request.action === 'ATIVAR_LICENCA' || request.action === 'ACTIVATE') {
    activate(request.chave)
      .then(r => sendResponse(r))
      .catch(e => sendResponse({ valido: false, motivo: e.message }));
    return true;
  }

  if (request.action === 'CHECK_LICENSE' || request.action === 'GET_STATUS') {
    checkStatus()
      .then(r => sendResponse(r))
      .catch(e => sendResponse({ valido: false, motivo: e.message }));
    return true;
  }

  if (request.action === 'LOGOUT_LICENSE') {
    chrome.storage.local.remove(
      ['umbra_token', 'umbra_chave', 'umbra_expiry', 'umbra_plano', 'umbra_blocked'],
      () => sendResponse({ success: true })
    );
    return true;
  }

  if (request.action === 'downloadVideo') {
    handleDownload(request.url, request.filename, request.settings || {})
      .then(r  => sendResponse(r))
      .catch(e => sendResponse({ success: false, error: e.message }));
    return true;
  }

  if (request.action === 'fetchTikWM') {
    fetchTikWMData(request.url)
      .then(data => sendResponse({ success: true, data }))
      .catch(e   => sendResponse({ success: false, error: e.message }));
    return true;
  }

  if (request.action === 'fetchText') {
    fetch(request.url)
      .then(r => r.text())
      .then(text => sendResponse({ success: true, text }))
      .catch(e   => sendResponse({ success: false, error: e.message }));
    return true;
  }

  if (request.action === 'fetchBlob') {
    fetchAsBase64(request.url)
      .then(r  => sendResponse(r))
      .catch(e => sendResponse({ success: false, error: e.message }));
    return true;
  }
});

// ── CLIQUE NO ÍCONE ───────────────────────────────────────────────
chrome.action.onClicked.addListener(tab => {
  if (tab.url && tab.url.includes('tiktok.com')) {
    chrome.tabs.sendMessage(tab.id, { action: 'togglePanel' });
  } else {
    chrome.tabs.create({ url: 'https://www.tiktok.com' });
  }
});

// ══════════════════════════════════════════════════════════════════
// UTILITÁRIOS
// ══════════════════════════════════════════════════════════════════

async function fetchTikWMData(tiktokUrl) {
  const apiUrl = `https://www.tikwm.com/api/?url=${encodeURIComponent(tiktokUrl)}&hd=1`;
  const res    = await fetch(apiUrl);
  if (!res.ok) throw new Error(`TikWM HTTP ${res.status}`);
  const json = await res.json();
  if (json.code !== 0) throw new Error(json.msg || 'Erro na API TikWM');
  return json.data;
}

async function fetchAsBase64(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status} ao baixar áudio`);

  const mimeType = res.headers.get('content-type') || 'video/mp4';
  const buffer   = await res.arrayBuffer();
  const bytes    = new Uint8Array(buffer);

  const CHUNK = 8192;
  let binary  = '';
  for (let i = 0; i < bytes.length; i += CHUNK) {
    binary += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
  }

  return { success: true, base64: btoa(binary), mimeType };
}

async function handleDownload(url, filename, settings) {
  let path = filename;
  if (settings.useSubdirectory && settings.subdirectoryName) {
    path = `${settings.subdirectoryName}/${filename}`;
  }
  const downloadId = await chrome.downloads.download({
    url, filename: path, saveAs: false, conflictAction: 'uniquify'
  });
  return { success: true, downloadId };
}
