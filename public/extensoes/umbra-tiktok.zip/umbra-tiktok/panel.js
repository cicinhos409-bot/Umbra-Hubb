// panel.js - Umbra TikTok Downloader
// This file is used by panel.html (standalone page version)

const autoUrlText = document.getElementById('autoUrlText');
const autoBtn = document.getElementById('autoBtn');
const urlInput = document.getElementById('urlInput');
const fetchBtn = document.getElementById('fetchBtn');
const statusEl = document.getElementById('statusEl');
const videoInfo = document.getElementById('videoInfo');
const videoThumb = document.getElementById('videoThumb');
const videoCreator = document.getElementById('videoCreator');
const videoTitleEl = document.getElementById('videoTitleEl');
const dlBtns = document.getElementById('dlBtns');

let isFetching = false;

function showStatus(msg, type = 'info') {
  statusEl.className = `status ${type}`;
  statusEl.innerHTML = msg;
}

function hideStatus() {
  statusEl.className = 'status';
  statusEl.textContent = '';
}

// Detect if we're running in extension context
const isExtension = typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id;

async function fetchVideoData(tiktokUrl) {
  if (isFetching) return;
  isFetching = true;
  fetchBtn.disabled = true;
  fetchBtn.textContent = '...';
  dlBtns.innerHTML = '';
  videoInfo.classList.remove('show');
  showStatus('<span class="spinner"></span> Buscando vídeo sem marca d\'água...', 'info');

  try {
    let data;

    if (isExtension) {
      // Use background script to avoid CORS
      data = await new Promise((resolve, reject) => {
        chrome.runtime.sendMessage({ action: 'fetchTikWM', url: tiktokUrl }, (res) => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else if (res.success) resolve(res.data);
          else reject(new Error(res.error));
        });
      });
    } else {
      // Direct fetch (works in standalone HTML page)
      const apiUrl = `https://www.tikwm.com/api/?url=${encodeURIComponent(tiktokUrl)}&hd=1`;
      const res = await fetch(apiUrl);
      const json = await res.json();
      if (json.code !== 0) throw new Error(json.msg || 'API error');
      data = json.data;
    }

    const author = data.author?.unique_id || data.author?.nickname || 'Desconhecido';
    const title = data.title || '';

    videoCreator.textContent = `@${author}`;
    videoTitleEl.textContent = title.substring(0, 80) + (title.length > 80 ? '...' : '');

    if (data.cover) {
      videoThumb.src = data.cover;
      videoThumb.style.display = 'block';
    } else {
      videoThumb.style.display = 'none';
    }

    videoInfo.classList.add('show');
    dlBtns.innerHTML = '';

    const makeBtn = (label, url, cls, badge) => {
      const btn = document.createElement('button');
      btn.className = `dl-btn ${cls}`;
      btn.innerHTML = `<span>${label}</span><span class="dl-badge">${badge}</span>`;
      btn.addEventListener('click', () => {
        const filename = `@${author}_${data.id || Date.now()}.mp4`;

        if (isExtension) {
          chrome.storage.sync.get({ useSubdirectory: true, subdirectoryName: 'TikTok' }, (settings) => {
            chrome.runtime.sendMessage({ action: 'downloadVideo', url, filename, settings }, (res) => {
              if (res && res.success) showStatus('✅ Download iniciado!', 'success');
              else { window.open(url, '_blank'); showStatus('⚠️ Abrindo em nova aba...', 'info'); }
            });
          });
        } else {
          // Standalone page: open in new tab
          window.open(url, '_blank');
          showStatus('✅ Abrindo download em nova aba!', 'success');
        }
      });
      dlBtns.appendChild(btn);
    };

    if (data.hdplay) makeBtn('🎬 HD Sem Marca D\'água', data.hdplay, 'hd', 'HD');
    if (data.play)   makeBtn('📹 Qualidade Normal', data.play, 'normal', 'SD');
    if (data.wmplay) makeBtn('⚡ Download Rápido', data.wmplay, 'fast', 'COM LOGO');

    if (!data.hdplay && !data.play) {
      showStatus('❌ Nenhuma URL encontrada para este vídeo', 'error');
    } else {
      showStatus('✅ Escolha a qualidade para baixar:', 'success');
    }

  } catch (err) {
    console.error('Umbra panel error:', err);
    showStatus(`❌ ${err.message || 'Erro ao buscar vídeo'}. Tente novamente.`, 'error');
  } finally {
    isFetching = false;
    fetchBtn.disabled = false;
    fetchBtn.textContent = 'Buscar';
  }
}

fetchBtn.addEventListener('click', () => {
  const url = urlInput.value.trim();
  if (!url) { showStatus('❌ Cole um link do TikTok!', 'error'); return; }
  if (!url.includes('tiktok')) { showStatus('❌ Link inválido! Use um link do TikTok.', 'error'); return; }
  fetchVideoData(url);
});

urlInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') fetchBtn.click();
});

autoBtn.addEventListener('click', () => {
  if (isExtension) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0] && tabs[0].url) fetchVideoData(tabs[0].url);
    });
  }
});

// If running as extension panel, check active tab URL
if (isExtension) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0] && tabs[0].url && /tiktok\.com\/@[^/]+\/video\/\d+/.test(tabs[0].url)) {
      const url = tabs[0].url;
      autoUrlText.textContent = url.replace(/https?:\/\/www\./, '').substring(0, 55) + '...';
      autoBtn.disabled = false;
    }
  });
}
