// ═══════════════════════════════════════════════════════
// UMBRA CLAUDE AUTOMATION - Content Script
// ═══════════════════════════════════════════════════════

(function () {
  'use strict';

  // ─── Message listener (ALWAYS respond immediately) ──
  chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    // Ping check — respond immediately
    if (request.type === 'PING') {
      sendResponse({ ok: true });
      return true;
    }

    // All other handlers respond immediately too
    sendResponse({ ok: true });

    // Long-running ops happen in background, never block the channel
    if (request.type === 'STEP') {
      handleStep(request);
    }
    if (request.type === 'LOG') {
      console.log('[Umbra Content]', request.level, request.message);
    }

    return false; // sync response already sent
  });

  function handleStep(data) {
    // Notify page-level if needed (future use)
    if (data.action === 'finished') {
      // Automation done — content script can react here
    }
  }
})();
