// ═══════════════════════════════════════════════════════
// UMBRA CLAUDE AUTOMATION - App Window Logic
// ═══════════════════════════════════════════════════════

(function () {
  'use strict';

  // ─── State ────────────────────────────────────────────
  let messages = [];
  let savedSequences = {};
  let settings = {
    cooldown: 2000,
    autoTab: true,
    focusTab: false,
    notify: true,
  };
  let isRunning = false;

  // ─── Element refs ──────────────────────────────────────
  const viewLicense     = document.getElementById('view-license');
  const appShell        = document.getElementById('app-shell');
  const licenseInput    = document.getElementById('license-key-input');
  const licenseError    = document.getElementById('license-error');
  const btnActivate     = document.getElementById('btn-activate');
  const btnLogout       = document.getElementById('btn-logout');
  const accountKeyDisp  = document.getElementById('account-key-display');

  const statusDot       = document.getElementById('status-dot');
  const statusDotLabel  = statusDot.querySelector('.label');

  const automationStatus= document.getElementById('automation-status');
  const statusText      = document.getElementById('status-text');
  const progressWrap    = document.getElementById('progress-wrap');
  const progressStep    = document.getElementById('progress-step');
  const progressPct     = document.getElementById('progress-pct');
  const progressFill    = document.getElementById('progress-bar-fill');
  const reviewBanner    = document.getElementById('review-banner');

  const msgTextarea     = document.getElementById('msg-textarea');
  const varSelect       = document.getElementById('var-select');
  const btnAddMsg       = document.getElementById('btn-add-msg');
  const msgList         = document.getElementById('msg-list');
  const btnSaveSeq      = document.getElementById('btn-save-seq');
  const btnClearQueue   = document.getElementById('btn-clear-queue');
  const btnSend         = document.getElementById('btn-send');
  const btnStop         = document.getElementById('btn-stop');

  const seqDropdown     = document.getElementById('seq-dropdown');
  const seqPreview      = document.getElementById('seq-preview');
  const btnLoadSeq      = document.getElementById('btn-load-seq');
  const btnDeleteSeq    = document.getElementById('btn-delete-seq');
  const btnLoadToQueue  = document.getElementById('btn-load-to-queue');

  const settingCooldown = document.getElementById('setting-cooldown');
  const settingAutoTab  = document.getElementById('setting-auto-tab');
  const settingFocusTab = document.getElementById('setting-focus-tab');
  const settingNotify   = document.getElementById('setting-notify');

  const btnRateNow      = document.getElementById('btn-rate-now');
  const btnRateLater    = document.getElementById('btn-rate-later');
  const btnRateNever    = document.getElementById('btn-rate-never');

  // ═══════════════════════════════════════════════════════
  // INIT
  // ═══════════════════════════════════════════════════════

  init();

  async function init() {
    setStatus('idle', 'Idle');
    const response = await sendToBackground({ type: 'GET_STATUS' });
    if (response && response.valido) {
      showApp();
    } else {
      showLicense();
    }
  }

  // ═══════════════════════════════════════════════════════
  // LICENSE GATE
  // ═══════════════════════════════════════════════════════

  function showLicense() {
    viewLicense.classList.add('active');
    appShell.style.display = 'none';
    document.getElementById('app-tabs') && (document.getElementById('app-tabs').style.display = 'none');
  }

  function showApp() {
    viewLicense.classList.remove('active');
    viewLicense.style.display = 'none';
    appShell.style.display = 'flex';
    loadAppData();
  }

  btnActivate.addEventListener('click', async () => {
    const chave = licenseInput.value.trim().toUpperCase();
    if (!chave) return;
    btnActivate.disabled = true;
    btnActivate.textContent = 'Validando...';
    licenseError.textContent = '';
    const res = await sendToBackground({ type: 'ACTIVATE', chave });
    btnActivate.disabled = false;
    btnActivate.textContent = 'Ativar Agora';
    if (res && res.valido) {
      showApp();
    } else {
      licenseError.textContent = (res && res.motivo) || 'Chave inválida ou limite atingido.';
    }
  });

  licenseInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') btnActivate.click(); });

  btnLogout.addEventListener('click', async () => {
    await sendToBackground({ type: 'LOGOUT' });
    messages = [];
    savedSequences = {};
    viewLicense.style.display = '';
    showLicense();
  });

  // ═══════════════════════════════════════════════════════
  // LOAD APP DATA
  // ═══════════════════════════════════════════════════════

  function loadAppData() {
    chrome.storage.local.get(
      ['messages', 'sequences', 'isRunning', 'showReviewBanner', 'settings', 'umbra_chave'],
      (data) => {
        if (data.messages)         { messages = data.messages; renderQueue(); }
        if (data.sequences)        { savedSequences = data.sequences; renderSequenceDropdown(); }
        if (data.settings)         { Object.assign(settings, data.settings); applySettings(); }
        if (data.isRunning)        { setRunning(true); }
        if (data.showReviewBanner) { reviewBanner.style.display = 'flex'; }
        if (data.umbra_chave)      { accountKeyDisp.textContent = maskKey(data.umbra_chave); }
        refreshVarDropdown();
      }
    );
  }

  function maskKey(key) {
    if (!key || key.length < 8) return 'Licença ativa';
    return key.slice(0, 8) + '••••••••';
  }

  function applySettings() {
    settingCooldown.value = settings.cooldown;
    settingAutoTab.checked = settings.autoTab;
    settingFocusTab.checked = settings.focusTab;
    settingNotify.checked = settings.notify;
  }

  function saveSettings() {
    chrome.storage.local.set({ settings });
  }

  // Settings listeners
  settingCooldown.addEventListener('change', () => {
    settings.cooldown = parseInt(settingCooldown.value, 10) || 2000;
    saveSettings();
  });
  settingAutoTab.addEventListener('change', () => { settings.autoTab = settingAutoTab.checked; saveSettings(); });
  settingFocusTab.addEventListener('change', () => { settings.focusTab = settingFocusTab.checked; saveSettings(); });
  settingNotify.addEventListener('change', () => { settings.notify = settingNotify.checked; saveSettings(); });

  // ═══════════════════════════════════════════════════════
  // TABS
  // ═══════════════════════════════════════════════════════

  document.querySelectorAll('.tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const tab = btn.dataset.tab;
      document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
      document.querySelectorAll('.view').forEach((v) => v.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(`view-${tab}`)?.classList.add('active');
    });
  });

  // ═══════════════════════════════════════════════════════
  // MESSAGE QUEUE
  // ═══════════════════════════════════════════════════════

  btnAddMsg.addEventListener('click', addMessage);
  msgTextarea.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); addMessage(); }
  });

  function addMessage() {
    const text = msgTextarea.value.trim();
    if (!text) return;
    messages.push(text);
    msgTextarea.value = '';
    saveMessages();
    renderQueue();
    refreshVarDropdown();
  }

  function renderQueue() {
    if (messages.length === 0) {
      msgList.innerHTML = '<div class="msg-empty">Nenhuma mensagem na fila</div>';
      return;
    }
    msgList.innerHTML = messages.map((m, i) => `
      <div class="msg-item">
        <span class="msg-num">${i + 1}</span>
        <span class="msg-text">${esc(m)}</span>
        <button class="msg-del" data-index="${i}" title="Remover">✕</button>
      </div>
    `).join('');

    msgList.querySelectorAll('.msg-del').forEach((btn) => {
      btn.addEventListener('click', () => {
        messages.splice(parseInt(btn.dataset.index, 10), 1);
        saveMessages();
        renderQueue();
        refreshVarDropdown();
      });
    });
  }

  btnClearQueue.addEventListener('click', () => {
    messages = [];
    saveMessages();
    renderQueue();
    refreshVarDropdown();
  });

  function saveMessages() { chrome.storage.local.set({ messages }); }

  // ═══════════════════════════════════════════════════════
  // VARIABLES
  // ═══════════════════════════════════════════════════════

  function getVariables() {
    const vars = new Set();
    const scan = (str) => {
      const re = /\{\{(.*?)\}\}/g;
      let m;
      while ((m = re.exec(str)) !== null) if (m[1].trim()) vars.add(m[1].trim());
    };
    messages.forEach(scan);
    scan(msgTextarea.value);
    return Array.from(vars);
  }

  function refreshVarDropdown() {
    varSelect.innerHTML = `<option value="" disabled selected>{{x}}</option><option value="NEW_VAR">+ Nova var</option>`;
    getVariables().forEach((v) => {
      const o = document.createElement('option');
      o.value = v;
      o.textContent = `{{${v}}}`;
      varSelect.appendChild(o);
    });
  }

  msgTextarea.addEventListener('input', refreshVarDropdown);

  varSelect.addEventListener('change', function () {
    const val = this.value;
    if (val === 'NEW_VAR') {
      const name = prompt('Nome da nova variável:');
      if (name && name.trim()) { insertAtCursor(`{{${name.trim()}}}`); refreshVarDropdown(); }
    } else if (val) {
      insertAtCursor(`{{${val}}}`);
    }
    this.value = '';
  });

  function insertAtCursor(text) {
    const s = msgTextarea.selectionStart;
    const v = msgTextarea.value;
    msgTextarea.value = v.slice(0, s) + text + v.slice(msgTextarea.selectionEnd);
    msgTextarea.focus();
    msgTextarea.setSelectionRange(s + text.length, s + text.length);
  }

  // ═══════════════════════════════════════════════════════
  // SEQUENCES
  // ═══════════════════════════════════════════════════════

  btnSaveSeq.addEventListener('click', () => {
    if (!messages.length) { alert('Adicione mensagens antes de salvar.'); return; }
    const name = prompt('Nome para esta sequência:');
    if (!name || !name.trim()) return;
    savedSequences[name.trim()] = [...messages];
    chrome.storage.local.set({ sequences: savedSequences }, () => {
      renderSequenceDropdown(name.trim());
    });
  });

  function renderSequenceDropdown(selectName) {
    const names = Object.keys(savedSequences);
    if (!names.length) {
      seqDropdown.innerHTML = '<option value="" disabled selected>Nenhuma sequência salva</option>';
      seqPreview.innerHTML = '<div class="msg-empty">Selecione uma sequência para visualizar</div>';
      return;
    }
    seqDropdown.innerHTML = names.map((n) => `<option value="${esc(n)}">${esc(n)}</option>`).join('');
    const target = (selectName && savedSequences[selectName]) ? selectName : names[0];
    seqDropdown.value = target;
    renderSeqPreview(target);
  }

  function renderSeqPreview(name) {
    const seq = savedSequences[name];
    if (!seq || !seq.length) {
      seqPreview.innerHTML = '<div class="msg-empty">Sequência vazia</div>';
      return;
    }
    seqPreview.innerHTML = seq.map((m, i) => `
      <div class="msg-item">
        <span class="msg-num">${i + 1}</span>
        <span class="msg-text">${esc(m)}</span>
      </div>
    `).join('');
  }

  seqDropdown.addEventListener('change', () => renderSeqPreview(seqDropdown.value));

  btnLoadSeq.addEventListener('click', () => {
    const name = seqDropdown.value;
    if (!name || !savedSequences[name]) return;
    messages = [...savedSequences[name]];
    saveMessages();
    renderQueue();
    refreshVarDropdown();
    // Switch to automation tab
    document.querySelector('[data-tab="automation"]')?.click();
  });

  btnLoadToQueue.addEventListener('click', () => btnLoadSeq.click());

  btnDeleteSeq.addEventListener('click', () => {
    const name = seqDropdown.value;
    if (!name || !savedSequences[name]) return;
    if (!confirm(`Excluir a sequência "${name}"?`)) return;
    delete savedSequences[name];
    chrome.storage.local.set({ sequences: savedSequences }, () => renderSequenceDropdown());
  });

  // ═══════════════════════════════════════════════════════
  // SEND / AUTOMATION
  // ═══════════════════════════════════════════════════════

  btnSend.addEventListener('click', async () => {
    if (!messages.length) { alert('Adicione mensagens à fila antes de enviar.'); return; }
    const vars = getVariables();
    let resolved = [...messages];

    if (vars.length > 0) {
      const values = {};
      for (const v of vars) {
        const val = prompt(`Valor para {{${v}}}:`);
        if (val === null) return;
        values[v] = val;
      }
      resolved = resolved.map((msg) => {
        let t = msg;
        for (const [k, v] of Object.entries(values)) {
          t = t.split(`{{${k}}}`).join(v);
        }
        return t;
      });
    }

    setRunning(true);
    setStatus('run', 'Executando');

    const res = await sendToBackground({
      type: 'TO_FLOW',
      payload: { action: 'startSequence', messages: resolved },
    });

    if (!res || !res.ok) {
      setRunning(false);
      setStatus('err', 'Erro');
      showStatusBanner('error', 'Não foi possível iniciar a automação.');
    }

    if (settings.focusTab && res && res.tabId) {
      chrome.tabs.update(res.tabId, { active: true });
    }
  });

  btnStop.addEventListener('click', async () => {
    await sendToBackground({ type: 'TO_FLOW', payload: { action: 'stopSequence' } });
    setRunning(false);
    setStatus('idle', 'Idle');
    hideStatusBanner();
    hideProgress();
  });

  // ═══════════════════════════════════════════════════════
  // MESSAGES FROM BACKGROUND
  // ═══════════════════════════════════════════════════════

  chrome.runtime.onMessage.addListener((request) => {
    if (request.type === 'STEP') {
      if (request.action === 'finished') {
        handleFinished(request.successCount);
      } else if (request.step !== undefined) {
        updateProgress(request.step, request.total);
        showStatusBanner('running', `Enviando mensagem ${request.step} de ${request.total}...`);
      }
    }
    if (request.type === 'PROGRESS') {
      updateProgress(request.current, request.total);
    }
    if (request.type === 'LOG' && request.level === 'error') {
      showStatusBanner('error', request.message);
      setStatus('err', 'Erro');
      setRunning(false);
    }
  });

  function handleFinished(successCount) {
    setRunning(false);
    setStatus('ok', 'Concluído');

    if (settings.notify) {
      showStatusBanner('success', '✔ Automação concluída com sucesso!');
      setTimeout(() => {
        setStatus('idle', 'Idle');
        hideStatusBanner();
      }, 3500);
    }

    // Progress to 100%
    updateProgress(1, 1);
    setTimeout(hideProgress, 3500);

    chrome.storage.local.get(['showReviewBanner'], (data) => {
      if (data.showReviewBanner) reviewBanner.style.display = 'flex';
    });
  }

  // ═══════════════════════════════════════════════════════
  // REVIEW
  // ═══════════════════════════════════════════════════════

  btnRateNow.addEventListener('click', () => {
    window.open('https://umbrahubb.vercel.app/', '_blank');
    chrome.storage.local.set({ reviewStatus: 'rated', showReviewBanner: false });
    reviewBanner.style.display = 'none';
  });
  btnRateLater.addEventListener('click', () => {
    chrome.storage.local.set({ showReviewBanner: false });
    reviewBanner.style.display = 'none';
  });
  btnRateNever.addEventListener('click', () => {
    chrome.storage.local.set({ reviewStatus: 'never', showReviewBanner: false });
    reviewBanner.style.display = 'none';
  });

  // ═══════════════════════════════════════════════════════
  // UI HELPERS
  // ═══════════════════════════════════════════════════════

  function setStatus(state, label) {
    statusDot.className = state;
    statusDotLabel.textContent = label;
  }

  function setRunning(running) {
    isRunning = running;
    btnSend.style.display = running ? 'none' : '';
    btnStop.style.display = running ? '' : 'none';
    if (!running) {
      hideProgress();
    } else {
      showProgress(0, messages.length);
    }
  }

  function showStatusBanner(type, msg) {
    automationStatus.style.display = 'flex';
    automationStatus.classList.remove('success');
    if (type === 'success') {
      automationStatus.classList.add('success');
      automationStatus.innerHTML = `<svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg> ${msg}`;
    } else if (type === 'error') {
      automationStatus.innerHTML = `<svg viewBox="0 0 24 24" style="fill:var(--error)"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg> ${msg}`;
      automationStatus.style.background = 'rgba(248,113,113,0.1)';
      automationStatus.style.borderColor = 'rgba(248,113,113,0.25)';
      automationStatus.style.color = 'var(--error)';
    } else {
      statusText.textContent = msg;
      automationStatus.innerHTML = `<span class="spinner"></span> ${msg}`;
    }
  }

  function hideStatusBanner() {
    automationStatus.style.display = 'none';
    automationStatus.style.background = '';
    automationStatus.style.borderColor = '';
    automationStatus.style.color = '';
  }

  function showProgress(current, total) {
    progressWrap.style.display = 'flex';
    updateProgress(current, total);
  }

  function hideProgress() {
    progressWrap.style.display = 'none';
  }

  function updateProgress(current, total) {
    if (!total) return;
    const pct = Math.round((current / total) * 100);
    progressStep.textContent = `Mensagem ${current} de ${total}`;
    progressPct.textContent = `${pct}%`;
    progressFill.style.width = `${pct}%`;
    progressWrap.style.display = 'flex';
  }

  // ═══════════════════════════════════════════════════════
  // UTILITIES
  // ═══════════════════════════════════════════════════════

  function esc(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function sendToBackground(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (response) => {
          if (chrome.runtime.lastError) { resolve(null); return; }
          resolve(response);
        });
      } catch (e) {
        resolve(null);
      }
    });
  }

})();
