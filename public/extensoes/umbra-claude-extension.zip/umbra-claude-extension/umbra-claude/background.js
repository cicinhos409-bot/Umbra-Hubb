// ═══════════════════════════════════════════════════════
// UMBRA CLAUDE AUTOMATION - Background Service Worker
// ═══════════════════════════════════════════════════════

const APP_URL = chrome.runtime.getURL('app.html');
const SITE_URL = 'https://claude.ai/new';
const SITE_MATCH = 'https://claude.ai/*';

// ─── Window State ─────────────────────────────────────
let appWindowId = null;

// ─── Automation State ─────────────────────────────────
let isRunning = false;
let lockedTabId = null;

// ─── License SDK Config ───────────────────────────────
const SDK = {
  endpoint: 'https://cvrdcupvqvkpwllwlkfw.functions.supabase.co/validar-licenca',
  slug: 'umbrahub-all',
  version: '1.0.0',
  sessionHours: 24,
  heartbeatHours: 6,
};

// ═══════════════════════════════════════════════════════
// WINDOW MANAGEMENT
// ═══════════════════════════════════════════════════════

chrome.action.onClicked.addListener(async () => {
  if (appWindowId !== null) {
    try {
      const win = await chrome.windows.get(appWindowId);
      if (win) {
        chrome.windows.update(appWindowId, { focused: true });
        return;
      }
    } catch (e) {
      appWindowId = null;
    }
  }
  const win = await chrome.windows.create({
    url: APP_URL,
    type: 'popup',
    width: 400,
    height: 680,
    focused: true,
  });
  appWindowId = win.id;
});

chrome.windows.onRemoved.addListener((windowId) => {
  if (windowId === appWindowId) appWindowId = null;
});

// ═══════════════════════════════════════════════════════
// CLAUDE TAB MANAGEMENT
// ═══════════════════════════════════════════════════════

async function getOrCreateClaudeTab() {
  const tabs = await chrome.tabs.query({ url: SITE_MATCH });
  if (tabs.length > 0) return tabs[0].id;
  const tab = await chrome.tabs.create({ url: SITE_URL, active: false });
  return tab.id;
}

// ═══════════════════════════════════════════════════════
// LICENSE SDK
// ═══════════════════════════════════════════════════════

async function getDeviceId() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['umbra_device_id'], (data) => {
      if (data.umbra_device_id) return resolve(data.umbra_device_id);
      const id = 'dev_' + Date.now() + '_' + Math.random().toString(36).slice(2, 10);
      chrome.storage.local.set({ umbra_device_id: id }, () => resolve(id));
    });
  });
}

async function callLicenseAPI(payload) {
  try {
    const res = await fetch(SDK.endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return await res.json();
  } catch (e) {
    console.error('[Umbra SDK] API error:', e);
    return null;
  }
}

async function activateLicense(chave) {
  const device_id = await getDeviceId();
  const result = await callLicenseAPI({
    action: 'activate',
    chave,
    device_id,
    slug: SDK.slug,
    version: SDK.version,
  });
  if (result && result.valido) {
    const expiry = Date.now() + SDK.sessionHours * 3600 * 1000;
    await chrome.storage.local.set({
      umbra_chave: chave,
      umbra_token: result.token || '',
      umbra_expiry: expiry,
    });
    scheduleHeartbeat();
    return { valido: true };
  }
  return { valido: false, motivo: result?.motivo || 'Chave inválida ou limite atingido.' };
}

async function verifyLicense() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['umbra_chave', 'umbra_token', 'umbra_expiry'], async (data) => {
      if (!data.umbra_chave) return resolve({ valido: false, motivo: 'Sem licença.' });
      if (data.umbra_expiry && Date.now() < data.umbra_expiry) return resolve({ valido: true });
      const device_id = await getDeviceId();
      const result = await callLicenseAPI({
        action: 'verify',
        chave: data.umbra_chave,
        device_id,
        token: data.umbra_token || '',
        slug: SDK.slug,
        version: SDK.version,
      });
      if (result && result.valido) {
        const expiry = Date.now() + SDK.sessionHours * 3600 * 1000;
        await chrome.storage.local.set({
          umbra_token: result.token || data.umbra_token,
          umbra_expiry: expiry,
        });
        return resolve({ valido: true });
      }
      await chrome.storage.local.remove(['umbra_chave', 'umbra_token', 'umbra_expiry']);
      resolve({ valido: false, motivo: result?.motivo || 'Licença revogada.' });
    });
  });
}

function scheduleHeartbeat() {
  chrome.alarms.create('umbra_heartbeat', { periodInMinutes: SDK.heartbeatHours * 60 });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'umbra_heartbeat') verifyLicense();
});

chrome.storage.local.get(['umbra_chave'], (data) => {
  if (data.umbra_chave) scheduleHeartbeat();
});

// ═══════════════════════════════════════════════════════
// MESSAGE ROUTER
// ═══════════════════════════════════════════════════════

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  // ── License ──
  if (request.type === 'GET_STATUS') {
    verifyLicense().then(sendResponse);
    return true;
  }
  if (request.type === 'ACTIVATE') {
    activateLicense(request.chave).then(sendResponse);
    return true;
  }
  if (request.type === 'LOGOUT') {
    chrome.storage.local.remove(['umbra_chave', 'umbra_token', 'umbra_expiry'], () => sendResponse({ ok: true }));
    return true;
  }

  // ── Automation ──
  if (request.type === 'TO_FLOW') {
    const { payload } = request;

    if (payload.action === 'startSequence') {
      handleStartSequence(payload.messages, sendResponse);
      return true;
    }
    if (payload.action === 'stopSequence') {
      isRunning = false;
      lockedTabId = null;
      chrome.storage.local.set({ isRunning: false });
      sendResponse({ ok: true });
      return true;
    }
    if (payload.action === 'openClaudeTab') {
      getOrCreateClaudeTab().then((tabId) => sendResponse({ tabId }));
      return true;
    }
  }

  // ── Relay from content.js to app window ──
  if (request.type === 'LOG' || request.type === 'PROGRESS' || request.type === 'STEP') {
    relayToApp(request);
    sendResponse({ ok: true });
    return true;
  }
});

function relayToApp(msg) {
  if (appWindowId === null) return;
  chrome.windows.get(appWindowId, { populate: true }, (win) => {
    if (chrome.runtime.lastError || !win) return;
    win.tabs.forEach((tab) => {
      chrome.tabs.sendMessage(tab.id, msg, () => { if (chrome.runtime.lastError) {} });
    });
  });
}

// ═══════════════════════════════════════════════════════
// AUTOMATION ENGINE
// ═══════════════════════════════════════════════════════

async function handleStartSequence(messages, sendResponse) {
  const tabId = await getOrCreateClaudeTab();

  // Wait for content script to be ready (retry up to 5×)
  let ready = false;
  for (let i = 0; i < 5; i++) {
    try {
      await chrome.tabs.sendMessage(tabId, { type: 'PING' });
      ready = true;
      break;
    } catch {
      await sleep(800);
    }
  }

  if (!ready) {
    // Inject content script manually as fallback
    try {
      await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
      await chrome.scripting.insertCSS({ target: { tabId }, files: ['content.css'] });
      await sleep(600);
    } catch (e) {
      console.error('[Umbra] Could not inject content script:', e);
    }
  }

  isRunning = true;
  lockedTabId = tabId;
  chrome.storage.local.set({ isRunning: true });
  sendResponse({ ok: true, tabId });

  processQueue(messages, tabId);
}

async function processQueue(messages, tabId) {
  let queue = [...messages];
  try {
    while (queue.length > 0 && isRunning && lockedTabId) {
      const msg = queue[0];
      const total = messages.length;
      const current = total - queue.length + 1;

      relayToApp({ type: 'STEP', step: current, total, text: msg });

      const success = await sendPromptToTab(tabId, msg);
      if (!success) throw new Error('Tab not found or input unavailable.');

      await waitForClaudeResponse(tabId);
      if (!isRunning) break;

      queue.shift();
      await chrome.storage.local.set({ messages: queue });
      relayToApp({ type: 'PROGRESS', current, total });
      if (queue.length > 0) await sleep(2000);
    }
  } catch (error) {
    console.error('[Umbra] Automation error:', error);
    relayToApp({ type: 'LOG', level: 'error', message: error.message });
  } finally {
    isRunning = false;
    lockedTabId = null;

    chrome.storage.local.get(['reviewStatus', 'successCount'], (data) => {
      const status = data.reviewStatus || 'pending';
      const newCount = (data.successCount || 0) + 1;
      const update = { successCount: newCount, isRunning: false };
      if (status === 'pending' && (newCount === 3 || (newCount > 3 && newCount % 10 === 0))) {
        update.showReviewBanner = true;
      }
      chrome.storage.local.set(update, () => {
        relayToApp({ type: 'STEP', action: 'finished', successCount: newCount });
      });
    });
  }
}

async function sendPromptToTab(tabId, text) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: async (msg) => {
        // Find the ProseMirror / contenteditable editor in Claude
        const findEditor = () =>
          document.querySelector('div[contenteditable="true"].ProseMirror') ||
          document.querySelector('[data-testid="composer-container"] div[contenteditable="true"]') ||
          document.querySelector('div[contenteditable="true"]');

        const editor = findEditor();
        if (!editor) return false;

        editor.focus();

        // Clear existing content safely (Claude uses ProseMirror/Slate-like)
        // Move to end and delete backwards
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(editor);
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);

        // Check if already empty
        const isEditorEmpty = () => {
          const text = editor.innerText.replace(/\n/g, '').trim();
          return text === '' || editor.getAttribute('data-placeholder') !== null;
        };

        if (!isEditorEmpty()) {
          editor.dispatchEvent(new KeyboardEvent('keydown', { key: 'a', code: 'KeyA', ctrlKey: true, bubbles: true }));
          await new Promise(r => setTimeout(r, 80));
          editor.dispatchEvent(new KeyboardEvent('keydown', { key: 'Delete', code: 'Delete', bubbles: true }));
          await new Promise(r => setTimeout(r, 80));
        }

        // Insert text char by char using beforeinput + insertText
        for (const char of msg) {
          editor.dispatchEvent(new InputEvent('beforeinput', {
            inputType: 'insertText',
            data: char,
            bubbles: true,
            cancelable: true,
          }));
          document.execCommand('insertText', false, char);
          await new Promise(r => setTimeout(r, 15));
        }

        // Confirm state (space + backspace trick for Slate/ProseMirror)
        editor.dispatchEvent(new InputEvent('beforeinput', { inputType: 'insertText', data: ' ', bubbles: true }));
        document.execCommand('insertText', false, ' ');
        await new Promise(r => setTimeout(r, 50));
        editor.dispatchEvent(new InputEvent('beforeinput', { inputType: 'deleteContentBackward', bubbles: true }));
        document.execCommand('delete');
        await new Promise(r => setTimeout(r, 80));

        // Click send button
        return new Promise(resolve => {
          setTimeout(() => {
            const viewportHeight = window.innerHeight;

            // Find button by multiple strategies
            const allButtons = Array.from(document.querySelectorAll('button'));

            // Strategy 1: aria-label
            let btn = document.querySelector('button[aria-label="Send message"]') ||
                      document.querySelector('button[aria-label="Enviar mensagem"]') ||
                      document.querySelector('button[data-testid="send-button"]');

            // Strategy 2: button below 55% of viewport
            if (!btn) {
              btn = allButtons.find(b => {
                const rect = b.getBoundingClientRect();
                return rect.top > viewportHeight * 0.55 && !b.disabled && rect.width > 0;
              });
            }

            // Strategy 3: SVG arrow/send icon inside button
            if (!btn) {
              btn = allButtons.find(b => {
                const svg = b.querySelector('svg');
                return svg && !b.disabled;
              });
            }

            if (btn && !btn.disabled) {
              btn.click();
              resolve(true);
            } else {
              // Fallback: Enter key
              editor.dispatchEvent(new KeyboardEvent('keydown', {
                key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true, cancelable: true,
              }));
              resolve(true);
            }
          }, 800);
        });
      },
      args: [text],
    });
    return results[0]?.result ?? false;
  } catch (e) {
    console.error('[Umbra] sendPrompt error:', e);
    return false;
  }
}

async function waitForClaudeResponse(tabId) {
  await sleep(2500);
  return new Promise((resolve) => {
    let idleCount = 0;
    const interval = setInterval(() => {
      if (!isRunning) { clearInterval(interval); resolve(); return; }
      chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          // Claude's streaming indicators
          const streaming = document.querySelector('.font-claude-message [data-is-streaming="true"]') ||
                            document.querySelector('[data-is-streaming]') ||
                            document.querySelector('.result-streaming');
          const stopBtn = document.querySelector('button[aria-label="Stop"]') ||
                          document.querySelector('button[aria-label="Parar"]');
          const spinner = document.querySelector('.loading-indicator, [class*="loading"], [class*="spinner"]');
          return !!(streaming || stopBtn || spinner);
        },
      }, (results) => {
        if (chrome.runtime.lastError) { clearInterval(interval); resolve(); return; }
        const busy = results?.[0]?.result;
        if (!busy) {
          idleCount++;
          if (idleCount >= 3) { clearInterval(interval); setTimeout(resolve, 500); }
        } else {
          idleCount = 0;
        }
      });
    }, 1000);
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
