// UMBRA SCREEN RECORDER - PANEL JS v1.0.2

const QUALITIES = {
    baixa: { videoBitsPerSecond: 1500000 },
    media: { videoBitsPerSecond: 3000000 },
    alta:  { videoBitsPerSecond: 5000000 },
    ultra: { videoBitsPerSecond: 8000000 }
};

let selectedQuality = 'alta';
let isRecording = false;
let isPaused = false;
let timerInterval = null;
let elapsed = 0;

// ============================================
// TABS
// ============================================

document.querySelectorAll('.app-tab').forEach(tab => {
    tab.addEventListener('click', () => {
        document.querySelectorAll('.app-tab').forEach(t => t.classList.remove('active'));
        document.querySelectorAll('.app-tab-content').forEach(c => c.classList.remove('active'));
        tab.classList.add('active');
        document.getElementById(`tab-${tab.dataset.tab}`)?.classList.add('active');
        if (tab.dataset.tab === 'historico') loadHistory();
    });
});

// ============================================
// EVENTS
// ============================================

document.getElementById('record-btn').addEventListener('click', () => {
    const opts = buildOptions();
    bg({ action: 'TOGGLE_RECORDING_REQUEST', options: opts });
    setTimeout(refreshStatus, 600);
});

document.getElementById('pause-btn').addEventListener('click', () => {
    bg({ action: 'TOGGLE_PAUSE_REQUEST' });
    setTimeout(refreshStatus, 300);
});

document.querySelectorAll('.q-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.q-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        selectedQuality = btn.dataset.q;
        saveSettings();
    });
});

document.getElementById('folder-input').addEventListener('input', () => { saveSettings(); updatePath(); });
document.getElementById('prefix-input').addEventListener('input', () => { saveSettings(); updatePath(); });

document.getElementById('mic-toggle').addEventListener('change', (e) => {
    const row = document.getElementById('mic-vol-row');
    row.style.opacity = e.target.checked ? '1' : '0.3';
    row.style.pointerEvents = e.target.checked ? 'all' : 'none';
    saveSettings();
});

document.getElementById('tab-vol').addEventListener('input', (e) => {
    document.getElementById('tab-vol-val').textContent = e.target.value + '%';
    saveSettings();
});

document.getElementById('mic-vol').addEventListener('input', (e) => {
    document.getElementById('mic-vol-val').textContent = e.target.value + '%';
    saveSettings();
});

document.getElementById('autostop').addEventListener('change', saveSettings);

document.getElementById('clear-btn').addEventListener('click', async () => {
    await bg({ action: 'CLEAR_HISTORY' });
    loadHistory();
});

// ============================================
// UTILS
// ============================================

function bg(msg) {
    return new Promise(resolve => chrome.runtime.sendMessage(msg, resolve));
}

function fmt(sec) {
    return `${String(Math.floor(sec/60)).padStart(2,'0')}:${String(sec%60).padStart(2,'0')}`;
}

function buildOptions() {
    const q = QUALITIES[selectedQuality] || QUALITIES.alta;
    return {
        ...q,
        includeMic: document.getElementById('mic-toggle')?.checked || false,
        tabVolume: parseInt(document.getElementById('tab-vol')?.value || 100) / 100,
        micVolume: parseInt(document.getElementById('mic-vol')?.value || 80) / 100,
        autoStopMinutes: parseInt(document.getElementById('autostop')?.value || 0)
    };
}

// ============================================
// RECORDING UI
// ============================================

function setUI(recording, paused = false) {
    isRecording = recording;
    isPaused = paused;

    const card = document.getElementById('status-card');
    const dot = document.getElementById('status-dot');
    const txt = document.getElementById('status-text');
    const timer = document.getElementById('big-timer');
    const btn = document.getElementById('record-btn');
    const btnTxt = document.getElementById('record-btn-text');
    const pauseBtn = document.getElementById('pause-btn');

    clearInterval(timerInterval);

    if (recording && !paused) {
        card.className = 'status-card recording';
        dot.className = 'status-dot recording';
        txt.textContent = '● Gravando'; txt.className = 'status-text recording';
        timer.classList.remove('idle');
        btn.classList.add('recording'); btnTxt.textContent = '■ Parar Gravação';
        pauseBtn.classList.remove('hidden', 'resumed');
        pauseBtn.title = 'Pausar (Alt+P)';
        pauseBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 16 16" fill="currentColor"><rect x="3" y="2" width="4" height="12" rx="1"/><rect x="9" y="2" width="4" height="12" rx="1"/></svg>';
        timerInterval = setInterval(() => { elapsed++; timer.textContent = fmt(elapsed); }, 1000);

    } else if (recording && paused) {
        card.className = 'status-card paused';
        dot.className = 'status-dot paused';
        txt.textContent = '⏸ Pausado'; txt.className = 'status-text paused';
        btn.classList.add('recording'); btnTxt.textContent = '■ Parar Gravação';
        pauseBtn.classList.remove('hidden'); pauseBtn.classList.add('resumed');
        pauseBtn.title = 'Retomar (Alt+P)';
        pauseBtn.innerHTML = '<svg width="18" height="18" viewBox="0 0 16 16" fill="currentColor"><path d="M4 2l10 6-10 6z"/></svg>';

    } else {
        card.className = 'status-card';
        dot.className = 'status-dot';
        txt.textContent = 'Pronto para gravar'; txt.className = 'status-text';
        timer.textContent = '00:00'; timer.classList.add('idle');
        elapsed = 0;
        btn.classList.remove('recording'); btnTxt.textContent = '▶ Iniciar Gravação';
        pauseBtn.classList.add('hidden');
        document.getElementById('size-display').textContent = '—';
    }
}

async function refreshStatus() {
    const s = await bg({ action: 'GET_RECORDING_STATUS' });
    if (!s) return;

    if (s.isRecording && !s.isPaused) {
        elapsed = s.elapsed || 0;
        document.getElementById('big-timer').textContent = fmt(elapsed);
    }

    setUI(s.isRecording, s.isPaused);

    if (s.totalBytes > 0) {
        const mb = (s.totalBytes / 1024 / 1024).toFixed(1);
        document.getElementById('size-display').textContent = `${mb} MB gravados`;
    }

    updateClipsCount();
    updatePath();
    updateDisk();
    getTabInfo();
}

// ============================================
// SETTINGS
// ============================================

function getFolder() { return (document.getElementById('folder-input')?.value || '').trim().replace(/[<>:"/\\|?*]/g,'').replace(/\s+/g,'_'); }
function getPrefix() { return (document.getElementById('prefix-input')?.value || 'clip').trim().replace(/[<>:"/\\|?*]/g,'').replace(/\s+/g,'_') || 'clip'; }

function saveSettings() {
    chrome.storage.local.set({
        umbra_folder: getFolder(), umbra_prefix: getPrefix(),
        umbra_quality: selectedQuality,
        umbra_mic: document.getElementById('mic-toggle')?.checked || false,
        umbra_tab_vol: document.getElementById('tab-vol')?.value || 100,
        umbra_mic_vol: document.getElementById('mic-vol')?.value || 80,
        umbra_autostop: document.getElementById('autostop')?.value || 0
    });
}

function loadSettings() {
    chrome.storage.local.get([
        'umbra_folder','umbra_prefix','umbra_quality',
        'umbra_mic','umbra_tab_vol','umbra_mic_vol','umbra_autostop'
    ], (r) => {
        if (r.umbra_folder) document.getElementById('folder-input').value = r.umbra_folder;
        if (r.umbra_prefix) document.getElementById('prefix-input').value = r.umbra_prefix;
        if (r.umbra_quality) {
            selectedQuality = r.umbra_quality;
            document.querySelectorAll('.q-btn').forEach(b => b.classList.toggle('active', b.dataset.q === selectedQuality));
        }
        const mic = document.getElementById('mic-toggle');
        if (mic && r.umbra_mic) {
            mic.checked = true;
            const row = document.getElementById('mic-vol-row');
            row.style.opacity = '1'; row.style.pointerEvents = 'all';
        }
        if (r.umbra_tab_vol) { document.getElementById('tab-vol').value = r.umbra_tab_vol; document.getElementById('tab-vol-val').textContent = r.umbra_tab_vol + '%'; }
        if (r.umbra_mic_vol) { document.getElementById('mic-vol').value = r.umbra_mic_vol; document.getElementById('mic-vol-val').textContent = r.umbra_mic_vol + '%'; }
        if (r.umbra_autostop) document.getElementById('autostop').value = r.umbra_autostop;
        updatePath();
    });
}

function updatePath() {
    chrome.storage.local.get('umbra_clip_counter', (r) => {
        const n = String((r.umbra_clip_counter || 0) + 1).padStart(3,'0');
        const date = new Date().toISOString().slice(0,10);
        const folder = getFolder();
        const prefix = getPrefix();
        document.getElementById('path-preview').textContent = folder
            ? `→ ${folder}/umbra/${prefix}_${date}_${n}.webm`
            : `→ umbra/${prefix}_${date}_${n}.webm`;
    });
}

function updateClipsCount() {
    chrome.storage.local.get('umbra_clip_counter', (r) => {
        document.getElementById('clips-count').textContent = r.umbra_clip_counter || 0;
    });
}

async function updateDisk() {
    const info = await bg({ action: 'GET_DISK_SPACE' });
    if (!info) return;
    document.getElementById('disk-val').textContent = `${info.availableMB} MB livres`;
    const pct = Math.min(100, Math.max(0, 100 - (info.availableMB / (info.quotaMB || 1000) * 100)));
    const fill = document.getElementById('disk-fill');
    fill.style.width = pct + '%';
    fill.className = 'disk-fill' + (pct > 90 ? ' danger' : pct > 70 ? ' warn' : '');
}

async function getTabInfo() {
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab?.url) {
            const host = new URL(tab.url).hostname.replace('www.','');
            document.getElementById('current-tab').textContent = host.length > 16 ? host.slice(0,14)+'…' : host;
        }
    } catch (e) { document.getElementById('current-tab').textContent = '—'; }
}

// ============================================
// HISTORY
// ============================================

async function loadHistory() {
    const history = await bg({ action: 'GET_HISTORY' });
    const list = document.getElementById('history-list');
    if (!history?.length) {
        list.innerHTML = '<div class="history-empty">Nenhum clip gravado ainda</div>';
        return;
    }
    list.innerHTML = history.map(item => {
        const dur = item.duration ? fmt(item.duration) : '—';
        const size = item.size ? (item.size > 1024*1024 ? `${(item.size/1024/1024).toFixed(1)}MB` : `${Math.round(item.size/1024)}KB`) : '—';
        const date = item.date ? new Date(item.date).toLocaleString('pt-BR', { day:'2-digit', month:'2-digit', hour:'2-digit', minute:'2-digit' }) : '—';
        const name = item.filename?.split('/').pop() || '—';
        return `<div class="history-item">
            <div class="history-name">${name}</div>
            <div class="history-meta"><span>⏱ ${dur}</span><span>📦 ${size}</span></div>
            <div class="history-date">${date}</div>
        </div>`;
    }).join('');
}

// ============================================
// INIT
// ============================================

document.getElementById('big-timer').classList.add('idle');
loadSettings();
refreshStatus();
setInterval(refreshStatus, 3000);
