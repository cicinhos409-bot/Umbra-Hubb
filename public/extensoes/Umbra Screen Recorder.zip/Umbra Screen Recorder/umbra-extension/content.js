// ============================================
// UMBRA SCREEN RECORDER - CONTENT SCRIPT v1.1.0
// Fixes: ping handler, timer via background apenas,
// debounce em settings, confirmação ao limpar histórico,
// aria-labels, hasMic no histórico, toasts de erro,
// aviso de gravação em aba diferente
// ============================================

(function () {
    if (window.__umbraInjected) return;
    window.__umbraInjected = true;

    // ============================================
    // CONFIGURAÇÕES DE LICENÇA (OBSOLETO - USANDO BACKGROUND AGORA)
    // ============================================

    let panelEl = null;
    let isRecording = false;
    let isPaused = false;
    let isPanelVisible = false;
    let selectedQuality = 'alta';
    let settingsDebounceTimer = null;

    // Mic recorder
    let micRecorder = null;
    let micChunks = [];
    let micStream = null;

    const QUALITIES = {
        baixa: { videoBitsPerSecond: 1500000 },
        media: { videoBitsPerSecond: 3000000 },
        alta:  { videoBitsPerSecond: 5000000 },
        ultra: { videoBitsPerSecond: 8000000 }
    };

    // ============================================
    // MIC
    // ============================================

    async function startMicRecording() {
        try {
            micStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
            micChunks = [];
            const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
                ? 'audio/webm;codecs=opus' : 'audio/webm';
            micRecorder = new MediaRecorder(micStream, { mimeType, audioBitsPerSecond: 128000 });
            micRecorder.ondataavailable = (e) => { if (e.data?.size > 0) micChunks.push(e.data); };
            micRecorder.start(1000);
            return true;
        } catch (e) {
            console.warn('[Umbra] Mic falhou:', e.message);
            micRecorder = null; micStream = null; micChunks = [];
            return false;
        }
    }

    function pauseMicRecording() {
        if (micRecorder?.state === 'recording') micRecorder.pause();
    }
    function resumeMicRecording() {
        if (micRecorder?.state === 'paused') micRecorder.resume();
    }

    async function stopMicRecording() {
        return new Promise((resolve) => {
            if (!micRecorder || micRecorder.state === 'inactive') { resolve(null); return; }
            micRecorder.onstop = () => {
                micStream?.getTracks().forEach(t => t.stop());
                if (micChunks.length === 0) { resolve(null); return; }
                const blob = new Blob(micChunks, { type: micRecorder.mimeType });
                const url = URL.createObjectURL(blob);
                micChunks = []; micRecorder = null; micStream = null;
                resolve({ url, size: blob.size });
            };
            if (micRecorder.state === 'paused') micRecorder.resume();
            micRecorder.stop();
        });
    }

    // ============================================
    // CRIAR PAINEL
    // ============================================

    function createPanel() {
        if (document.getElementById('umbra-root')) return;

        const root = document.createElement('div');
        root.id = 'umbra-root';
        root.setAttribute('role', 'region');
        root.setAttribute('aria-label', 'Umbra Screen Recorder');

        const overlay = document.createElement('div');
        overlay.id = 'umbra-rec-overlay';
        overlay.setAttribute('aria-hidden', 'true');

        const stopBtn = document.createElement('div');
        stopBtn.id = 'umbra-stop-btn';
        stopBtn.className = 'umbra-hidden';
        stopBtn.setAttribute('role', 'toolbar');
        stopBtn.setAttribute('aria-label', 'Controles de gravação');
        stopBtn.innerHTML = `
            <div class="umbra-stop-dot" id="umbra-stop-dot" aria-hidden="true"></div>
            <span class="umbra-stop-timer" id="umbra-stop-timer" aria-live="polite" aria-label="Tempo de gravação">00:00</span>
            <div class="umbra-stop-controls">
                <button class="umbra-stop-pause-btn" id="umbra-stop-pause-btn" aria-label="Pausar gravação">⏸ PAUSAR</button>
                <button class="umbra-stop-action" id="umbra-stop-action" aria-label="Parar gravação">■ PARAR</button>
            </div>
        `;

        const toast = document.createElement('div');
        toast.id = 'umbra-toast';
        toast.setAttribute('role', 'status');
        toast.setAttribute('aria-live', 'polite');
        toast.innerHTML = `
            <div class="umbra-toast-title" id="umbra-toast-title"></div>
            <div class="umbra-toast-sub" id="umbra-toast-sub"></div>
        `;

        const panel = document.createElement('div');
        panel.id = 'umbra-panel';
        panel.className = 'umbra-hidden';
        panel.setAttribute('role', 'dialog');
        panel.setAttribute('aria-label', 'Umbra Screen Recorder');
        panel.innerHTML = `
            <div class="umbra-header" id="umbra-drag-handle" role="banner">
                <div class="umbra-header-left">
                    <div class="umbra-logo" aria-hidden="true">
                        <svg viewBox="0 0 16 16" fill="white"><circle cx="8" cy="8" r="7"/></svg>
                    </div>
                    <span class="umbra-title">Umbra <span>REC</span></span>
                    <span class="umbra-version">v2.0.1</span>
                </div>
                <div class="umbra-header-actions">
                    <button class="umbra-btn-icon" id="umbra-minimize" aria-label="Minimizar painel">
                        <svg width="14" height="2" viewBox="0 0 14 2" fill="none" aria-hidden="true"><line x1="1" y1="1" x2="13" y2="1" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>
                    </button>
                    <button class="umbra-btn-icon close" id="umbra-close" aria-label="Fechar painel">
                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true"><path d="M1 1l10 10M11 1L1 11" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                    </button>
                </div>
            </div>

            <div class="umbra-tabs" role="tablist" aria-label="Seções do painel">
                <button class="umbra-tab active" data-tab="gravar" role="tab" aria-selected="true" aria-controls="umbra-tab-gravar">Gravar</button>
                <button class="umbra-tab" data-tab="config" role="tab" aria-selected="false" aria-controls="umbra-tab-config">Config</button>
                <button class="umbra-tab" data-tab="historico" role="tab" aria-selected="false" aria-controls="umbra-tab-historico">Histórico</button>
            </div>

            <div class="umbra-body">

                <!-- TAB GRAVAR -->
                <div class="umbra-tab-content active" id="umbra-tab-gravar" role="tabpanel">

                    <!-- Aviso: gravando em outra aba -->
                    <div class="umbra-other-tab-warn umbra-hidden" id="umbra-other-tab-warn" role="alert">
                        ⚠️ Gravando em outra aba. Os controles abaixo funcionam normalmente.
                    </div>

                    <div class="umbra-status-card" id="umbra-status-card">
                        <div class="umbra-status-row">
                            <div class="umbra-rec-dot" id="umbra-rec-dot" aria-hidden="true"></div>
                            <span class="umbra-rec-label" id="umbra-rec-label" aria-live="polite">Pronto para gravar</span>
                        </div>
                        <div class="umbra-timer idle" id="umbra-timer" aria-live="off" aria-label="Tempo decorrido">00:00</div>
                        <div class="umbra-size-info" id="umbra-size-info" aria-live="polite">—</div>
                    </div>

                    <div class="umbra-controls">
                        <button class="umbra-main-btn" id="umbra-main-btn" aria-label="Iniciar gravação">
                            <span id="umbra-btn-text">▶ Iniciar Gravação</span>
                        </button>
                        <button class="umbra-pause-btn hidden" id="umbra-pause-btn" aria-label="Pausar gravação">
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><rect x="3" y="2" width="4" height="12" rx="1"/><rect x="9" y="2" width="4" height="12" rx="1"/></svg>
                        </button>
                    </div>

                    <div class="umbra-mic-status umbra-hidden" id="umbra-mic-status" role="status">
                        <span id="umbra-mic-status-icon" aria-hidden="true">🎙</span>
                        <span id="umbra-mic-status-text">Microfone não testado</span>
                    </div>

                    <div class="umbra-disk-bar-wrap">
                        <div class="umbra-disk-row">
                            <span class="umbra-disk-label">💾 Espaço disponível</span>
                            <span class="umbra-disk-value" id="umbra-disk-value" aria-live="polite">—</span>
                        </div>
                        <div class="umbra-disk-bar" role="progressbar" aria-label="Uso de disco" aria-valuemin="0" aria-valuemax="100">
                            <div class="umbra-disk-fill" id="umbra-disk-fill" style="width:0%"></div>
                        </div>
                    </div>

                    <div class="umbra-section">
                        <div class="umbra-section-title">Arquivo de saída</div>
                        <div class="umbra-field">
                            <label class="umbra-label" for="umbra-folder">Pasta</label>
                            <input type="text" class="umbra-input" id="umbra-folder" placeholder="ex: meu_projeto" autocomplete="off">
                        </div>
                        <div class="umbra-field">
                            <label class="umbra-label" for="umbra-prefix">Prefixo</label>
                            <input type="text" class="umbra-input" id="umbra-prefix" placeholder="ex: clip" autocomplete="off">
                        </div>
                        <div class="umbra-path-preview" id="umbra-path-preview" aria-live="polite">→ umbra/clip_001.webm</div>
                    </div>

                    <div class="umbra-clips-row">
                        <span class="umbra-clips-label">Total de clips gravados</span>
                        <span class="umbra-clips-count" id="umbra-clips-count" aria-live="polite">0</span>
                    </div>
                </div>

                <!-- TAB CONFIG -->
                <div class="umbra-tab-content" id="umbra-tab-config" role="tabpanel">
                    <div class="umbra-section">
                        <div class="umbra-section-title">Qualidade de vídeo</div>
                        <div class="umbra-quality-grid" role="group" aria-label="Qualidade de vídeo">
                            <button class="umbra-quality-btn" data-quality="baixa" aria-pressed="false">Baixa<small>1.5M</small></button>
                            <button class="umbra-quality-btn" data-quality="media" aria-pressed="false">Média<small>3M</small></button>
                            <button class="umbra-quality-btn active" data-quality="alta" aria-pressed="true">Alta<small>5M</small></button>
                            <button class="umbra-quality-btn" data-quality="ultra" aria-pressed="false">Ultra<small>8M</small></button>
                        </div>
                    </div>

                    <div class="umbra-section">
                        <div class="umbra-section-title">Áudio</div>
                        <div class="umbra-toggle-row">
                            <div>
                                <div class="umbra-toggle-label">🎙 Gravar minha voz</div>
                                <div class="umbra-toggle-sub">Arquivo .webm separado, sincronizado</div>
                            </div>
                            <label class="umbra-toggle" aria-label="Ativar microfone">
                                <input type="checkbox" id="umbra-mic-toggle">
                                <span class="umbra-toggle-slider"></span>
                            </label>
                        </div>

                        <button class="umbra-test-mic-btn" id="umbra-test-mic-btn" aria-label="Testar microfone e pedir permissão">
                            🎙 Testar microfone / Pedir permissão
                        </button>

                        <div class="umbra-volume-row">
                            <span class="umbra-volume-label" id="tab-vol-label">🔊 Aba</span>
                            <input type="range" class="umbra-slider" id="umbra-tab-vol" min="0" max="100" value="100"
                                aria-label="Volume da aba" aria-valuemin="0" aria-valuemax="100">
                            <span class="umbra-slider-value" id="umbra-tab-vol-val">100%</span>
                        </div>

                        <div class="umbra-info-box">
                            ℹ️ A voz é salva em arquivo <strong>.webm separado</strong> com o mesmo timestamp. Use um editor para combinar.
                        </div>
                    </div>

                    <div class="umbra-section">
                        <div class="umbra-section-title">Auto-parar</div>
                        <div class="umbra-autostop-row">
                            <input type="number" class="umbra-autostop-input" id="umbra-autostop" min="0" max="480" value="0"
                                aria-label="Minutos para parar automaticamente">
                            <span class="umbra-autostop-unit">minutos (0 = desativado)</span>
                        </div>
                    </div>

                    <div class="umbra-section">
                        <div class="umbra-section-title">Atalhos</div>
                        <div class="umbra-shortcuts" role="list">
                            <div class="umbra-shortcut-row" role="listitem">
                                <span class="umbra-shortcut-desc">Gravar / Parar</span>
                                <div class="umbra-shortcut-keys" aria-label="Alt mais R">
                                    <kbd class="umbra-kbd">Alt</kbd><kbd class="umbra-kbd">R</kbd>
                                </div>
                            </div>
                            <div class="umbra-shortcut-row" role="listitem">
                                <span class="umbra-shortcut-desc">Pausar / Retomar</span>
                                <div class="umbra-shortcut-keys" aria-label="Alt mais P">
                                    <kbd class="umbra-kbd">Alt</kbd><kbd class="umbra-kbd">P</kbd>
                                </div>
                            </div>
                            <div class="umbra-shortcut-row" role="listitem">
                                <span class="umbra-shortcut-desc">Painel</span>
                                <div class="umbra-shortcut-keys" aria-label="Alt mais U">
                                    <kbd class="umbra-kbd">Alt</kbd><kbd class="umbra-kbd">U</kbd>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="umbra-section">
                        <div class="umbra-section-title">🔒 Gerenciar Licença</div>
                        <div class="umbra-toggle-row">
                            <div>
                                <div class="umbra-toggle-label" id="umbra-license-status">✓ Ativa e Válida</div>
                                <div class="umbra-toggle-sub" id="umbra-license-masked">UMBRA-••••-••••</div>
                            </div>
                            <button class="umbra-clear-history-btn" id="umbra-btn-logout" style="width:auto; padding:6px 12px; margin:0;">
                                Remover
                            </button>
                        </div>
                    </div>
                </div>

                <!-- TAB HISTÓRICO -->
                <div class="umbra-tab-content" id="umbra-tab-historico" role="tabpanel">
                    <div class="umbra-history-list" id="umbra-history-list" role="list">
                        <div class="umbra-history-empty">Nenhum clip gravado ainda</div>
                    </div>
                    <button class="umbra-clear-history-btn" id="umbra-clear-history" aria-label="Limpar todo o histórico de clips">
                        Limpar Histórico
                    </button>
                </div>

            </div>

            <div class="umbra-resizer" id="umbra-resizer" role="separator" aria-label="Redimensionar painel">
                <svg viewBox="0 0 10 10" fill="none" aria-hidden="true"><path d="M2 8l6-6M5 8l3-3M8 8v-1" stroke="rgba(255,255,255,0.5)" stroke-width="1.2" stroke-linecap="round"/></svg>
            </div>
        `;

        root.appendChild(overlay);
        root.appendChild(stopBtn);
        root.appendChild(toast);
        root.appendChild(panel);
        document.body.appendChild(root);
        panelEl = panel;

        bindEvents();
        loadSettings();
        updateClipsCount();
        checkRecordingStatus();
        loadDiskSpace();
    }

    // ============================================
    // TESTAR MIC
    // ============================================

    async function requestMicPermission() {
        const btn = document.getElementById('umbra-test-mic-btn');
        const statusEl = document.getElementById('umbra-mic-status');
        const statusIcon = document.getElementById('umbra-mic-status-icon');
        const statusText = document.getElementById('umbra-mic-status-text');
        try {
            if (btn) { btn.textContent = '⏳ Pedindo permissão...'; btn.disabled = true; }
            statusEl?.classList.remove('umbra-hidden');
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
            stream.getTracks().forEach(t => t.stop());
            if (statusIcon) statusIcon.textContent = '✅';
            if (statusText) statusText.textContent = 'Microfone autorizado e pronto';
            if (btn) {
                btn.textContent = '✅ Microfone autorizado';
                btn.style.borderColor = 'rgba(52,211,153,0.4)';
                btn.style.color = '#34D399';
                btn.disabled = false;
            }
            showToast('✅ Microfone autorizado', 'Sua voz será gravada em arquivo separado', 'success');
            return true;
        } catch (e) {
            const msg = e.name === 'NotAllowedError' ? 'Permissão negada'
                : e.name === 'NotFoundError' ? 'Nenhum microfone encontrado' : e.message;
            if (statusIcon) statusIcon.textContent = '❌';
            if (statusText) statusText.textContent = msg;
            if (btn) { btn.textContent = '🎙 Testar microfone / Pedir permissão'; btn.disabled = false; }
            showToast('❌ Microfone indisponível', msg, 'error');
            return false;
        }
    }

    // ============================================
    // BIND EVENTS
    // ============================================

    function bindEvents() {
        document.getElementById('umbra-close').addEventListener('click', hidePanel);

        let minimized = false;
        document.getElementById('umbra-minimize').addEventListener('click', () => {
            minimized = !minimized;
            panelEl.classList.toggle('umbra-minimized', minimized);
            document.getElementById('umbra-minimize').setAttribute('aria-label', minimized ? 'Expandir painel' : 'Minimizar painel');
        });

        document.querySelectorAll('.umbra-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                document.querySelectorAll('.umbra-tab').forEach(t => {
                    t.classList.remove('active');
                    t.setAttribute('aria-selected', 'false');
                });
                document.querySelectorAll('.umbra-tab-content').forEach(c => c.classList.remove('active'));
                tab.classList.add('active');
                tab.setAttribute('aria-selected', 'true');
                document.getElementById(`umbra-tab-${tab.dataset.tab}`)?.classList.add('active');
                if (tab.dataset.tab === 'historico') loadHistory();
            });
        });

        document.getElementById('umbra-main-btn').addEventListener('click', async () => {
            if (isRecording) {
                chrome.runtime.sendMessage({ action: 'STOP_RECORDING_REQUEST' });
            } else {
                const opts = buildOptions();
                chrome.runtime.sendMessage({ action: 'START_RECORDING_REQUEST', options: opts });
            }
        });

        document.getElementById('umbra-pause-btn').addEventListener('click', () => {
            chrome.runtime.sendMessage({ action: 'TOGGLE_PAUSE_REQUEST' });
        });

        document.getElementById('umbra-stop-action').addEventListener('click', () => {
            chrome.runtime.sendMessage({ action: 'STOP_RECORDING_REQUEST' });
        });

        document.getElementById('umbra-stop-pause-btn').addEventListener('click', () => {
            chrome.runtime.sendMessage({ action: 'TOGGLE_PAUSE_REQUEST' });
        });

        document.getElementById('umbra-test-mic-btn').addEventListener('click', requestMicPermission);

        document.getElementById('umbra-mic-toggle').addEventListener('change', (e) => {
            const statusEl = document.getElementById('umbra-mic-status');
            if (e.target.checked) statusEl?.classList.remove('umbra-hidden');
            scheduleSaveSettings();
        });

        // Debounce em campos de texto
        document.getElementById('umbra-folder').addEventListener('input', () => {
            updatePathPreview();
            scheduleSaveSettings();
        });
        document.getElementById('umbra-prefix').addEventListener('input', () => {
            updatePathPreview();
            scheduleSaveSettings();
        });

        document.querySelectorAll('.umbra-quality-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.umbra-quality-btn').forEach(b => {
                    b.classList.remove('active');
                    b.setAttribute('aria-pressed', 'false');
                });
                btn.classList.add('active');
                btn.setAttribute('aria-pressed', 'true');
                selectedQuality = btn.dataset.quality;
                scheduleSaveSettings();
            });
        });

        document.getElementById('umbra-tab-vol').addEventListener('input', (e) => {
            document.getElementById('umbra-tab-vol-val').textContent = e.target.value + '%';
            document.getElementById('umbra-tab-vol').setAttribute('aria-valuenow', e.target.value);
            scheduleSaveSettings();
        });

        document.getElementById('umbra-autostop').addEventListener('change', scheduleSaveSettings);

        document.getElementById('umbra-btn-logout')?.addEventListener('click', () => {
            showConfirm(
                'Remover Licença?',
                'Isso desativará a extensão neste dispositivo. Você precisará da chave para reativar.',
                () => {
                    chrome.runtime.sendMessage({ action: 'LOGOUT' }, () => {
                        hidePanel();
                        showToast('🔓 Licença removida', 'Extensão desativada', 'info');
                    });
                }
            );
        });

        // Limpar histórico com confirmação
        document.getElementById('umbra-clear-history').addEventListener('click', () => {
            showConfirm(
                'Limpar histórico?',
                'Isso removerá todos os registros de clips. Os arquivos não serão apagados.',
                async () => {
                    await chrome.runtime.sendMessage({ action: 'CLEAR_HISTORY' });
                    loadHistory();
                    showToast('🗑️ Histórico limpo', '', 'info');
                }
            );
        });

        makeDraggable(panelEl, document.getElementById('umbra-drag-handle'));
        makeResizable(panelEl, document.getElementById('umbra-resizer'));
        makeDraggable(document.getElementById('umbra-stop-btn'), document.getElementById('umbra-stop-btn'));
    }

    function buildOptions() {
        const q = QUALITIES[selectedQuality] || QUALITIES.alta;
        return {
            ...q,
            includeMic: document.getElementById('umbra-mic-toggle')?.checked || false,
            tabVolume: parseInt(document.getElementById('umbra-tab-vol')?.value || 100) / 100,
            autoStopMinutes: parseInt(document.getElementById('umbra-autostop')?.value || 0)
        };
    }

    // ============================================
    // DEBOUNCE DE SETTINGS
    // ============================================

    function scheduleSaveSettings() {
        clearTimeout(settingsDebounceTimer);
        settingsDebounceTimer = setTimeout(saveSettings, 350);
    }

    // ============================================
    // CONFIRM DIALOG
    // ============================================

    function showConfirm(title, message, onConfirm) {
        const existing = document.getElementById('umbra-confirm-overlay');
        if (existing) existing.remove();

        const overlay = document.createElement('div');
        overlay.id = 'umbra-confirm-overlay';
        overlay.style.cssText = `
            position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:2147483648;
            display:flex;align-items:center;justify-content:center;pointer-events:all;
        `;
        overlay.innerHTML = `
            <div style="background:#0a0a0f;border:1px solid rgba(255,45,85,0.35);border-radius:14px;
                padding:24px 28px;max-width:320px;width:90%;display:flex;flex-direction:column;gap:14px;
                box-shadow:0 24px 64px rgba(0,0,0,0.9);font-family:Syne,sans-serif;">
                <div style="font-size:15px;font-weight:700;color:#fff;letter-spacing:0.03em;">${title}</div>
                <div style="font-size:12px;color:rgba(255,255,255,0.45);line-height:1.6;">${message}</div>
                <div style="display:flex;gap:8px;justify-content:flex-end;">
                    <button id="umbra-confirm-cancel" style="padding:9px 18px;background:rgba(255,255,255,0.05);
                        border:1px solid rgba(255,255,255,0.1);border-radius:8px;color:rgba(255,255,255,0.5);
                        font-family:Syne,sans-serif;font-size:12px;font-weight:600;cursor:pointer;" aria-label="Cancelar">
                        Cancelar
                    </button>
                    <button id="umbra-confirm-ok" style="padding:9px 18px;background:linear-gradient(135deg,#FF2D55,#D4002B);
                        border:none;border-radius:8px;color:#fff;font-family:Syne,sans-serif;font-size:12px;
                        font-weight:700;cursor:pointer;" aria-label="Confirmar">
                        Confirmar
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(overlay);

        overlay.querySelector('#umbra-confirm-cancel').addEventListener('click', () => overlay.remove());
        overlay.querySelector('#umbra-confirm-ok').addEventListener('click', () => { overlay.remove(); onConfirm(); });
        overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
    }

    // ============================================
    // DRAG / RESIZE
    // ============================================

    function makeDraggable(el, handle) {
        let isDragging = false, startX, startY, startL, startT;
        handle.addEventListener('mousedown', (e) => {
            if (e.target.closest('.umbra-btn-icon, .umbra-stop-action, .umbra-stop-pause-btn')) return;
            isDragging = true;
            startX = e.clientX; startY = e.clientY;
            const r = el.getBoundingClientRect();
            startL = r.left; startT = r.top;
            e.preventDefault();
        });
        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            const newLeft = Math.max(0, Math.min(window.innerWidth - el.offsetWidth, startL + e.clientX - startX));
            const newTop = Math.max(0, Math.min(window.innerHeight - el.offsetHeight, startT + e.clientY - startY));
            el.style.left = newLeft + 'px';
            el.style.top = newTop + 'px';
            el.style.right = 'auto'; el.style.bottom = 'auto';
        });
        document.addEventListener('mouseup', () => {
            if (isDragging) { isDragging = false; savePanelPosition(); }
        });
    }

    function makeResizable(el, resizer) {
        let isResizing = false, startX, startY, startW, startH;
        resizer.addEventListener('mousedown', (e) => {
            isResizing = true; startX = e.clientX; startY = e.clientY;
            startW = el.offsetWidth; startH = el.offsetHeight;
            e.preventDefault(); e.stopPropagation();
        });
        document.addEventListener('mousemove', (e) => {
            if (!isResizing) return;
            el.style.width = Math.max(340, startW + e.clientX - startX) + 'px';
            el.style.height = Math.max(46, startH + e.clientY - startY) + 'px';
        });
        document.addEventListener('mouseup', () => { isResizing = false; });
    }

    // ============================================
    // PANEL
    // ============================================

    function showPanel() {
        if (!panelEl) createPanel();
        panelEl.classList.remove('umbra-hidden');
        isPanelVisible = true;
        loadSavedPanelPosition();
        loadDiskSpace();
    }

    function hidePanel() {
        panelEl?.classList.add('umbra-hidden');
        isPanelVisible = false;
    }

    // ============================================
    // LICENÇA OVERLAY
    // ============================================

    async function checkLicenseAndTogglePanel() {
        chrome.runtime.sendMessage({ action: 'GET_STATUS' }, (res) => {
            if (res && res.valido) {
                togglePanel();
            } else {
                createLicenseOverlay();
            }
        });
    }

    function createLicenseOverlay() {
        if (document.getElementById('umbra-license-overlay')) return;

        const overlay = document.createElement('div');
        overlay.id = 'umbra-license-overlay';
        overlay.innerHTML = `
            <div class="umbra-license-modal">
                <div class="umbra-header" style="width:100%; position:absolute; top:0; left:0; border-radius:24px 24px 0 0; background: rgba(255, 255, 255, 0.02);">
                    <div class="umbra-header-left">
                        <div class="umbra-logo"><svg viewBox="0 0 16 16" fill="white"><circle cx="8" cy="8" r="7"/></svg></div>
                        <span class="umbra-title">Umbra <span>REC</span></span>
                    </div>
                    <div class="umbra-header-actions">
                        <button class="umbra-btn-icon close" id="umbra-license-close" aria-label="Fechar">
                            <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M1 1l10 10M11 1L1 11" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
                        </button>
                    </div>
                </div>
                <div class="umbra-license-logo">
                    <svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="11" fill="white" opacity="0.95"/><circle cx="12" cy="12" r="6" fill="#FF2D55"/></svg>
                </div>
                <div>
                    <div class="umbra-license-badge">STATUS: ACESSO RESTRITO</div>
                    <div class="umbra-license-title" style="margin-top:15px;">Digite sua<br/><span>chave de licença</span></div>
                </div>
                <div class="umbra-license-sub">Apenas usuários autorizados podem acessar esta ferramenta. Ative com sua chave PRO.</div>
                <div class="umbra-license-input-wrap">
                    <span class="umbra-license-input-icon">🔑</span>
                    <input type="text" class="umbra-license-input" id="umbra-license-input" placeholder="PRO" maxlength="30">
                </div>
                <button class="umbra-license-btn" id="umbra-license-btn">ATIVAR EXTENSÃO</button>
                <div class="umbra-license-error" id="umbra-license-error"></div>
            </div>
        `;

        document.body.appendChild(overlay);

        const input = overlay.querySelector('#umbra-license-input');
        const btn = overlay.querySelector('#umbra-license-btn');
        const error = overlay.querySelector('#umbra-license-error');
        const close = overlay.querySelector('#umbra-license-close');

        close.addEventListener('click', () => overlay.remove());

        input.addEventListener('input', (e) => {
            // Nova formatação: apenas maiúsculas, sem split automático por 4
            let val = e.target.value.toUpperCase().replace(/\s/g, '');
            e.target.value = val;
            error.textContent = "";
        });

        btn.addEventListener('click', async () => {
            const chave = input.value.trim().toUpperCase();
            if (!chave) { error.textContent = "⚠ Digite uma chave."; return; }

            btn.textContent = "VERIFICANDO...";
            btn.disabled = true;
            error.textContent = "";

            chrome.runtime.sendMessage({ action: 'ACTIVATE', chave }, (res) => {
                btn.textContent = "ATIVAR EXTENSÃO";
                btn.disabled = false;

                if (res && res.valido) {
                    overlay.remove();
                    // Pequeno delay para garantir que o overlay sumiu antes de tentar focar/posicionar o painel
                    setTimeout(() => {
                        showPanel();
                        showToast('✅ Ativado!', 'Licença PRO ativada com sucesso.', 'success');
                    }, 100);
                } else {
                    error.textContent = `✗ ${res.motivo || "Chave inválida."}`;
                    const modal = overlay.querySelector('.umbra-license-modal');
                    modal?.classList.add('umbra-shake');
                    setTimeout(() => modal?.classList.remove('umbra-shake'), 500);
                }
            });
        });

        input.addEventListener('keydown', e => {
            if (e.key === "Enter") btn.click();
        });
    }

    function togglePanel() {
        if (!panelEl) createPanel();
        isPanelVisible ? hidePanel() : showPanel();
    }

    // ============================================
    // RECORDING UI — timer APENAS via background
    // ============================================

    function setRecordingUI(recording, paused = false, recordingInOtherTab = false) {
        isRecording = recording;
        isPaused = paused;

        const dot = document.getElementById('umbra-rec-dot');
        const label = document.getElementById('umbra-rec-label');
        const timer = document.getElementById('umbra-timer');
        const btn = document.getElementById('umbra-main-btn');
        const btnText = document.getElementById('umbra-btn-text');
        const pauseBtn = document.getElementById('umbra-pause-btn');
        const overlay = document.getElementById('umbra-rec-overlay');
        const statusCard = document.getElementById('umbra-status-card');
        const stopPauseBtn = document.getElementById('umbra-stop-pause-btn');
        const stopDot = document.getElementById('umbra-stop-dot');
        const warnEl = document.getElementById('umbra-other-tab-warn');
        const mainBtn = document.getElementById('umbra-main-btn');

        // Aviso de outra aba
        if (warnEl) warnEl.classList.toggle('umbra-hidden', !recordingInOtherTab);

        if (recording && !paused) {
            dot?.classList.add('recording'); dot?.classList.remove('paused');
            if (label) { label.textContent = '● Gravando'; label.className = 'umbra-rec-label recording'; }
            timer?.classList.remove('idle');
            btn?.classList.add('recording');
            if (mainBtn) mainBtn.setAttribute('aria-label', 'Parar gravação');
            if (btnText) btnText.textContent = '■ Parar Gravação';
            pauseBtn?.classList.remove('hidden', 'resumed');
            if (pauseBtn) {
                pauseBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><rect x="3" y="2" width="4" height="12" rx="1"/><rect x="9" y="2" width="4" height="12" rx="1"/></svg>';
                pauseBtn.setAttribute('aria-label', 'Pausar gravação');
            }
            overlay?.classList.add('active'); overlay?.classList.remove('paused');
            statusCard?.classList.remove('paused');
            panelEl?.classList.add('umbra-recording-active');
            document.getElementById('umbra-stop-btn')?.classList.remove('umbra-hidden', 'paused');
            if (stopPauseBtn) { stopPauseBtn.textContent = '⏸ PAUSAR'; stopPauseBtn.className = 'umbra-stop-pause-btn'; stopPauseBtn.setAttribute('aria-label', 'Pausar gravação'); }
            stopDot?.classList.remove('paused');

        } else if (recording && paused) {
            dot?.classList.remove('recording'); dot?.classList.add('paused');
            if (label) { label.textContent = '⏸ Pausado'; label.className = 'umbra-rec-label paused'; }
            overlay?.classList.add('paused'); overlay?.classList.remove('active');
            statusCard?.classList.add('paused');
            panelEl?.classList.remove('umbra-recording-active');
            if (mainBtn) mainBtn.setAttribute('aria-label', 'Parar gravação');
            if (btnText) btnText.textContent = '■ Parar Gravação';
            pauseBtn?.classList.remove('hidden'); pauseBtn?.classList.add('resumed');
            if (pauseBtn) {
                pauseBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M4 2l10 6-10 6z"/></svg>';
                pauseBtn.setAttribute('aria-label', 'Retomar gravação');
            }
            document.getElementById('umbra-stop-btn')?.classList.add('paused');
            if (stopPauseBtn) { stopPauseBtn.textContent = '▶ RETOMAR'; stopPauseBtn.className = 'umbra-stop-pause-btn resumed'; stopPauseBtn.setAttribute('aria-label', 'Retomar gravação'); }
            stopDot?.classList.add('paused');

        } else {
            dot?.classList.remove('recording', 'paused');
            if (label) { label.textContent = 'Pronto para gravar'; label.className = 'umbra-rec-label'; }
            if (timer) { timer.textContent = '00:00'; timer.classList.add('idle'); }
            btn?.classList.remove('recording');
            if (mainBtn) mainBtn.setAttribute('aria-label', 'Iniciar gravação');
            if (btnText) btnText.textContent = '▶ Iniciar Gravação';
            pauseBtn?.classList.add('hidden');
            overlay?.classList.remove('active', 'paused');
            statusCard?.classList.remove('paused');
            panelEl?.classList.remove('umbra-recording-active');
            document.getElementById('umbra-stop-btn')?.classList.add('umbra-hidden');
            const si = document.getElementById('umbra-size-info');
            if (si) si.textContent = '—';
        }
    }

    // Timer só atualizado por mensagem do background — sem contador local
    function updateTimer(elapsed) {
        const m = Math.floor(elapsed / 60);
        const s = elapsed % 60;
        const fmt = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
        const timer = document.getElementById('umbra-timer');
        if (timer) timer.textContent = fmt;
        const stopTimer = document.getElementById('umbra-stop-timer');
        if (stopTimer) stopTimer.textContent = fmt;
    }

    function updateSize(bytes) {
        const el = document.getElementById('umbra-size-info');
        if (!el || !bytes) return;
        el.textContent = bytes < 1024 * 1024
            ? `${Math.round(bytes / 1024)} KB gravados`
            : `${(bytes / 1024 / 1024).toFixed(1)} MB gravados`;
    }

    // ============================================
    // TOAST
    // ============================================

    let toastTimeout = null;
    function showToast(title, sub, type = 'info') {
        const toast = document.getElementById('umbra-toast');
        if (!toast) return;
        document.getElementById('umbra-toast-title').textContent = title;
        document.getElementById('umbra-toast-sub').textContent = sub || '';
        toast.className = `show ${type}`;
        clearTimeout(toastTimeout);
        toastTimeout = setTimeout(() => toast.classList.remove('show'), 4500);
    }

    // ============================================
    // SETTINGS
    // ============================================

    function getFolder() {
        return (document.getElementById('umbra-folder')?.value || '')
            .trim().replace(/[<>:"/\\|?*]/g, '').replace(/\s+/g, '_');
    }
    function getPrefix() {
        return (document.getElementById('umbra-prefix')?.value || 'clip')
            .trim().replace(/[<>:"/\\|?*]/g, '').replace(/\s+/g, '_') || 'clip';
    }

    function saveSettings() {
        chrome.storage.local.set({
            umbra_folder: getFolder(),
            umbra_prefix: getPrefix(),
            umbra_quality: selectedQuality,
            umbra_mic: document.getElementById('umbra-mic-toggle')?.checked || false,
            umbra_tab_vol: document.getElementById('umbra-tab-vol')?.value || 100,
            umbra_autostop: document.getElementById('umbra-autostop')?.value || 0
        });
    }

    function loadSettings() {
        chrome.storage.local.get([
            'umbra_folder', 'umbra_prefix', 'umbra_quality',
            'umbra_mic', 'umbra_tab_vol', 'umbra_autostop'
        ], (r) => {
            if (r.umbra_folder) document.getElementById('umbra-folder').value = r.umbra_folder;
            if (r.umbra_prefix) document.getElementById('umbra-prefix').value = r.umbra_prefix;
            if (r.umbra_quality) {
                selectedQuality = r.umbra_quality;
                document.querySelectorAll('.umbra-quality-btn').forEach(b => {
                    const active = b.dataset.quality === selectedQuality;
                    b.classList.toggle('active', active);
                    b.setAttribute('aria-pressed', String(active));
                });
            }
            const micToggle = document.getElementById('umbra-mic-toggle');
            if (micToggle && r.umbra_mic) {
                micToggle.checked = true;
                document.getElementById('umbra-mic-status')?.classList.remove('umbra-hidden');
            }
            const tabVol = document.getElementById('umbra-tab-vol');
            if (tabVol && r.umbra_tab_vol !== undefined) {
                tabVol.value = r.umbra_tab_vol;
                tabVol.setAttribute('aria-valuenow', r.umbra_tab_vol);
                document.getElementById('umbra-tab-vol-val').textContent = r.umbra_tab_vol + '%';
            }
            if (r.umbra_autostop) document.getElementById('umbra-autostop').value = r.umbra_autostop;
            updatePathPreview();
        });

        chrome.storage.local.get("licenca_ativa", (r) => {
            const maskedEl = document.getElementById('umbra-license-masked');
            if (maskedEl && r.licenca_ativa) {
                const key = r.licenca_ativa;
                // Formato: UMBRA-XXXX-••••
                const parts = key.split('-');
                if (parts.length >= 2) {
                    maskedEl.textContent = `${parts[0]}-${parts[1]}-••••••••`;
                } else {
                    maskedEl.textContent = key.slice(0, 5) + "-••••••••";
                }
            }
        });
    }

    function updatePathPreview() {
        const el = document.getElementById('umbra-path-preview');
        if (!el) return;
        chrome.storage.local.get('umbra_clip_counter', (r) => {
            const n = String((r.umbra_clip_counter || 0) + 1).padStart(3, '0');
            const date = new Date().toISOString().slice(0, 10);
            const folder = getFolder();
            const prefix = getPrefix();
            el.textContent = folder
                ? `→ ${folder}/umbra/${prefix}_${date}_${n}.webm`
                : `→ umbra/${prefix}_${date}_${n}.webm`;
        });
    }

    function updateClipsCount() {
        chrome.storage.local.get('umbra_clip_counter', (r) => {
            const el = document.getElementById('umbra-clips-count');
            if (el) el.textContent = r.umbra_clip_counter || 0;
        });
    }

    function savePanelPosition() {
        if (!panelEl) return;
        const r = panelEl.getBoundingClientRect();
        chrome.storage.local.set({ umbra_panel_top: r.top, umbra_panel_left: r.left });
    }

    function loadSavedPanelPosition() {
        chrome.storage.local.get(['umbra_panel_top', 'umbra_panel_left'], (r) => {
            if (!panelEl || r.umbra_panel_top === undefined) return;
            panelEl.style.top = r.umbra_panel_top + 'px';
            panelEl.style.left = r.umbra_panel_left + 'px';
            panelEl.style.right = 'auto';
        });
    }

    function loadDiskSpace() {
        chrome.runtime.sendMessage({ action: 'GET_DISK_SPACE' }, (info) => {
            if (!info) return;
            const valEl = document.getElementById('umbra-disk-value');
            const fillEl = document.getElementById('umbra-disk-fill');
            const barEl = fillEl?.parentElement;
            if (valEl) valEl.textContent = `${info.availableMB} MB livres`;
            if (fillEl) {
                const pct = Math.min(100, 100 - (info.availableMB / (info.quotaMB || 1000) * 100));
                fillEl.style.width = pct + '%';
                fillEl.className = 'umbra-disk-fill' + (pct > 90 ? ' danger' : pct > 70 ? ' warn' : '');
                if (barEl) barEl.setAttribute('aria-valuenow', Math.round(pct));
            }
        });
    }

    function loadHistory() {
        chrome.runtime.sendMessage({ action: 'GET_HISTORY' }, (history) => {
            const list = document.getElementById('umbra-history-list');
            if (!list) return;
            if (!history?.length) {
                list.innerHTML = '<div class="umbra-history-empty">Nenhum clip gravado ainda</div>';
                return;
            }
            list.innerHTML = history.map(item => {
                const dur = item.duration
                    ? `${Math.floor(item.duration / 60)}:${String(item.duration % 60).padStart(2, '0')}` : '—';
                const size = item.size
                    ? (item.size > 1024 * 1024
                        ? `${(item.size / 1024 / 1024).toFixed(1)}MB`
                        : `${Math.round(item.size / 1024)}KB`) : '—';
                const date = item.date
                    ? new Date(item.date).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—';
                const name = item.filename?.split('/').pop() || '—';
                const micBadge = item.hasMic ? '<span class="umbra-history-mic" title="Inclui arquivo de voz">🎙</span>' : '';
                const shortBadge = item.tooShort ? '<span class="umbra-history-short" title="Gravação muito curta">⚠️</span>' : '';
                return `<div class="umbra-history-item" role="listitem">
                    <div class="umbra-history-name-row">
                        <div class="umbra-history-name" title="${item.filename || ''}">${name}</div>
                        <div class="umbra-history-badges">${micBadge}${shortBadge}</div>
                    </div>
                    <div class="umbra-history-meta"><span>⏱ ${dur}</span><span>📦 ${size}</span></div>
                    <div class="umbra-history-date">${date}</div>
                </div>`;
            }).join('');
        });
    }

    function checkRecordingStatus() {
        chrome.runtime.sendMessage({ action: 'GET_RECORDING_STATUS' }, (r) => {
            if (!r) return;
            if (r.isRecording) {
                // Detectar se está gravando outra aba (não podemos saber o tabId aqui,
                // mas o background envia UMBRA_TIMER_UPDATE apenas para a aba certa)
                setRecordingUI(true, r.isPaused || false);
                if (r.elapsed > 0) updateTimer(r.elapsed);
            }
        });
    }

    // ============================================
    // MESSAGES DO BACKGROUND
    // ============================================

    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        switch (message.action) {

            // Ping de verificação de saúde do content script
            case 'UMBRA_PING':
                sendResponse({ alive: true });
                break;

            case 'UMBRA_TOGGLE_PANEL':
                checkLicenseAndTogglePanel();
                sendResponse({ success: true });
                break;

            case 'UMBRA_RECORDING_STARTED':
                setRecordingUI(true, false);
                if (message.includeMic) {
                    startMicRecording().then(ok => {
                        const statusIcon = document.getElementById('umbra-mic-status-icon');
                        const statusText = document.getElementById('umbra-mic-status-text');
                        document.getElementById('umbra-mic-status')?.classList.remove('umbra-hidden');
                        if (ok) {
                            if (statusIcon) statusIcon.textContent = '🔴';
                            if (statusText) statusText.textContent = 'Gravando voz...';
                        } else {
                            if (statusIcon) statusIcon.textContent = '❌';
                            if (statusText) statusText.textContent = 'Mic falhou — sem voz';
                            showToast('⚠️ Microfone falhou', 'Gravando só o áudio da aba', 'error');
                        }
                    });
                }
                sendResponse({ success: true });
                break;

            case 'UMBRA_RECORDING_PAUSED':
                setRecordingUI(true, true);
                pauseMicRecording();
                showToast('⏸ Pausado', 'Alt+P para retomar', 'paused');
                sendResponse({ success: true });
                break;

            case 'UMBRA_RECORDING_RESUMED':
                setRecordingUI(true, false);
                resumeMicRecording();
                showToast('▶ Retomado', '', 'info');
                sendResponse({ success: true });
                break;

            case 'UMBRA_STOP_MIC_AND_REPORT':
                stopMicRecording().then(result => { sendResponse({ micResult: result }); });
                return true;

            case 'UMBRA_RECORDING_STOPPED': {
                setRecordingUI(false);
                updateClipsCount();
                updatePathPreview();
                const statusIcon = document.getElementById('umbra-mic-status-icon');
                const statusText = document.getElementById('umbra-mic-status-text');
                if (statusIcon) statusIcon.textContent = '✅';
                if (statusText) statusText.textContent = 'Mic autorizado e pronto';
                const dur = message.duration
                    ? `${Math.floor(message.duration / 60)}:${String(message.duration % 60).padStart(2, '0')}` : '';
                const micInfo = message.hasMic ? ' + voz 🎙' : '';
                const shortWarn = message.tooShort ? ' ⚠️ Clip muito curto' : '';
                showToast(
                    message.tooShort ? '⚠️ Clip salvo (muito curto)' : '✅ Clip salvo!',
                    (message.filename?.split('/').pop() || '') + (dur ? ` · ${dur}` : '') + micInfo + shortWarn,
                    message.tooShort ? 'error' : 'success'
                );
                if (!isPanelVisible) showPanel();
                loadHistory();
                sendResponse({ success: true });
                break;
            }

            case 'UMBRA_RECORDING_ERROR':
                setRecordingUI(false);
                stopMicRecording();
                showToast('❌ Erro ao gravar', message.error || 'Erro desconhecido', 'error');
                sendResponse({ success: true });
                break;

            // Timer SOMENTE via background — sem contador local
            case 'UMBRA_TIMER_UPDATE':
                updateTimer(message.elapsed);
                sendResponse({ success: true });
                break;

            case 'UMBRA_SIZE_UPDATE':
                updateSize(message.totalBytes);
                sendResponse({ success: true });
                break;

            default:
                sendResponse({});
        }
        return true;
    });

    // ============================================
    // INIT
    // ============================================

    createPanel();

})();
