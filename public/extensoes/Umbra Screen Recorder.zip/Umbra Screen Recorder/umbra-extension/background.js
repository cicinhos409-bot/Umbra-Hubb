// ============================================
// UMBRA SCREEN RECORDER - BACKGROUND v2.0.1
// Melhorias: guard de content script, timer unificado,
// debounce, validação de duração mínima, revogação segura
// ============================================

let isRecording = false;
let isPaused = false;
let recordingTabId = null;
let recordingStartTime = null;
let pausedAt = null;
let totalPausedMs = 0;
let timerInterval = null;
let autoStopTimeout = null;
let totalRecordedBytes = 0;
let recordingOptions = {};
let pendingFilename = null; // gerado antes de gravar, salvo após

// ============================================
// CONFIGURAÇÕES UMBRA SDK v2.0
// ============================================
const API_URL = "https://cvrdcupvqvkpwllwlkfw.functions.supabase.co/validar-licenca";
const SLUG = "umbrahub-all";
const VERSION = "2.0.1";

const MIN_RECORDING_SECONDS = 2;

// ============================================
// BADGE
// ============================================

function updateBadge() {
    if (isPaused) {
        chrome.action.setBadgeText({ text: '⏸' });
        chrome.action.setBadgeBackgroundColor({ color: '#F59E0B' });
    } else if (isRecording) {
        chrome.action.setBadgeText({ text: 'REC' });
        chrome.action.setBadgeBackgroundColor({ color: '#FF2D2D' });
    } else {
        chrome.action.setBadgeText({ text: '' });
    }
}

// ============================================
// OFFSCREEN
// ============================================

async function ensureOffscreen() {
    const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    if (contexts.length === 0) {
        await chrome.offscreen.createDocument({
            url: 'offscreen.html',
            reasons: ['USER_MEDIA'],
            justification: 'Tab capture recording'
        });
        await new Promise(r => setTimeout(r, 200));
    }
}

async function closeOffscreen() {
    try {
        const contexts = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
        if (contexts.length > 0) await chrome.offscreen.closeDocument();
    } catch (e) {}
}

// ============================================
// GUARD: verifica se content script está ativo
// ============================================

async function isContentScriptReady(tabId) {
    try {
        await chrome.tabs.sendMessage(tabId, { action: 'UMBRA_PING' });
        return true;
    } catch (e) {
        // Tenta injetar dinamicamente
        try {
            await chrome.scripting.executeScript({
                target: { tabId },
                files: ['content.js']
            });
            await chrome.scripting.insertCSS({
                target: { tabId },
                files: ['content.css']
            });
            await new Promise(r => setTimeout(r, 300));
            return true;
        } catch (err) {
            return false;
        }
    }
}

// ============================================
// FILENAME
// ============================================

async function buildFilename(suffix) {
    const stored = await chrome.storage.local.get(['umbra_clip_counter', 'umbra_folder', 'umbra_prefix']);
    const counter = (stored.umbra_clip_counter || 0) + 1;
    if (!suffix) await chrome.storage.local.set({ umbra_clip_counter: counter });
    const folder = stored.umbra_folder || '';
    const prefix = stored.umbra_prefix || 'clip';
    const timestamp = new Date().toISOString().slice(0, 10);
    const pad = String(counter).padStart(3, '0');
    const base = folder
        ? `${folder}/umbra/${prefix}_${timestamp}_${pad}`
        : `umbra/${prefix}_${timestamp}_${pad}`;
    return suffix ? `${base}_${suffix}.webm` : `${base}.webm`;
}

// ============================================
// START
// ============================================

async function startRecording(tab, options = {}) {
    if (isRecording) return { error: 'Já está gravando' };

    // Bloquear páginas restritas
    if (!tab?.id || tab.url?.startsWith('chrome://') || tab.url?.startsWith('about:') || tab.url?.startsWith('chrome-extension://')) {
        return { error: 'Não é possível gravar esta página. Tente em um site normal.' };
    }

    try {
        recordingTabId = tab.id;
        totalRecordedBytes = 0;
        recordingOptions = options;

        // Verificar content script antes de qualquer coisa
        const ready = await isContentScriptReady(tab.id);
        if (!ready) throw new Error('Não foi possível conectar ao content script desta página.');

        await ensureOffscreen();

        const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tab.id });
        if (!streamId) throw new Error('Falha ao capturar a aba');

        // Pré-gerar filename (não incrementa contador ainda — só na parada)
        // O contador só sobe no stop, então aqui apenas armazenamos a intenção
        await chrome.tabs.sendMessage(tab.id, {
            action: 'UMBRA_RECORDING_STARTED',
            includeMic: options.includeMic || false
        });

        await new Promise(r => setTimeout(r, 150));

        const response = await chrome.runtime.sendMessage({
            action: 'OFFSCREEN_START_RECORDING',
            streamId,
            options: {
                videoBitsPerSecond: options.videoBitsPerSecond || 5000000,
                maxFrameRate: options.maxFrameRate || 30,
                maxWidth: options.maxWidth || 1920,
                maxHeight: options.maxHeight || 1080,
                tabVolume: options.tabVolume !== undefined ? options.tabVolume : 1.0
            }
        });

        if (response?.error) throw new Error(response.error);

        isRecording = true;
        isPaused = false;
        recordingStartTime = Date.now();
        totalPausedMs = 0;
        pausedAt = null;
        updateBadge();

        if (options.autoStopMinutes > 0) {
            autoStopTimeout = setTimeout(() => stopRecording(), options.autoStopMinutes * 60 * 1000);
        }

        startTimerBroadcast(tab.id);
        return { success: true };

    } catch (error) {
        isRecording = false;
        recordingTabId = null;
        updateBadge();
        await closeOffscreen();
        safeSendMessage(tab.id, { action: 'UMBRA_RECORDING_ERROR', error: error.message });
        return { error: error.message };
    }
}

// ============================================
// STOP
// ============================================

async function stopRecording() {
    if (!isRecording) return { error: 'Nenhuma gravação ativa' };

    clearInterval(timerInterval);
    clearTimeout(autoStopTimeout);
    timerInterval = null;
    autoStopTimeout = null;

    const duration = recordingStartTime
        ? Math.round((Date.now() - recordingStartTime - totalPausedMs) / 1000)
        : 0;

    // Validação de duração mínima
    if (duration < MIN_RECORDING_SECONDS) {
        // Continua parando, mas avisa
        console.warn(`[Umbra] Gravação muito curta: ${duration}s`);
    }

    const tabId = recordingTabId;
    const hadMic = recordingOptions.includeMic || false;

    isRecording = false;
    isPaused = false;
    recordingTabId = null;
    recordingStartTime = null;
    totalPausedMs = 0;
    recordingOptions = {};
    updateBadge();

    try {
        // 1. Pedir mic ao content script
        let micObjectUrl = null;
        if (hadMic) {
            try {
                const micResult = await chrome.tabs.sendMessage(tabId, { action: 'UMBRA_STOP_MIC_AND_REPORT' });
                micObjectUrl = micResult?.micResult?.url || null;
            } catch (e) {
                console.warn('[Umbra] Mic não disponível:', e.message);
            }
        }

        // 2. Parar gravação no offscreen
        const response = await chrome.runtime.sendMessage({ action: 'OFFSCREEN_STOP_RECORDING' });
        if (response?.error) throw new Error(response.error);

        if (!response?.objectUrl) throw new Error('Nenhum dado de vídeo gravado');

        // 3. Gerar filename e salvar (incrementa contador aqui, atomicamente)
        const filename = await buildFilename();

        // 4. Download do vídeo principal
        await new Promise((resolve, reject) => {
            chrome.downloads.download({ url: response.objectUrl, filename, saveAs: false }, (id) => {
                if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
                else resolve(id);
            });
        });

        // Revogar URL do offscreen de forma segura — antes de fechar o offscreen
        setTimeout(async () => {
            try { await chrome.runtime.sendMessage({ action: 'OFFSCREEN_REVOKE_URL' }); } catch (e) {}
        }, 5000);

        // 5. Arquivo de voz separado
        if (micObjectUrl) {
            const micFilename = filename.replace('.webm', '_voz.webm');
            chrome.downloads.download({ url: micObjectUrl, filename: micFilename, saveAs: false }, () => {
                setTimeout(() => {
                    try { URL.revokeObjectURL(micObjectUrl); } catch (e) {}
                }, 30000);
            });
        }

        // 6. Salvar no histórico (incluindo flag hasMic)
        await saveToHistory({
            filename,
            duration,
            size: response.size,
            date: new Date().toISOString(),
            hasMic: !!micObjectUrl,
            tooShort: duration < MIN_RECORDING_SECONDS
        });

        safeSendMessage(tabId, {
            action: 'UMBRA_RECORDING_STOPPED',
            filename,
            duration,
            size: response.size,
            hasMic: !!micObjectUrl,
            tooShort: duration < MIN_RECORDING_SECONDS
        });

        setTimeout(() => closeOffscreen(), 4000);
        return { success: true, filename, duration };

    } catch (error) {
        safeSendMessage(tabId, { action: 'UMBRA_RECORDING_ERROR', error: error.message });
        await closeOffscreen();
        return { error: error.message };
    }
}

// ============================================
// PAUSE / RESUME
// ============================================

async function pauseRecording() {
    if (!isRecording || isPaused) return { error: 'Não é possível pausar agora' };
    try {
        const r = await chrome.runtime.sendMessage({ action: 'OFFSCREEN_PAUSE_RECORDING' });
        if (r?.error) throw new Error(r.error);
        isPaused = true;
        pausedAt = Date.now();
        clearInterval(timerInterval);
        updateBadge();
        safeSendMessage(recordingTabId, { action: 'UMBRA_RECORDING_PAUSED' });
        return { success: true };
    } catch (e) { return { error: e.message }; }
}

async function resumeRecording() {
    if (!isRecording || !isPaused) return { error: 'Não está pausado' };
    try {
        const r = await chrome.runtime.sendMessage({ action: 'OFFSCREEN_RESUME_RECORDING' });
        if (r?.error) throw new Error(r.error);
        if (pausedAt) totalPausedMs += Date.now() - pausedAt;
        isPaused = false;
        pausedAt = null;
        updateBadge();
        startTimerBroadcast(recordingTabId);
        safeSendMessage(recordingTabId, { action: 'UMBRA_RECORDING_RESUMED' });
        return { success: true };
    } catch (e) { return { error: e.message }; }
}

async function togglePause() { return isPaused ? await resumeRecording() : await pauseRecording(); }
async function toggleRecording(tab) { return isRecording ? await stopRecording() : await startRecording(tab); }

// ============================================
// TIMER — fonte única de verdade
// ============================================

function startTimerBroadcast(tabId) {
    clearInterval(timerInterval);
    timerInterval = setInterval(() => {
        if (!isRecording || isPaused) return;
        const elapsed = Math.round((Date.now() - recordingStartTime - totalPausedMs) / 1000);
        safeSendMessage(tabId, { action: 'UMBRA_TIMER_UPDATE', elapsed });
    }, 1000);
}

// ============================================
// HELPERS
// ============================================

function safeSendMessage(tabId, msg) {
    if (!tabId) return;
    chrome.tabs.sendMessage(tabId, msg).catch(() => {});
}

async function saveToHistory(entry) {
    const { umbra_history = [] } = await chrome.storage.local.get('umbra_history');
    umbra_history.unshift(entry);
    if (umbra_history.length > 50) umbra_history.splice(50);
    await chrome.storage.local.set({ umbra_history });
}

// ============================================
// MESSAGE HANDLER
// ============================================

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    (async () => {
        switch (message.action) {

            case 'GET_RECORDING_STATUS':
                sendResponse({
                    isRecording, isPaused,
                    elapsed: recordingStartTime
                        ? Math.round((Date.now() - recordingStartTime - totalPausedMs) / 1000)
                        : 0,
                    totalBytes: totalRecordedBytes
                });
                break;

            case 'START_RECORDING_REQUEST': {
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                sendResponse(await startRecording(tab, message.options || {}));
                break;
            }

            case 'STOP_RECORDING_REQUEST':
                sendResponse(await stopRecording());
                break;

            case 'TOGGLE_RECORDING_REQUEST': {
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                sendResponse(await toggleRecording(tab));
                break;
            }

            case 'PAUSE_RECORDING_REQUEST':
                sendResponse(await pauseRecording());
                break;

            case 'RESUME_RECORDING_REQUEST':
                sendResponse(await resumeRecording());
                break;

            case 'TOGGLE_PAUSE_REQUEST':
                sendResponse(await togglePause());
                break;

            case 'GET_HISTORY': {
                const { umbra_history = [] } = await chrome.storage.local.get('umbra_history');
                sendResponse(umbra_history);
                break;
            }

            case 'CLEAR_HISTORY':
                await chrome.storage.local.set({ umbra_history: [] });
                sendResponse({ success: true });
                break;

            case 'GET_DISK_SPACE':
                try {
                    await ensureOffscreen();
                    const disk = await chrome.runtime.sendMessage({ action: 'OFFSCREEN_CHECK_DISK' });
                    sendResponse(disk);
                } catch (e) { sendResponse(null); }
                break;

            case 'TOGGLE_PANEL': {
                const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
                safeSendMessage(tab.id, { action: 'UMBRA_TOGGLE_PANEL' });
                sendResponse({ success: true });
                break;
            }

            case 'OFFSCREEN_STREAM_ENDED':
                if (isRecording) await stopRecording();
                sendResponse({});
                break;

            case 'OFFSCREEN_CHUNK_SAVED':
                totalRecordedBytes = message.totalBytes || 0;
                if (recordingTabId) {
                    safeSendMessage(recordingTabId, {
                        action: 'UMBRA_SIZE_UPDATE',
                        totalBytes: totalRecordedBytes
                    });
                }
                sendResponse({});
                break;

            // ============================================
            // LICENCIAMENTO SDK v2.0 (MODO PADRÃO)
            // ============================================

            case 'GET_STATUS': {
                const data = await chrome.storage.local.get(["umbra_chave", "umbra_token"]);
                sendResponse({
                    valido: !!data.umbra_chave,
                    chave: data.umbra_chave || null,
                    token: data.umbra_token || null
                });
                break;
            }

            case 'ACTIVATE': {
                const response = await handleLicenseSDK("activate", { chave: message.chave });
                sendResponse(response);
                break;
            }

            case 'LOGOUT': {
                await chrome.storage.local.remove(["umbra_chave", "umbra_token", "umbra_expiry"]);
                sendResponse({ success: true });
                break;
            }

            default:
                sendResponse({});
        }
    })();
    return true;
});

// ─── Lógica SDK v2.0 ─────────────────────────────

async function getDeviceId() {
    let { umbra_device_id } = await chrome.storage.local.get("umbra_device_id");
    if (!umbra_device_id) {
        umbra_device_id = crypto.randomUUID();
        await chrome.storage.local.set({ umbra_device_id });
    }
    return umbra_device_id;
}

async function handleLicenseSDK(action, { chave, token }) {
    try {
        const device_id = await getDeviceId();
        const payload = {
            action,
            chave: chave || "",
            device_id,
            slug: SLUG,
            version: VERSION
        };
        if (token) payload.token = token;

        const res = await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        if (!res.ok) throw new Error("Erro na rede.");
        const data = await res.json();

        if (data.valido || data.success) {
            const finalToken = data.token || (data.data ? data.data.token : null);
            await chrome.storage.local.set({
                umbra_chave: chave,
                umbra_token: finalToken,
                umbra_expiry: Date.now() + (24 * 60 * 60 * 1000)
            });
            return { valido: true };
        } else {
            return { valido: false, motivo: data.motivo || data.message || "Chave inválida." };
        }
    } catch (e) {
        return { valido: false, motivo: "Erro de conexão." };
    }
}

// ============================================
// COMMANDS & ACTION
// ============================================

chrome.commands.onCommand.addListener(async (command) => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;
    if (command === 'toggle-recording') await toggleRecording(tab);
    if (command === 'toggle-pause') await togglePause();
    if (command === 'toggle-panel') safeSendMessage(tab.id, { action: 'UMBRA_TOGGLE_PANEL' });
});

chrome.action.onClicked.addListener(async (tab) => {
    if (!tab?.id) return;
    const ready = await isContentScriptReady(tab.id);
    if (ready) {
        safeSendMessage(tab.id, { action: 'UMBRA_TOGGLE_PANEL' });
    }
});

chrome.runtime.onInstalled.addListener(updateBadge);
chrome.runtime.onStartup.addListener(updateBadge);
