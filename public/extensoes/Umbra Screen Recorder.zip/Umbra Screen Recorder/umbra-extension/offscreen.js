// ============================================
// UMBRA SCREEN RECORDER - OFFSCREEN v1.1.0
// Fixes: AudioContext autoplay, codec list estendido,
// revogação segura de blob, cleanup correto
// ============================================

let mediaRecorder = null;
let mediaStream = null;
let audioContext = null;
let recordedChunks = [];
let recordingMimeType = 'video/webm';
let objectUrl = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

    if (message.action === 'OFFSCREEN_START_RECORDING') {
        startRecording(message.streamId, message.options || {})
            .then(() => sendResponse({ success: true }))
            .catch(err => sendResponse({ error: err.message }));
        return true;
    }

    if (message.action === 'OFFSCREEN_STOP_RECORDING') {
        stopRecording()
            .then(result => sendResponse(result))
            .catch(err => sendResponse({ error: err.message }));
        return true;
    }

    if (message.action === 'OFFSCREEN_PAUSE_RECORDING') {
        try {
            if (mediaRecorder && mediaRecorder.state === 'recording') {
                mediaRecorder.pause();
                if (audioContext?.state === 'running') audioContext.suspend();
                sendResponse({ success: true });
            } else {
                sendResponse({ error: 'Não está gravando' });
            }
        } catch (e) { sendResponse({ error: e.message }); }
        return true;
    }

    if (message.action === 'OFFSCREEN_RESUME_RECORDING') {
        try {
            if (mediaRecorder && mediaRecorder.state === 'paused') {
                if (audioContext?.state === 'suspended') audioContext.resume();
                mediaRecorder.resume();
                sendResponse({ success: true });
            } else {
                sendResponse({ error: 'Não está pausado' });
            }
        } catch (e) { sendResponse({ error: e.message }); }
        return true;
    }

    if (message.action === 'OFFSCREEN_REVOKE_URL') {
        // Revogar com segurança — garante que o offscreen ainda está vivo
        if (objectUrl) {
            try { URL.revokeObjectURL(objectUrl); } catch (e) {}
            objectUrl = null;
        }
        sendResponse({ success: true });
        return true;
    }

    if (message.action === 'OFFSCREEN_CHECK_DISK') {
        checkDiskSpace().then(info => sendResponse(info));
        return true;
    }
});

async function startRecording(streamId, options) {
    recordedChunks = [];

    // Capturar tela + áudio da aba
    mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: {
            mandatory: { chromeMediaSource: 'tab', chromeMediaSourceId: streamId }
        },
        video: {
            mandatory: {
                chromeMediaSource: 'tab',
                chromeMediaSourceId: streamId,
                maxWidth: options.maxWidth || 1920,
                maxHeight: options.maxHeight || 1080,
                maxFrameRate: options.maxFrameRate || 30
            }
        }
    });

    // AudioContext para redirecionar áudio da aba aos alto-falantes
    const audioTracks = mediaStream.getAudioTracks();
    if (audioTracks.length > 0) {
        audioContext = new AudioContext();

        // Tratar política de autoplay: resumir se suspenso
        if (audioContext.state === 'suspended') {
            try { await audioContext.resume(); } catch (e) {
                console.warn('[Umbra Offscreen] AudioContext suspenso, tentando continuar sem playback local');
            }
        }

        try {
            const source = audioContext.createMediaStreamSource(
                new MediaStream(audioTracks.map(t => t.clone()))
            );
            const gain = audioContext.createGain();
            gain.gain.value = options.tabVolume !== undefined ? options.tabVolume : 1.0;
            source.connect(gain);
            gain.connect(audioContext.destination);
        } catch (e) {
            console.warn('[Umbra Offscreen] Não foi possível conectar AudioContext ao destino:', e.message);
        }
    }

    // Seleção de codec — lista estendida com H.264 e VP9
    const mimeTypes = [
        'video/webm;codecs=avc1,opus',      // H.264 + Opus (aceleração HW em muitos sistemas)
        'video/webm;codecs=vp9,opus',        // VP9 + Opus (boa qualidade, sem HW)
        'video/webm;codecs=vp8,opus',        // VP8 + Opus (compatível universal)
        'video/webm;codecs=h264,opus',       // H.264 variante
        'video/webm'                          // Fallback genérico
    ];
    recordingMimeType = mimeTypes.find(t => MediaRecorder.isTypeSupported(t)) || 'video/webm';

    mediaRecorder = new MediaRecorder(mediaStream, {
        mimeType: recordingMimeType,
        videoBitsPerSecond: options.videoBitsPerSecond || 5000000,
        audioBitsPerSecond: 128000
    });

    mediaRecorder.ondataavailable = (event) => {
        if (event.data && event.data.size > 0) {
            recordedChunks.push(event.data);
            const total = recordedChunks.reduce((a, c) => a + c.size, 0);
            chrome.runtime.sendMessage({ action: 'OFFSCREEN_CHUNK_SAVED', totalBytes: total }).catch(() => {});
        }
    };

    const videoTrack = mediaStream.getVideoTracks()[0];
    if (videoTrack) {
        videoTrack.onended = () => {
            chrome.runtime.sendMessage({ action: 'OFFSCREEN_STREAM_ENDED' }).catch(() => {});
        };
    }

    mediaRecorder.start(1000);
}

function stopRecording() {
    return new Promise((resolve, reject) => {
        if (!mediaRecorder || mediaRecorder.state === 'inactive') {
            if (recordedChunks.length > 0) { finalize(resolve, reject); }
            else { reject(new Error('Gravação vazia')); }
            return;
        }
        if (mediaRecorder.state === 'paused') mediaRecorder.resume();
        mediaRecorder.onstop = () => { cleanup(); finalize(resolve, reject); };
        mediaRecorder.stop();
    });
}

function finalize(resolve, reject) {
    try {
        const totalSize = recordedChunks.reduce((a, c) => a + c.size, 0);
        if (totalSize === 0) {
            recordedChunks = [];
            reject(new Error('Nenhum dado gravado'));
            return;
        }
        const blob = new Blob(recordedChunks, { type: recordingMimeType });
        recordedChunks = [];

        // Revogar URL anterior se existir (evita leak)
        if (objectUrl) {
            try { URL.revokeObjectURL(objectUrl); } catch (e) {}
        }
        objectUrl = URL.createObjectURL(blob);
        resolve({ success: true, objectUrl, size: blob.size });
    } catch (e) {
        recordedChunks = [];
        reject(e);
    }
}

async function checkDiskSpace() {
    try {
        if (!navigator.storage?.estimate) return null;
        const { quota, usage } = await navigator.storage.estimate();
        return {
            availableMB: Math.round((quota - usage) / 1024 / 1024),
            quotaMB: Math.round(quota / 1024 / 1024)
        };
    } catch (e) { return null; }
}

function cleanup() {
    if (mediaStream) {
        mediaStream.getTracks().forEach(t => t.stop());
        mediaStream = null;
    }
    if (audioContext) {
        audioContext.close().catch(() => {});
        audioContext = null;
    }
    mediaRecorder = null;
}
