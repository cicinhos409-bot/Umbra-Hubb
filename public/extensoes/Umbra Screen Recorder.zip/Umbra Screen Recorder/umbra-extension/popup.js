// =============================================
//  UMBRA SCREEN RECORDER - POPUP JS
// =============================================

const btnAbrirPainel = document.getElementById("btn-abrir-painel");
const btnSair = document.getElementById("btn-sair");
const chaveExibida = document.getElementById("chave-exibida");

// ─── Ao abrir: carregar status básico ────────
chrome.storage.local.get("licenca_ativa", (data) => {
    if (data.licenca_ativa) {
        chaveExibida.textContent = data.licenca_ativa.slice(0, 9) + "-••••-••••";
    }
});

// ─── Abrir painel de gravação ─────────────────
btnAbrirPainel.addEventListener("click", async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    // Bloquear abrindo em páginas restritas
    if (!tab?.id || tab.url?.startsWith('chrome://') || tab.url?.startsWith('about:')) {
        alert("Não é possível abrir o gravador nesta página. Tente em um site normal.");
        return;
    }

    if (tab?.id) {
        chrome.tabs.sendMessage(tab.id, { action: "UMBRA_TOGGLE_PANEL" });
        window.close(); // fecha o popup após abrir o painel
    }
});

// ─── Remover licença ──────────────────────────
btnSair.addEventListener("click", () => {
    if (confirm("Deseja realmente remover a licença deste dispositivo?")) {
        chrome.storage.local.remove("licenca_ativa", () => {
            window.close();
        });
    }
});
